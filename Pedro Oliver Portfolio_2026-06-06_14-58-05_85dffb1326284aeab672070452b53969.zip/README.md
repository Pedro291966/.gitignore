# Portifólio | Pedro Oliver

Site profissional em React + Vite preparado para rodar na Square Cloud.

## Como rodar localmente

```bash
npm install
npm run dev
```

## Como enviar para a Square Cloud

1. Envie o `.zip` completo do projeto para a Square Cloud.
2. A Square Cloud vai instalar as dependências e executar `npm start`.
3. O arquivo `main_file.js` compila o Vite automaticamente quando necessário e serve a pasta `dist` com Express.

## Arquivos importantes

- `main_file.js`: servidor de produção para Square Cloud.
- `squarecloud.app`: configuração básica da aplicação.
- `public/logo.png`: logo oficial enviada.
