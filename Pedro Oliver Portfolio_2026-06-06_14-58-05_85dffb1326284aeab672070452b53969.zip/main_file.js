import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.join(__dirname, 'dist');
const indexPath = path.join(distPath, 'index.html');
const port = Number(process.env.PORT || process.env.SERVER_PORT || 3000);

function ensureProductionBuild() {
  if (fs.existsSync(indexPath)) {
    console.log('[Square Cloud] Build encontrado em /dist. Iniciando servidor...');
    return;
  }

  console.log('[Square Cloud] Pasta /dist não encontrada. Gerando build de produção...');
  execSync('npm run build', {
    cwd: __dirname,
    stdio: 'inherit',
    env: {
      ...process.env,
      NODE_ENV: 'production',
      NODE_OPTIONS: `${process.env.NODE_OPTIONS || ''} --max-old-space-size=1024`.trim(),
    },
  });
}

ensureProductionBuild();

const app = express();

app.disable('x-powered-by');
app.use(express.static(distPath, {
  maxAge: '1h',
  etag: true,
}));

app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'online', app: 'Portifólio | Pedro Oliver' });
});

app.get('*', (_req, res) => {
  res.sendFile(indexPath);
});

app.listen(port, '0.0.0.0', () => {
  console.log(`[Square Cloud] Portifólio | Pedro Oliver online em 0.0.0.0:${port}`);
});
