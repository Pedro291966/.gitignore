import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR controlado via variável DISABLE_HMR.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Desativa file watching quando DISABLE_HMR estiver ativo para poupar CPU.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
