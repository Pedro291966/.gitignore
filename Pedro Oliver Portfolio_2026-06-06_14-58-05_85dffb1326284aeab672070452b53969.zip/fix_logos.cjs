const fs = require('fs');
let code = fs.readFileSync('src/pages/InfoPage.tsx', 'utf8');

const jsLogo = `logo: (
      <motion.div 
        animate={{ y: [0, -10, 0] }} 
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
        className="w-32 h-32 flex items-center justify-center rounded-2xl bg-yellow-400/10 border border-yellow-400/30 relative shadow-[0_0_40px_rgba(250,204,21,0.2)]"
      >
        <div className="absolute inset-0 bg-yellow-400/20 blur-xl rounded-2xl animate-pulse" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/6/6a/JavaScript-logo.png" alt="JavaScript" className="w-20 h-20 object-contain z-10 drop-shadow-lg" />
      </motion.div>
    )`;

const htmlLogo = `logo: (
      <motion.div 
        animate={{ y: [0, -10, 0] }} 
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
        className="w-32 h-32 flex items-center justify-center rounded-2xl bg-orange-500/10 border border-orange-500/30 relative shadow-[0_0_40px_rgba(249,115,22,0.2)]"
      >
        <div className="absolute inset-0 bg-orange-500/20 blur-xl rounded-2xl animate-pulse" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/6/61/HTML5_logo_and_wordmark.svg" alt="HTML5" className="w-20 h-20 object-contain z-10 drop-shadow-lg" />
      </motion.div>
    )`;

const pythonLogo = `logo: (
      <motion.div 
        animate={{ y: [0, -10, 0] }} 
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        className="w-32 h-32 flex items-center justify-center rounded-2xl bg-blue-500/10 border border-blue-500/30 relative shadow-[0_0_40px_rgba(59,130,246,0.2)]"
      >
        <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-2xl animate-pulse" />
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/c3/Python-logo-notext.svg" alt="Python" className="w-20 h-20 object-contain z-10 drop-shadow-lg" />
      </motion.div>
    )`;

const runLogo = `logo: (
      <motion.div 
        animate={{ y: [0, -10, 0] }} 
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
        className="w-32 h-32 flex items-center justify-center rounded-2xl bg-emerald-500/10 border border-emerald-500/30 relative shadow-[0_0_40px_rgba(16,185,129,0.2)]"
      >
        <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-2xl animate-pulse" />
        <Server size={52} className="text-emerald-400 z-10 filter drop-shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
      </motion.div>
    )`;

// Replace JS
code = code.replace(/logo:\s*\([\s\S]*?<Zap size=\{52\} className="text-yellow-400" \/>[\s\S]*?\)/, jsLogo);
// Replace HTML
code = code.replace(/logo:\s*\([\s\S]*?<Globe size=\{52\} className="text-orange-400" \/>[\s\S]*?\)/, htmlLogo);
// Replace Python
code = code.replace(/logo:\s*\([\s\S]*?<Terminal size=\{52\} className="text-blue-400" \/>[\s\S]*?\)/, pythonLogo);
// Replace Run
code = code.replace(/logo:\s*\([\s\S]*?<Cpu size=\{52\} className="text-emerald-400" \/>[\s\S]*?\)/, runLogo);

fs.writeFileSync('src/pages/InfoPage.tsx', code);
