DISPLAY_NAME=Portifólio Pedro Oliver
DESCRIPTION=Portifólio profissional de Pedro Oliver em React e Vite.
MAIN=main_file.js
MEMORY=512
VERSION=recommended
AUTORESTART=true
