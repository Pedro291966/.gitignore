import { useState, useEffect } from 'react';
import Giscus from '@giscus/react';

interface CommentsProps {
  articleTitle?: string;
}

export default function Comments({ articleTitle = "Untitled Article" }: CommentsProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <div className="mt-16 border-t border-zinc-900 w-full pt-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h3 className="text-2xl font-display font-medium text-white mb-2">Comentários e Discussão</h3>
          <p className="text-zinc-500 text-sm font-light">Participe do debate, envie feedbacks e sugestões técnicas integrados ao GitHub.</p>
        </div>
        <span className="w-fit px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono rounded-full uppercase tracking-wider">GitHub Sync</span>
      </div>

      <div className="relative w-full bg-gradient-to-b from-zinc-900/50 to-zinc-950/80 rounded-3xl border border-zinc-900 shadow-xl overflow-hidden min-h-[300px]">
        <div className="w-full p-4 sm:p-8">
          {mounted && (
            <Giscus
              id="comments"
              repo="utterance/utterances"
              repoId="MDEwOlJlcG9zaXRvcnkxMTM2Mzg1MjM="
              category="Announcements"
              categoryId="DIC_kwDOBsV8O84CAtfG"
              mapping="specific"
              term={articleTitle}
              reactionsEnabled="1"
              emitMetadata="0"
              inputPosition="top"
              theme="dark"
              lang="pt"
              loading="lazy"
            />
          )}
        </div>
      </div>
    </div>
  );
}
