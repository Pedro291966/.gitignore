import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface Props {
  title: ReactNode;
  subtitle: string;
}

export default function SectionHeader({ title, subtitle }: Props) {
  return (
    <div className="py-24 md:py-32 border-b border-zinc-900 border-dashed mb-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl"
        >
          <h1 className="text-4xl md:text-6xl font-display font-medium tracking-tight mb-6">
            {title}
          </h1>
          <p className="text-lg md:text-xl text-zinc-400 font-light leading-relaxed">
            {subtitle}
          </p>
        </motion.div>
      </div>
    </div>
  );
}
