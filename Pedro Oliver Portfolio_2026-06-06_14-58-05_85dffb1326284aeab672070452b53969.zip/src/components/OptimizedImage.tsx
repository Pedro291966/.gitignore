import { useState } from 'react';
import { motion } from 'motion/react';
import { ImageOff } from 'lucide-react';

interface Props extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'onAnimationStart' | 'onDragStart' | 'onDragEnd' | 'onDrag'> {
  src: string;
  alt: string;
}

export function OptimizedImage({ src, alt, className, ...props }: Props) {
  const [loaded, setLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  return (
    <div className={`relative overflow-hidden bg-zinc-900 ${className || ''}`}>
      {!loaded && !hasError && (
        <div className="absolute inset-0 bg-zinc-800 animate-pulse" />
      )}

      {hasError ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-zinc-900 to-zinc-950 p-6 text-center border border-zinc-800/50 rounded-2xl">
          <ImageOff size={24} className="text-zinc-600 mb-2 animate-pulse" />
          <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest">Mídia não disponível</span>
        </div>
      ) : (
        <motion.img
          initial={{ filter: 'blur(20px)', opacity: 0 }}
          animate={{ filter: loaded ? 'blur(0px)' : 'blur(20px)', opacity: loaded ? 1 : 0 }}
          transition={{ duration: 0.5 }}
          src={src || ''}
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 1200px"
          alt={alt}
          loading="lazy"
          decoding="async"
          onLoad={() => setLoaded(true)}
          onError={() => setHasError(true)}
          className="w-full h-full object-cover transition-transform duration-500 ease-out hover:scale-[1.02]"
          {...props}
        />
      )}
    </div>
  );
}
