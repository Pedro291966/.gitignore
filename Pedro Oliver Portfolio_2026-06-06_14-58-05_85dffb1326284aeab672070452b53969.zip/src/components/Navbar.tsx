import { useState, useEffect, useRef } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Sun, Moon, Search, FileText, CornerDownLeft, HelpCircle, Layers, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { infoPages } from '../data/infoPages';

const links = [
  { name: 'Início', path: '/' },
  { name: 'Sobre', path: '/about' },
  { name: 'Projetos', path: '/projects' },
  { name: 'Artigos', path: '/articles' },
  { name: 'Novidades', path: '/news' },
  { name: 'Docs', path: '/docs' },
  { name: 'Bots', path: '/bots' },
  { name: 'Sistemas', path: '/sistemas' },
  { name: 'FAQ', path: '/faq' },
  { name: 'Contato', path: '/contact' }
];

export default function Navbar() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isLight, setIsLight] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [focusedIndex, setFocusedIndex] = useState(-1);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    
    // Check initial theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
      setIsLight(true);
      document.body.classList.add('light');
    }
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const [placeholderText, setPlaceholderText] = useState('');
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const placeholders = [
    "Buscar artigos, páginas...",
    "O que busca no portifólio?",
    "Pesquisar documentações...",
    "Navegar em soluções..."
  ];

  useEffect(() => {
    if (!searchOpen) return;
    
    let timer: NodeJS.Timeout;
    const currentFullText = placeholders[placeholderIndex];

    if (isDeleting) {
      timer = setTimeout(() => {
        setPlaceholderText(currentFullText.substring(0, placeholderText.length - 1));
        if (placeholderText.length <= 1) {
          setIsDeleting(false);
          setPlaceholderIndex((prev) => (prev + 1) % placeholders.length);
        }
      }, 50); // Deleting speed
    } else {
      timer = setTimeout(() => {
        setPlaceholderText(currentFullText.substring(0, placeholderText.length + 1));
        if (placeholderText.length === currentFullText.length) {
          timer = setTimeout(() => setIsDeleting(true), 2000); // Wait before delete
        }
      }, 100); // Typing speed
    }

    return () => clearTimeout(timer);
  }, [placeholderText, isDeleting, placeholderIndex, searchOpen, placeholders]);

  const toggleTheme = () => {
    if (isLight) {
      document.body.classList.remove('light');
      localStorage.setItem('theme', 'dark');
      setIsLight(false);
    } else {
      document.body.classList.add('light');
      localStorage.setItem('theme', 'light');
      setIsLight(true);
    }
  };

  useEffect(() => {
    setIsOpen(false);
    setSearchOpen(false);
    setSearchQuery('');
  }, [location]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && searchOpen) {
        setSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [searchOpen]);

  useEffect(() => {
    if (searchOpen && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 100);
    }
  }, [searchOpen]);

  const toggleSearch = () => {
    setSearchOpen(!searchOpen);
    if (!searchOpen) {
      setSearchQuery('');
      setFocusedIndex(-1);
    }
  };

  const handleClearOrClose = () => {
    if (searchQuery) {
      setSearchQuery('');
      setFocusedIndex(-1);
      searchInputRef.current?.focus();
    } else {
      setSearchOpen(false);
    }
  };

  const navItems = [
    { name: 'Início', path: '/', type: 'page', category: 'Navegação', desc: 'Página inicial e institucional' },
    { name: 'Sobre Nós', path: '/about', type: 'page', category: 'Navegação', desc: 'História, missão e valores' },
    { name: 'Nossos Projetos', path: '/projects', type: 'page', category: 'Navegação', desc: 'Cases e portfólio desenvolvido' },
    { name: 'Artigos & Insights', path: '/articles', type: 'page', category: 'Navegação', desc: 'Conhecimento técnico' },
    { name: 'Novidades', path: '/news', type: 'page', category: 'Navegação', desc: 'Atualizações e releases' },
    { name: 'Central de FAQ', path: '/faq', type: 'page', category: 'Navegação', desc: 'Perguntas frequentes' },
    { name: 'Fale Conosco', path: '/contact', type: 'page', category: 'Navegação', desc: 'Orçamentos e canais de contato' },
  ];

  const pageItems = Object.values(infoPages).map(p => ({
    name: p.title.replace('Documentação: ', '').replace('Manifesto: ', ''),
    path: `/info/${p.id}`,
    type: p.id === 'pedro-oliver-dev' || p.id === 'sobre-mim' ? 'page' : 'doc',
    category: p.id === 'pedro-oliver-dev' || p.id === 'sobre-mim' ? 'Institucional' : 'Tecnologias & Docs',
    desc: p.description
  }));

  const allSearchableItems = [...navItems, ...pageItems];

  const searchResults = searchQuery.trim().length > 0
    ? allSearchableItems.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.desc.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 6)
    : [
        { name: 'Aplicações React', path: '/info/react', type: 'doc', desc: 'Interfaces de alto desempenho', category: 'Sugestões' },
        { name: 'Automação Python', path: '/info/python', type: 'doc', desc: 'Robôs e inteligência de planilhas', category: 'Sugestões' },
        { name: 'Status do Sistema', path: '/info/status', type: 'doc', desc: 'Uptime e monitoramento em tempo real', category: 'Sugestões' },
        { name: 'Nossos Cases', path: '/projects', type: 'page', desc: 'Trabalhos selecionados corporativos', category: 'Sugestões' },
        { name: 'Central de Ajuda', path: '/info/central-de-ajuda', type: 'doc', desc: 'Dúvidas de contratos de SLA', category: 'Sugestões' },
      ];

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!searchOpen) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setFocusedIndex(prev => (prev + 1) % searchResults.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setFocusedIndex(prev => (prev - 1 + searchResults.length) % searchResults.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (focusedIndex >= 0 && focusedIndex < searchResults.length) {
        const item = searchResults[focusedIndex];
        setSearchOpen(false);
        setSearchQuery('');
        navigate(item.path);
      } else if (searchResults.length > 0) {
        const item = searchResults[0];
        setSearchOpen(false);
        setSearchQuery('');
        navigate(item.path);
      }
    } else if (e.key === 'Escape') {
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'page': return <FileText size={14} className="text-zinc-400 shrink-0" />;
      case 'doc': return <Layers size={14} className="text-blue-400 shrink-0" />;
      default: return <Compass size={14} className="text-emerald-400 shrink-0" />;
    }
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-black/80 backdrop-blur-md border-b border-white/10 py-4 shadow-xl' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8 flex items-center justify-between">
        <NavLink 
          to="/" 
          aria-label="Página Inicial - Portifólio de Pedro Oliver"
          className="text-xl font-display font-medium tracking-tighter uppercase z-50 relative group flex items-center gap-2"
        >
          <div className="w-10 h-10 rounded-xl border border-white/10 bg-zinc-950 flex items-center justify-center overflow-hidden shadow-[0_0_22px_rgba(255,255,255,0.18)] transform group-hover:scale-105 group-hover:rotate-3 transition-all duration-300">
            <img src="/logo.png" alt="Logo Pedro Oliver" className="w-9 h-9 object-contain" />
          </div>
          <span className="hidden sm:block">Portifólio <span className="text-zinc-500 group-hover:text-white transition-colors">| Pedro Oliver</span></span>
          <span className="absolute top-full lg:left-1/2 lg:-translate-x-1/2 mt-2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-lg border border-zinc-800">
            Ir para a Home
          </span>
        </NavLink>

        <nav 
          role="navigation" 
          aria-label="Navegação Principal"
          className="hidden md:flex gap-6 lg:gap-8 items-center"
        >
          {links.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              aria-label={`Ir para ${link.name}`}
              className={({ isActive }) =>
                `relative group text-sm font-medium tracking-wide uppercase transition-all duration-300 ${
                   link.path === '/about' ? 'hover:scale-105 hover:-translate-y-0.5 hover:text-emerald-400 hover:drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]' : 'hover:text-white'
                } ${
                  isActive ? 'text-white' : 'text-zinc-400'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <span className="relative z-10 px-0.5">{link.name}</span>
                  {isActive && (
                    <motion.div 
                      layoutId="navbar-active"
                      className="absolute -inset-x-3 -inset-y-2 bg-gradient-to-r from-emerald-500/20 via-emerald-400/10 to-transparent rounded-full -z-10 border border-emerald-500/20 shadow-[0_0_15px_rgba(52,211,153,0.15)] backdrop-blur-sm"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-zinc-900/90 backdrop-blur-md text-zinc-200 text-xs font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_10px_30px_rgba(0,0,0,0.5)] border border-zinc-700/50 transform translate-y-2 group-hover:translate-y-0 z-50 flex items-center justify-center">
                    Acessar {link.name}
                    <div className="absolute -top-1 left-1/2 -translate-x-1/2 border-[5px] border-transparent border-b-zinc-800/80" />
                  </div>
                </>
              )}
            </NavLink>
          ))}
          
          <div className="flex items-center gap-2">
            <div className="relative flex items-center h-10">
              <AnimatePresence>
                {searchOpen && (
                  <motion.div
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 320, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    className="overflow-visible absolute right-12 flex items-center bg-zinc-950 rounded-full"
                  >
                    <div className="relative w-full">
                      <input
                        ref={searchInputRef}
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={handleInputKeyDown}
                        placeholder={placeholderText}
                        className="w-full h-11 bg-zinc-900 border border-zinc-700/50 rounded-xl pl-4 pr-12 text-sm text-white focus:outline-none focus:border-zinc-400 focus:ring-1 focus:ring-zinc-400 focus:bg-zinc-800/80 shadow-[0_0_30px_rgba(0,0,0,0.8)] transition-all z-20 relative placeholder-zinc-500"
                        aria-label="Campo de busca"
                      />
                      {!searchQuery && (
                         <span className="absolute right-12 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-white animate-pulse pointer-events-none opacity-50"></span>
                      )}
                      <AnimatePresence>
                        {searchQuery && (
                          <motion.button 
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            onClick={handleClearOrClose}
                            className="absolute right-12 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-emerald-400 z-30 p-1.5 hover:bg-emerald-500/10 rounded-lg transition-all duration-200"
                            aria-label="Limpar busca"
                          >
                            <X size={15} />
                          </motion.button>
                        )}
                      </AnimatePresence>
                      {searchOpen && (
                        <button 
                          onClick={() => {
                            setSearchOpen(false);
                            setSearchQuery('');
                          }}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white z-30 p-1.5 hover:bg-zinc-800 rounded-lg transition-colors border-l border-zinc-800/50 pl-3"
                          aria-label="Fechar busca"
                        >
                          <X size={14} />
                        </button>
                      )}

                      <AnimatePresence>
                        {searchOpen && (
                          <motion.div 
                            initial={{ opacity: 0, y: 15, scale: 0.98 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.98 }}
                            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                            className="absolute top-14 left-0 w-full min-w-[340px] md:min-w-[400px] bg-zinc-900/95 border border-zinc-800 rounded-2xl overflow-hidden shadow-[0_20px_60px_-15px_rgba(0,0,0,0.8)] z-50 pt-3 pb-3 backdrop-blur-2xl"
                          >
                            <div className="px-5 pb-2 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] mb-2 flex items-center justify-between">
                              <span>{searchQuery.trim().length > 0 ? 'Resultados Relacionados' : 'Sugestões Rápidas'}</span>
                              {searchQuery.trim().length === 0 && <span className="text-[9px] text-zinc-600 font-mono font-normal">Pressione setas para navegar</span>}
                            </div>
                            {searchResults.length > 0 ? (
                              <ul className="flex flex-col gap-1 px-2 max-h-[380px] overflow-y-auto custom-scrollbar">
                                {searchResults.map((res: any, i: number) => (
                                  <li key={i}>
                                    <NavLink 
                                      to={res.path} 
                                      className={`flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl transition-all group ${
                                        i === focusedIndex 
                                          ? 'bg-white/10 text-white' 
                                          : 'text-zinc-300 hover:text-white hover:bg-white/5'
                                      }`} 
                                      onClick={() => {
                                        setSearchOpen(false);
                                        setSearchQuery('');
                                      }}
                                      onMouseEnter={() => setFocusedIndex(i)}
                                    >
                                      <div className="flex items-center gap-3">
                                        <div className="w-7 h-7 rounded-lg bg-zinc-800/40 flex items-center justify-center border border-zinc-800 shrink-0 group-hover:bg-zinc-800 transition-colors">
                                          {getTypeIcon(res.type)}
                                        </div>
                                        <div className="flex flex-col text-left">
                                          <div className="flex items-center gap-1.5">
                                            <span className="text-sm font-medium group-hover:translate-x-0.5 transition-transform">{res.name}</span>
                                            {res.category && (
                                              <span className="text-[9px] uppercase font-semibold text-zinc-500 bg-zinc-800/60 px-1.5 py-0.5 rounded-md self-center">
                                                {res.category}
                                              </span>
                                            )}
                                          </div>
                                          {res.desc && <span className="text-[11px] text-zinc-500 group-hover:text-zinc-400 group-hover:translate-x-0.5 transition-colors line-clamp-1">{res.desc}</span>}
                                        </div>
                                      </div>
                                      
                                      {/* Key indicators for interactive selection */}
                                      {i === focusedIndex && (
                                        <motion.div 
                                          layoutId="search-arrow-indicator"
                                          className="flex items-center gap-1 text-[9px] font-mono text-zinc-500 bg-zinc-950 px-1.5 py-0.5 rounded border border-zinc-800"
                                        >
                                          <span>Ir</span>
                                          <CornerDownLeft size={8} />
                                        </motion.div>
                                      )}
                                    </NavLink>
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <div className="px-5 py-8 flex flex-col items-center justify-center text-center gap-2">
                                <Search size={22} className="text-zinc-600 mb-1" />
                                <span className="text-sm text-zinc-300 font-medium">Nenhum resultado para "{searchQuery}"</span>
                                <span className="text-xs text-zinc-500">Tente buscar por tecnologias ou explore nossas seções.</span>
                              </div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              <button 
                onClick={toggleSearch}
                className={`flex items-center justify-center w-10 h-10 rounded-full transition-all group z-10 ${searchOpen ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/5'}`}
                aria-label={searchOpen ? "Fechar Busca" : "Abrir Busca"}
              >
                {searchOpen ? <X size={18} /> : <Search size={18} />}
                {!searchOpen && (
                  <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800">
                    Buscar
                  </span>
                )}
              </button>
            </div>

            <button 
              onClick={toggleTheme}
              className="text-zinc-400 hover:text-white transition-colors ml-1 relative group w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/5"
              aria-label={isLight ? "Ativar tema escuro" : "Ativar tema claro"}
            >
              {isLight ? <Moon size={18} /> : <Sun size={18} />}
              <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800">
                {isLight ? "Tema Escuro" : "Tema Claro"}
              </span>
            </button>
          </div>
        </nav>

        <div className="flex items-center gap-2 md:hidden z-50">
          <button 
            onClick={toggleTheme}
            className="text-zinc-400 hover:text-white transition-colors p-2 rounded-md hover:bg-zinc-900"
            aria-label={isLight ? "Ativar tema escuro" : "Ativar tema claro"}
          >
            {isLight ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          
          <button 
            className="text-white relative group p-2 hover:bg-zinc-900 rounded-md transition-colors"
            onClick={() => setIsOpen(!isOpen)}
            aria-label={isOpen ? "Fechar Menu" : "Abrir Menu"}
            aria-expanded={isOpen}
            aria-controls="mobile-menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
            <span className="absolute right-full mr-2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800">
              {isOpen ? "Fechar" : "Menu"}
            </span>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            id="mobile-menu"
            role="dialog"
            aria-label="Menu Mobile"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 bg-gradient-to-b from-zinc-950 to-black z-40 flex flex-col items-center justify-center gap-6 md:hidden"
          >
            <div className="flex flex-col gap-4 w-full px-8 mt-10">
              {links.map((link, idx) => (
                <NavLink
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) =>
                    `group flex items-center justify-between text-2xl font-display font-medium uppercase tracking-widest transition-all p-3 rounded-2xl ${
                      isActive ? 'text-white bg-white/5 border border-white/10' : 'text-zinc-500 hover:text-zinc-300 hover:bg-white/5'
                    }`
                  }
                >
                  <motion.span 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 + (idx * 0.05) }}
                    className="group-hover:translate-x-2 transition-transform duration-300"
                  >
                    {link.name}
                  </motion.span>
                  <span className="opacity-0 group-hover:opacity-100 text-emerald-500 -translate-x-4 group-hover:translate-x-0 transition-all duration-300">
                    →
                  </span>
                </NavLink>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Search Overlay for closing when clicking outside */}
      {searchOpen && (
        <div 
          className="fixed inset-0 z-40 hidden md:block" 
          onClick={() => setSearchOpen(false)}
          aria-hidden="true"
        />
      )}
    </header>
  );
}
