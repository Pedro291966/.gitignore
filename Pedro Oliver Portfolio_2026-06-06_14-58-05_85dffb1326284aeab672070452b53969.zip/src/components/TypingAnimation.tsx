import { motion, useAnimationControls } from 'motion/react';
import { useEffect, useState } from 'react';

export function TypingAnimation({ text, className = '' }: { text: string; className?: string }) {
  const controls = useAnimationControls();

  useEffect(() => {
    controls.start("visible");
  }, [controls, text]);

  const container = {
    hidden: { opacity: 1 },
    visible: {
      transition: { staggerChildren: 0.02, delayChildren: 0.1 },
    },
  };

  const child: any = {
    visible: {
      opacity: 1,
      y: 0,
      filter: "blur(0px)",
      transition: {
        type: 'spring',
        damping: 18,
        stiffness: 120,
      },
    },
    hidden: {
      opacity: 0,
      y: 10,
      filter: "blur(4px)",
    },
  };

  return (
    <motion.span
      style={{ display: 'inline-block', flexWrap: 'wrap' }}
      variants={container}
      initial="hidden"
      animate={controls}
      className={className}
    >
      {text.split(' ').map((word, wIndex) => (
        <span key={`w-${wIndex}`} className="inline-flex mr-[0.25em] relative">
          {word.split('').map((char, cIndex) => (
            <motion.span variants={child} key={`c-${wIndex}-${cIndex}`} className="inline-block relative">
              {char}
            </motion.span>
          ))}
        </span>
      ))}
    </motion.span>
  );
}
