import { NavLink, Link } from 'react-router-dom';
import { Github, Twitter, Linkedin, Instagram, ShieldCheck, Activity, Globe } from 'lucide-react';
import { motion } from 'motion/react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    navegacao: [
      { name: 'Página Inicial', path: '', desc: 'Voltar ao início' },
      { name: 'Nossos Projetos', path: 'projects', desc: 'Portfólio de excelência de Pedro Oliver' },
      { name: 'Insights & Blog', path: 'info/blog', desc: 'Leitura e análises técnicas' },
      { name: 'Sistemas Web', path: 'info/desenvolvimento-web', desc: 'Arquitetura de software de ponta' },
      { name: 'Sites Customizados', path: 'info/otimizacao', desc: 'Otimizados de alta performance' },
    ],
    empresa: [
      { name: 'Quem Somos', path: 'info/pedro-oliver-dev', desc: 'História e DNA de Pedro Oliver Dev' },
      { name: 'Quem é Pedro Oliver', path: 'info/sobre-mim', desc: 'Conheça o desenvolvedor' },
      { name: 'Serviços Premium', path: 'info/servicos', desc: 'Consultoria e engenharia' },
      { name: 'Nossas Parcerias', path: 'info/parcerias', desc: 'Crescimento compartilhado' },
      { name: 'Novidades & Releases', path: 'news', desc: 'Últimas atualizações da marca' },
    ],
    tecnologias: [
      { name: 'Ecossistema JavaScript', path: 'info/javascript', desc: 'Aplicações seguras e rápidas' },
      { name: 'Interfaces com React', path: 'info/react', desc: 'Componentes interativos elegantes' },
      { name: 'Engenharia de Node.js', path: 'info/back-end', desc: 'Middlewares e integrações REST' },
      { name: 'Automação Python', path: 'info/python', desc: 'Modelos e processamento automático' },
      { name: 'UI/UX & Design System', path: 'info/ui-ux', desc: 'Visual elegante e responsivo' },
    ],
    documentacao: [
      { name: 'Guias & Tutoriais', path: 'info/guias-tutoriais', desc: 'Aprenda do zero com a gente' },
      { name: 'Bots de Discord', path: 'info/discord-bots', desc: 'Integre robôs automáticos' },
      { name: 'Square Cloud Deploy', path: 'info/square-cloud', desc: 'Hospedagem ágil na nuvem' },
      { name: 'Infra hoteleira & Host', path: 'info/hospedagem', desc: 'Servidores de alto uptime' },
    ],
    suporte: [
      { name: 'Central de Ajuda', path: 'info/central-de-ajuda', desc: 'Guia de SLA e consultoria' },
      { name: 'Perguntas Frequentes', path: 'faq', desc: 'Principais respostas ágeis' },
      { name: 'Abra um Ticket', path: 'contact', desc: 'Suporte técnico humano' },
      { name: 'Status operacional', path: 'info/status', desc: 'Uptime em tempo real' },
    ],
    politicas: [
      { name: 'Termos de Serviço', path: 'info/termos-uso', desc: 'Contratos e licenças' },
      { name: 'Privacidade de Dados', path: 'info/politica-privacidade', desc: 'Sua privacidade em 1º lugar' },
      { name: 'Diretiva de Cookies', path: 'info/politica-cookies', desc: 'Gestão de rastreadores' },
      { name: 'Segurança & Código', path: 'info/seguranca-digital', desc: 'Auditorias e mitigação de risco' },
    ]
  };

  const RenderLinks = ({ section, links }: { section: string, links: any[] }) => (
    <div className="col-span-1">
      <h3 className="text-xs font-bold tracking-widest uppercase text-zinc-100 mb-6 relative inline-block">
        {section}
        <span className="absolute -bottom-2 left-0 w-5 h-[2px] bg-zinc-700"></span>
      </h3>
      <ul className="flex flex-col gap-3">
        {links.map((item, i) => (
          <li key={i} className="relative group">
            <Link 
              to={`/${item.path}`} 
              className="flex items-center gap-2 w-fit relative transition-all duration-200 hover:translate-x-1"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-700 transition-all group-hover:bg-emerald-400 group-hover:scale-125 shadow-[0_0_10px_rgba(16,185,129,0.5)]" aria-hidden="true" />
              <span className="text-sm text-zinc-400 group-hover:text-emerald-300 transition-colors relative">
                {item.name}
              </span>
              
              {/* Premium Dark Theme Tooltip - Hidden on mobile, animated on hover on desktop */}
              <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs rounded-lg opacity-0 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_4px_20px_rgba(0,0,0,0.8)] transform translate-x-2 group-hover:translate-x-0 z-50 group-hover:opacity-100 hidden md:block select-none font-sans">
                <span className="text-zinc-100 font-medium">{item.desc}</span>
                <div className="absolute left-0 top-1/2 -translate-x-1 -translate-y-1/2 border-[4px] border-transparent border-r-zinc-800" />
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <footer className="border-t border-zinc-900 bg-zinc-950 pt-24 pb-8 px-6 lg:px-8 mt-24 relative overflow-hidden">
      {/* Background radial soft light for tech theme */}
      <div className="absolute top-0 left-1/4 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-zinc-800 to-transparent opacity-80" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 aspect-[3/1] bg-emerald-500/5 blur-[120px] rounded-[100%] pointer-events-none" />

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-12 mb-20 relative z-10">
        
        {/* Brand Hero block - spanning 1 major grid column */}
        <div className="lg:col-span-1 flex flex-col justify-between gap-8 h-full">
          <div>
            <div className="text-2xl font-display font-medium tracking-tighter uppercase mb-6 flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl border border-zinc-800 bg-black flex items-center justify-center overflow-hidden shadow-[0_0_22px_rgba(255,255,255,0.16)]">
                <img src="/logo.png" alt="Logo Pedro Oliver" className="w-9 h-9 object-contain" />
              </div>
              <span>PORTIFÓLIO <span className="text-zinc-500">| PEDRO OLIVER</span></span>
            </div>
            
            <p className="text-zinc-400 text-sm max-w-sm mb-6 leading-relaxed font-light">
              Construímos ecossistemas robustos de desenvolvimento web, bots integrados de alta densidade e aplicações escaláveis orientadas a desempenho.
            </p>

            {/* Certifications & Trust indicators */}
            <div className="flex flex-col gap-2.5 mb-6">
              <div className="flex items-center gap-2 text-zinc-500 hover:text-zinc-400 transition-colors">
                <ShieldCheck size={14} className="text-emerald-500 shrink-0" />
                <span className="text-xs font-mono">Seguro e funcionando - ISO-27001</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-500 hover:text-zinc-400 transition-colors">
                <Activity size={14} className="text-emerald-500 shrink-0" />
                <span className="text-xs font-mono">Aplicações funcionando em 90%</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Nossa presença social</span>
            <div className="flex gap-3" role="navigation" aria-label="Redes Sociais">
              {[
                { id: 'gh', name: 'Github', icon: <Github size={18} />, url: 'https://github.com' },
                { id: 'tw', name: 'Twitter', icon: <Twitter size={18} />, url: 'https://twitter.com' },
                { id: 'li', name: 'LinkedIn', icon: <Linkedin size={18} />, url: 'https://linkedin.com' },
                { id: 'in', name: 'Instagram', icon: <Instagram size={18} />, url: 'https://instagram.com' },
              ].map(social => (
                <a 
                  key={social.id} 
                  href={social.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="group relative w-10 h-10 rounded-xl border border-zinc-800 bg-zinc-900/40 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-700 hover:bg-zinc-900 transition-all duration-300 active:scale-95 hover:-translate-y-1" 
                  aria-label={`Siga-nos no ${social.name}`}
                >
                  {social.icon}
                  
                  {/* Tooltip */}
                  <span className="absolute -top-12 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 border border-zinc-800 text-zinc-100 text-[11px] font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-lg z-20">
                    {social.name}
                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 border-[5px] border-transparent border-t-zinc-800" />
                  </span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Links matrix block - spanning 3 grid columns on lg */}
        <div className="lg:col-span-3 grid grid-cols-2 sm:grid-cols-3 max-md:gap-y-10 gap-x-8 gap-y-12">
          <RenderLinks section="Navegação" links={footerLinks.navegacao} />
          <RenderLinks section="Empresa" links={footerLinks.empresa} />
          <RenderLinks section="Tecnologias" links={footerLinks.tecnologias} />
          <RenderLinks section="Documentação" links={footerLinks.documentacao} />
          <RenderLinks section="Suporte" links={footerLinks.suporte} />
          <RenderLinks section="Políticas" links={footerLinks.politicas} />
        </div>

      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
        <p className="text-xs text-zinc-500 tracking-wide font-mono">
          &copy; {currentYear} Portifólio | Pedro Oliver. Todos os direitos reservados. 
        </p>
        
        <div className="flex gap-6 items-center">
          <Link to="/info/politica-privacidade" className="text-xs text-zinc-500 hover:text-zinc-300 hover:underline transition-all">Privacidade</Link>
          <span className="text-zinc-800 text-xs font-mono">•</span>
          <Link to="/info/termos-uso" className="text-xs text-zinc-500 hover:text-zinc-300 hover:underline transition-all">Termos de Uso</Link>
          <span className="text-zinc-800 text-xs font-mono">•</span>
          <Link to="/info/politica-cookies" className="text-xs text-zinc-500 hover:text-zinc-300 hover:underline transition-all">Cookies</Link>
          <span className="text-zinc-800 text-xs font-mono">•</span>
          <Link to="/info/status" className="text-xs text-zinc-500 hover:text-zinc-300 flex items-center gap-1.5 transition-all">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Sistema online
          </Link>
        </div>
      </div>
    </footer>
  );
}
