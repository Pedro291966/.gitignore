import { InfoPageType } from '../types';

export const infoPages: Record<string, InfoPageType> = {
  javascript: {
    id: "javascript",
    title: "Documentação: JavaScript Moderno",
    description: "Do Front-end imersivo ao Back-end de altíssima performance. Descubra como a linguagem universal da internet move aplicações corporativas com Pedro Oliver Dev.",
    content: `
### O que é o JavaScript?
O **JavaScript (JS)** é a espinha dorsal de tudo que se move, interage e responde nas aplicações web de hoje. Lançado em 1995 como uma linguagem simples de *scripting* para navegadores, ele superou rapidamente esse rótulo. Hoje, é uma das linguagens de programação mais adotadas e maduras da Terra, operando desde microcontroladores até sistemas bancários massivos globais. 

Sua habilidade singular de rodar nativamente em literalmente qualquer navegador moderno fez do JS uma escolha tática inevitável para projetos que precisam ser acessíveis ao público em geral.

### Por que o JavaScript é revolucionário?
Seu gigantesco impacto no mercado ocorreu pela introdução do **Assincronismo Inteligente (Event Loop)**. O JavaScript não trava o sistema esperando o término de uma tarefa demorada (como carregar uma foto pesada ou buscar dados de um servidor). Ele despacha a tarefa e continua processando e renderizando o resto do seu aplicativo fluentemente. Para o usuário final, isso significa **Zero Interrupções**.

### Onde ele é utilizado no mercado?
* **Aplicações de Página Única (SPA)**: Sites como Spotify, Netflix e Gmail; onde a página nunca pisca ou recarrega.
* **Server-side (Back-end)**: Utilizando o ambiente *Node.js*, grandes marcas escalam suas APIs suportando milhões de requisições por segundo.
* **Aplicativos Nativos Mobile (React Native)**: Códigos escritos em JS que são renderizados como aplicativos nativos para iOS e Android.
* **Automações Nativas de Nuvem**: Funções semânticas que reagem a eventos (AWS Lambda, Vercel Edge).

### JavaScript de Nível *Enterprise* por Pedro Oliver Dev
Na Pedro Oliver Dev não apenas utilizamos JavaScript, nós dominamos seu ecossistema. 

**Nossos Padrões Ouro:**
1. **Tipagem Estrita (TypeScript)**: Não permitimos JavaScript puro (\`Vanilla JS\`) na camada de produção empresarial. Tudo é tipado com TypeScript, injetando segurança de linguagens compiladas tradicionais.
2. **Frameworks de Última Geração (React e Next.js)**: Construímos as interfaces da *interface user (UI)* a partir de componentes encapsulados e reaproveitáveis.
3. **Data Fetching Preciso**: Para painéis e dashboards que precisam de tempo real, acoplamos *WebSockets*, e o JavaScript cuida de alterar os gráficos em milissegundos, gerando valor operacional na mesma hora em que o dado entra.

### Vantagens Estratégicas Comprovadas
* \`Universalidade\`: Compartilhamento de tipagens e modelos (\`models\`) entre as equipes que criam o aplicativo do cliente e as equipes que alimentam as APIs no servidor. 
* \`Comunidade Imenso\`: Onde surgem padrões incríveis da indústria (Módulos Open Source, Bibliotecas de Machine Learning *TensorFlow.js*).
* \`Baixo tempo de prototipação\`: Redução do *Time-To-Market*. 

### Perguntas Frequentes (FAQ)
**O JavaScript é lento perto do Python ou C++?**
Para I/O (requisições de rede, tráfego de dados, webhooks), ambientes JS como Node.js ou o moderno *Bun* são algumas das tecnologias mais insanas de velozes já vistas. Para processamento bruto de matemática e CPU intensa pura, aí sim outras linguagens levam a melhor.

**Qual a relação de HTML/CSS com JavaScript?**
Se um site fosse um corpo humano, o **HTML** seriam os ossos (estruturação visual), o **CSS** seria a pele e as roupas (o visual esplêndido), e o **JavaScript** seria o sistema nervoso e muscular (reação a um botão, a uma rolagem de cursor).

**Quero aprender mais. Qual curso vocês indicam?**
Comece entendendo a diferença entre código Síncrono e Assíncrono (\`Promises\`, \`async/await\`). Esse conceito muda completamente sua percepção da linguagem.
    `
  },
  python: {
    id: "python",
    title: "Documentação: Python",
    description: "Conheça o Python: a linguagem pragmática que baseou as maiores revoluções da inteligência artificial e domina automações severas no mercado global.",
    content: `
### A Matemática Exata no Formato Certo
Se o JavaScript rege as interfaces que as pessoas enxergam (O mundo *client-side*), o **Python** é o governante silencioso nos porões dos servidores lidando com massas imensuráveis de dados.

Python é uma linguagem de altíssimo nível, cuja imensa popularidade se deve à sua **sintaxe absurdamente pragmática e elegante**. Ler um código escrito em Python é muito semelhante a ler um manual de instrução técnico escrito em inglês nativo. Essa fluidez permite que a pessoa foque em **resolver o problema**, e não em brigar com vírgulas e aspas do compilador.

### Áreas Onde Python é Rei Indispensável
- **Artificial Intelligence (AI) & Machine Learning (ML)**: Das redes neurais profundas do Google Cloud e Gemini, aos sistemas vitais de recomendações no Netflix. Bibliotecas como \`PyTorch\`, \`TensorFlow\` e \`Pandas\` colocaram correntes de ouro no Python neste aspecto. Sem elas o avanço colossal da atualidade não aconteceria.
- **Micro Automações / Scripts Operacionais**: Ferramentas cruciais chamadas de BOTs em sistemas fechados de automações (como chatbots no Telegram/WhatsApp).
- **Raspagem de Dados Estratégica (Web Scraping)**: Como alimentar sua inteligência corporativa buscando centenas de milhares de ofertas da concorrência de madrugada diariamente em paralelo.
- **APIs Sólidas e Robustas**: Django e FastAPI entregam APIs assíncronas e hiper validadas direto de fábrica.

### Python e Automação: O Fator Pedro Oliver Dev
Nossos clientes corporativos sentem a força bruta dessa linguagem quando implementamos o sistema de **Automação B2B (Business-to-Business)** projetado por Pedro Oliver Dev.

Um exemplo prático de onde utilizamos Python: **Extração e Tratamento em Massa**.
O cliente possui planilhas bagunçadas, relatórios em PDF de bancos federais e bases CSV geradas num sistema antigo da década de 90. Nosso código em Python captura isso, cruza em memória (com algoritmos de baixa eficiência O(N)), limpa as falhas estruturais, padroniza as *labels* e alimenta diretamente o novo banco de dados limpo do cliente sem nenhuma intervenção mecânica humana.

Isso significa centenas de horas operacionais recuperadas usando linhas de código focadas em tarefas específicas (os *worker-dynos*).

### Benefícios no Ciclo de Vida do Negócio
- \`Expressividade\`: Códigos mais simples geram sistemas mais simples. Sistemas simples são mais fáceis e baratos de se escalar e corrigir no futuro (redução do débito técnico).
- \`Ciência de Dados Unificada\`: Quando um projeto precisa escalar as métricas para cruzar Inteligência Artificial Preditiva (Estatística profunda), a equipe de *dev* não precisará trocar as ferramentas.
    `
  },
  html: {
    id: "html",
    title: "Semântica Oculta: HTML e CSS",
    description: "A essência inquebrável. HTML semanticamente robusto acoplado à engenharia CSS moderna é o que garante sites ultrarrápidos e perfeitamente indexados no Google.",
    content: `
### Desmitificando as Camadas de Base da Web
É fácil perder a grandiosidade perante Reacts ou APIs robustas baseadas em GraphQL e Python, mas seria um tremendo erro subestimar o verdadeiro idioma base dos navegadores globais: o **HTML (Linguagem de Marcação de Hipertexto)** combinado com seu irmão fraterno **CSS (Folhas de Estilo em Cascata)**. 

Um HTML não é um código programável. Ele é um arquiteto mestre desenhando uma malha para robôs interpretarem onde está um rodapé seguro, um cabeçalho e um botão crítico.

### Por que Pedro Oliver Dev leva HTML tão a sério?

Diferente de muitas agências da internet que entregam tudo com bases HTML geradas artificialmente (causando sites pesados e travados), levamos a métrica de semântica web às últimas consequências.

#### 1. A11y: A Acessibilidade em Primeiro Lugar
\`Acessibilidade Web\` significa programar também para deficientes visuais. Usamos os atributos ARIA corretos \`(aria-label)\`, respeitamos hierarquia pesada de \`h1\`, \`h2\`, \`h3\` (um H1 a todo custo não deve ser usado como "fonte grande") e garantimos navegação natural por Teclado \`(focus-visible e tab-index corretos)\` para todos os botões modais que criamos. 

#### 2. SEO (Motor de Otimização e Busca) Orgânico
Acreditamos que pagar milhares de dólares em anúncios é tolice se a base é esburacada. Um robô da Google não enxerga a "beleza de um botão no CSS", ele lê as *tags semânticas*. O código gerado é preparado utilizando marcadores de meta e Graph-tags que entregam as novidades perfeitas em segundos.

### Engenharia com CSS (Tailwind, nosso motor chefe)
Utilizamos **Tailwind CSS**, a fantástica tecnologia de classes focadas com variáveis CSS rigorosas de sistema (Design Tokens). 

Não há espaços, não há regras inventadas por programadores desesperados ao meio-dia. Cada arredondamento de card, cada \`blur(20px)\`, e as animações das sombras pulsantes do estilo Dark-Mode da marca são desenhados sistemicamente. Um *Design System* garante escalabilidade para nossos clientes empresariais expandirem suas aplicações com garantia infinita de harmonia visual e performance extrema do código rodando nas máquinas do usuário (baixo *layout-shift*).
    `
  },
  "pedro-oliver-dev": {
    id: "pedro-oliver-dev",
    title: "Manifesto: Sobre Pedro Oliver Dev",
    description: "Nós transmutamos necessidades operacionais em ecossistemas de software robustos. A excelência no *Craft* da programação sob demanda.",
    content: `
### Mais do que 'Apenas um Site'
O portal de **Pedro Oliver Dev** nasceu a partir da necessidade de unir duas extremidades da tecnologia que raramente convergem nos prestadores habituais do mercado: A *Estética Sublime Invejável* versus A *Arquitetura Operacional à Prova de Falhas*.

Não faturamos criando templates e hospedadores engessados de 20 dólares no final de semana; não fazemos "site no Wix para a padaria da esquina". Nós focamos nossa atenção, intelecto e maestria tática em clientes estruturais.

### O Modelo Tecnológico e Nossos Clientes Corporativos
Quando grandes ideias encontram amarras em sistemas mal trabalhados e planilhas instáveis, surge a oportunidade ideal de intervir na logística da operação.
Oferecemos:

- **Sistemas Administrativos Focados (Dashboards Analíticos)**: Cruzadores de Big Data visuais rápidos como um videogame e intuitivos como um aplicativo local.
- **Arquitetura Orientada a Bots B2B**: Orquestradores nos canais de comunicação com as integrações que sua empresa necessita (Bancos em nuvem, Stripe para faturas massivas e processamentos assíncronos no servidor).
- **Identidade de Alta Perfomance Web**: Aplicações (Sites SPA / React + APIs robustas e protegidas contra DDOS) de performance latente onde milissegundos convertem em vendas institucionais de alto-nível (*High Ticket* e *B2C Scale*).

### Nossas Diretrizes Inquebráveis
#### 1. Tolerância Zero com a Lata de Lixo Semântica (Tech Slop)
Detestamos jargões usados em demasia apenas por modismo comercial, painéis inúteis repletos de "tabelas falsas de TI" espalhados pelas pontas do site ou recursos escondidos e complicados (Dark Patterns). Construímos **Interface Funcionais** e literais.

#### 2. Transparência na Base (Open Source Vibe)
Seus códigos não estão mortos nos nossos fundos. Desenvolvemos com as tecnologias gigantes abraçadas massivamente pela engenharia livre moderna (Ecossistema Open Source JavaScript/Node e Python Global). Isso blinda nossos compradores contra os chamados "Vendedores Exclusivos Secretos", mantendo sua arquitetura saudável e com acesso a manutenção vitalícia com qualquer grande programador global do mercado.

#### 3. UX Minimalista, Design Impecável e Premium.
O design só funciona quando removemos até onde nada mais precisa sair. As linhas limpas, navegação por teclado elegante e tema-escuro padronizado trazem uma aura de luxo corporativo imbatível. A percepção do seu usuário sobre os seus aplicativos determina a confiança transacional. E **nós entregamos confiança empacotada em arquitetura de interface.**
    `
  },
  react: {
    id: "react",
    title: "Aplicações de Performance Extrema: React.js",
    description: "Despedace as UIs. Entenda porque todas as startups modernas, gigantes globais (Netflix, Meta, Airbnb) e Pedro Oliver Dev apostam suas fichas na inteligência modular do React.",
    content: `
### A Filosofia de Componentes e o DOM Virtual
A **Web Antiga** exigia que, a cada nova página solicitada (um painel de configurações, ou a área de meus pedidos de uma loja), a tela entrasse em branco (tela amarela carregando internet no topo) e tudo começasse do zero. Lento, caro nos servidores e quebrava terrivelmente a atenção do cliente.

O **React**, revolucionária livraria criada dentro da gigante *Meta (Facebook)* em 2013, destruiu isso com o conceito do *Virtual DOM*. Modulamos toda a tela visual em pedaços atômicos e avulsos chamados "Componentes". Se alguém apertou o "Curtir", o React apenas atualiza "aquele micro botão de estrela" em milissegundos matematicamente, invés de refazer as 2.000 imagens carregadas embaixo da página.
Resultado: Um aplicativo no navegador *veloz, contínuo* e *sedutor*.

### A Abordagem e Aplicação por Pedro Oliver Dev
Muitos reclamam da "lentidão do React", todavia os mesmos o preenchem com centenas de bibliotecas mortas sem utilidade na raiz da árvore de dependências.

Nós praticamos programação minimalista, com pacotes selecionados a dedo e forte integração do React + Componentes de Server-Side.
Entregamos animações *framerate 60FPS fluidas*, gráficos interativos e botões magnéticos; tudo arquitetado sobre um padrão sólido de TypeScript React (TSX).

- **Ecossistema Escalável**: Em 1 click de código limpo, é imensurável a facilidade para re-arranjar componentes. "Mudar um campo X para a tela secundária". Com Pedro Oliver Dev, isso não demora uma semana, pode ser feito eficientemente.
- **Design System Coeso**: Você nunca verá "2 tipos de bordas nos nossos aplicativos complexos". Construímos *UI-Kits* que importam os mesmos botões de tipografia.
    `
  },
  apis: {
    id: "apis",
    title: "Interfaces e Integrações: O que são APIs?",
    description: "Os canos centrais da informação que interligam os serviços e bancos de dados isolados dentro e fora de sua empresa.",
    content: `
### Os Mensageiros da Engenharia (Application Programming Interface)
Imagine que sua empresa fizesse emissão de Notas Fiscais Nacionais, cobrasse no Cartão de Crédito gringo Stripe, informasse o cliente por mensagens automatizadas nativas no WhatsApp enquanto manda dados vitais ao estoque interno da Amazon Web Services (AWS). Fazer tudo isso à mão na tela ou via arquivos gigantes demoraria meses.

**As APIs resolvem as amarras corporativas.** É uma ponte (normalmente usando tecnologia superleve REST ou GraphQL enviando arquivos JSON microscópicos de dezenas de caracteres) onde um sistema manda a ordem bruta ao outro. Quando o cliente compra o ingresso e recebe o Ticket na mesma fração de segundos? As APIs efetuaram 35 transações simultâneas em segurança sem os humanos saberem.

### Por que Investir em Robustez
Sistemas fortes devem ser fechados contra os perigos e abertos de maneira hipercontrolada aos seus clientes e terceiriza. Exemplo prático da "Ação": A Interface da Web é apenas 'uma máscara interativa', mas a base da API criada por **Pedro Oliver Dev** tem um motor que executa regras de cálculo, confere a legitimidade de permissões de acesso, autenticação e valida antes de mudar dados sensíveis no Banco de Dados Criptografado.

* A API é imortal: Você muda o design inteiro do aplicativo se quiser 10 vezes; tudo continuará servindo perfeitamente dados reais porque a API isolada está operando imutável nos servidores paralelos.
    `
  },
  sql: {
    id: "sql",
    title: "Engenharia de Dados (SQL & NoSQL)",
    description: "Onde seus dados vitais vivem. Arquitetura de banco de dados e armazenamento altamente disponível.",
    content: `
### O Cofre da Empresa
O aplicativo é a vitrine, a API é a tubulação processadora, e o Banco de Dados é o gigantesco cofre. Com Pedro Oliver Dev, construímos a modelagem de dados para que a busca seja indexada (rápida) e a escrita seja atômica (não corrompa durante quedas de servidor).

Utilizamos principalmente modelagem Relacional **SQL** (PostgreSQL, MySQL) para contextos severos de finanças e estoques, mas abraçamos **NoSQL** e Redis quando a necessidade é um milhão de leituras de cachê por minuto.
    `
  },
  css: {
    id: "css",
    title: "CSS & Design Interativo",
    description: "Arquitetura visual, design systems e interfaces que encantam e convertem.",
    content: `
### A Psicologia Visual
Não escrevemos apenas código CSS; nós desenhamos experiências. O CSS é a linguagem que controla cores, fluxos espaciais, sombras e interações físicas dentro de um aplicativo.

Com Pedro Oliver Dev, alinhamos o CSS com conceitos rigorosos de *Design System*. Utilizando abordagens como o **Tailwind CSS**, eliminamos inconsistências visuais (como dois botões primários de tamanhos diferentes no mesmo aplicativo) e implementamos o "Mobile First". O sistema precisa ficar magnífico num relógio conectável, e expandir gloriosamente numa tela Retina Gigante.
    `
  },
  "node-js": {
    id: "node-js",
    title: "Back-end de Alto Impacto: Node.js",
    description: "Operações corporativas baseadas em eventos, microsserviços e velocidade terminal.",
    content: `
### O JavaScript Envenenado nos Servidores
Quando o JavaScript saiu dos navegadores e entrou nos servidores pelo Node.js, a indústria virou do avesso. O Node utiliza o V8 Engine (O cérebro bruto de processamento construído pelo Google para o Chrome).

Sua capacidade de assincronismo significa que Node.js brilha absurdamente sob estresse corporativo (Milhares de pessoas batendo nos seus servidores perguntando preços simultaneamente, sistemas robustos de chat de atendimento, atualizações em tempo real com WebSockets de Dashboards Financeiros).
    `
  },
  bots: {
    id: "bots",
    title: "Agentes e Bots Customizados",
    description: "Transformando processos manuais repetitivos em tropas de execução em tempo integral.",
    content: `
### Sequestro da Burocracia
Por que manter uma pessoa gastando 4h diárias conferindo planilhas de pagamento? Com Pedro Oliver Dev nós construímos Bots (Automações Independentes por Interface Conversacional) para interceder em seu nome. Seja operando comandos gigantescos via Discord, moderando milhares de pessoas no Telegram, ou gerenciando CRM complexo em servidores corporativos Slack. Eles atuam sem erros, não param no final de semana, não se estressam e são 100% monitoráveis.
    `
  },
  dashboards: {
    id: "dashboards",
    title: "Data e Dashboards Analíticos",
    description: "Centralizando os dados crípticos da sua empresa em painéis elegantes e lógicos que embasam decisões C-Level estratégicas.",
    content: `
### O Radar do Negócio
Ter dados não é ter vantagem. A vantagem vem de conseguir **ler os dados em tempo recorde**. Dashboards desenvolvidos por Pedro Oliver Dev abraçam tipologia focada. Eliminamos ruidos, linhas inúteis e focamos na renderização vetorial com SVG e animações nativas interativas via React. 
Os executivos não esperam "o final do mês" para ver as falhas de faturamento; o sistema os alerta em tempo real.
    `
  },
  run: {
    id: "run",
    title: "Hospedagem & Execução: O Ambiente Run",
    description: "A nuvem moderna e distribuída que mantém seus produtos no ar sob os piores tráfegos.",
    content: `
### A Diferença de um Servidor Robusto
Não configuramos painéis CPanel frívolos e compartilhamos sua segurança. Operamos infraestrutura nativa em nuvem (Containers, Edge Analytics, Clusters Vercel/AWS).

Quando desenvolvemos um software corporativo, o ciclo de "Run" (Deploy) orquestra a aplicação em *Edge Network* globais. Servidores ao redor do mundo armazenam os sites como cópias quase locais, reduzindo a latência para os acessos corporativos independente do estado geográfico do cliente final.
    `
  },
  "sobre-mim": {
    id: "sobre-mim",
    title: "Quem é Pedro Oliver",
    description: "A mente criativa e a engenharia dedicada por trás de Pedro Oliver Dev, forjando a elite do desenvolvimento.",
    content: `
### Minha Essência Dev
Como **Pedro Oliver Dev**, acredito que a engenharia de software de elite é pessoal. Por trás de toda grande estrutura há programadores obstinados, arquitetos de dados focados e designers rigorosos com a estética.

Atuamos de forma a alinhar cada linha de código com os propósitos estratégicos da sua empresa. Evitamos o intermediário burocrático, permitindo conversas fluidas diretamente com nossos engenheiros de software seniores.

### Nosso Fundamento
Criamos soluções robustas com o menor atraso tecnológico do mercado. Cuidamos do seu design, da sua base NoSQL, das APIs escaláveis ao deploy do seu bot de forma a blindar sua empresa para novos picos de faturamento.
    `
  },
  servicos: {
    id: "servicos",
    title: "Nossos Serviços Premium",
    description: "Uma prateleira completa e refinada de soluções em software que aprimoram e automatizam suas operações.",
    content: `
### Engenharia Sob Medida
Desenvolvemos softwares com foco estrito em performance e segurança. No nosso catálogo corporativo atuamos principalmente com:

* **Sistemas Administrativos Integrados (Dashboards)**: Painéis com cruzamento inteligente de bancos e tempo real.
* **Agentes de Automação Independente**: Bots dedicados criados sob medida para interagir em Discord, Telegram, Slack ou Whatsapp de forma a reduzir sua folha operacional.
* **Aplicações Web de Performance Extrema (React SPAs)**: Sites rápidos com otimizações profundas que surpreendem o usuário.
* **APIs Seguras & Robustas**: Arquitetura orientada a serviços integrando múltiplos softwares da sua organização (Stripe, CRMs, etc.).
    `
  },
  portfolio: {
    id: "portfolio",
    title: "Portfólio & Cases de Excelência",
    description: "Confira cases selecionados onde transmutamos negócios através de código e inteligência digital.",
    content: `
### Sucesso Comprovado no Mundo Real
Nossos projetos não são fictícios. Desenvolvemos soluções implementadas e validadas por empresas líderes e marcas que operam 24/7 de forma ininterrupta.

Exibimos orgulhosamente:
- **Painéis Financeiros**: Com gestão em tempo de execução de faturas e processamentos fiscais simulados em segundos.
- **Ecossistema Discord para Empresas**: Bots de triagem rápida de atendimento integrados a CRMs internos que guiam o novo usuário pelas ofertas.
- **Portfólios Institucionais Premium**: Marcas que exigiam estética e transições de tela fluidas que causam inveja mercadológica.
    `
  },
  automacoes: {
    id: "automacoes",
    title: "Sistemas & Automações Robóticas B2B",
    description: "Sua folha corporativa mais eficiente com exércitos silenciosos trabalhando ininterruptamente.",
    content: `
### Elimine a Burocracia Mecânica
Passar horas diárias copiando linhas de planilhas para e-mails ou atualizando estoque à mão é uma falha operacional dispendiosa.

Desenvolvemos **Workers digitais em Python e Node** que lidam com web scraping preciso, sincronização de bancos, webhooks customizados e bots que operam em canais de comunicação para sanar instantaneamente dúvidas comuns de suporte ou converter possíveis clientes sem exigir repetição humana.
    `
  },
  "central-de-ajuda": {
    id: "central-de-ajuda",
    title: "Central de Ajuda Pedro Oliver Dev",
    description: "O canal dedicado para você solucionar rapidamente suas dúvidas institucionais ou de contratos técnicos.",
    content: `
### Autoatendimento de Elite
Seja bem-vindo ao suporte de Pedro Oliver Dev. Para acelerar suas respostas, estruturamos respostas rápidas para dúvidas comuns:

- **Como faço para alterar meu contrato de SLA?** Entre em contato pelo e-mail oficial anexando sua proposta de requisição.
- **Onde vejo minhas faturas enviadas?** Elas chegam diretamente de forma criptografada pelo gateway Stripe no seu e-mail cadastrado.
- **Vocês fornecem documentação local?** Toda entrega de sistema acompanha documentação restrita com tutoriais do administrador.
    `
  },
  atualizacoes: {
    id: "atualizacoes",
    title: "Mural de Atualizações e Changelog",
    description: "Mantenha-se informado sobre as últimas otimizações e melhorias lançadas na plataforma e serviços.",
    content: `
### Evolução Constante
Não paramos de codar. Acompanhe nossas últimas conquistas:

#### v2.4.0 (Q2 2026)
- **Melhoria Absurda na Busca**: Adicionado suporte inteligente a teclados e categorias expandidas no site de Pedro Oliver Dev.
- **Performance de Imagem**: Implementação completa de Lazy Loading e indexação WebP estrita.
- **SEO Otimizado**: Estruturação semântica do layout para indexação perfeita do Google Search.
    `
  },
  "guias-tutoriais": {
    id: "guias-tutoriais",
    title: "Guias Técnicos & Tutoriais",
    description: "Instruções didáticas e focadas prontas para sua equipe operar ferramentas como bots e APIs.",
    content: `
### Conhecimento Compartilhado
Explore nossos guias estruturados e didáticos:

1. **Guia de Integração com APIs de Pedro Oliver Dev**: Entenda as chamadas POST e cabeçalhos Authorization de forma a proteger suas chaves de API secretas.
2. **Como configurar webhooks no Discord**: Ajuste endpoints para receber atualizações do servidor com segurança de dados.
3. **Escala de Contêineres no Docker**: Melhores táticas de isolamento para evitar vazamento de memória.
    `
  },
  blog: {
    id: "blog",
    title: "Blog & Tendências de Tecnologia",
    description: "Nossos insights profundos sobre o rumo do mercado de software, cloud computing e design corporativo.",
    content: `
### O Segredo das Agências Rápidas
Por que startups preferem arquiteturas Headless e linguagens nativas a templates estáticos prontos? A resposta repousa no **debito técnico de longo prazo**. 

No nosso blog compartilhamos artigos sobre a importância de possuir códigos limpos (Clean Arch), o impacto assíncrono do Node.js nos servidores, e por que a tipagem estrita de TypeScript salva sua empresa de erros catastróficos aos domingos.
    `
  },
  "termos-uso": {
    id: "termos-uso",
    title: "Termos de Uso de Pedro Oliver Dev",
    description: "Delineamento claro das regras de uso aplicadas aos nossos portais e ferramentas corporativas.",
    content: `
### Regras de Engajamento Técnico
Este site e os serviços integrados de Pedro Oliver Dev são oferecidos sob aceitação contratual estrita. Ao utilizar nossos portais, você concorda em:

- Não utilizar as ferramentas para mineração maliciosa de dados, scraper abusivo de APIs ou atividades fraudulentas.
- Manter segredo profissional absoluto em relação às chaves de API particulares e documentações entregues pelo estúdio em caráter restrito.
- Respeitar a propriedade intelectual das marcas, códigos fontes proprietários de biblioteca de componentes construídos sobre demanda.
    `
  },
  "politica-privacidade": {
    id: "politica-privacidade",
    title: "Política de Privacidade e Proteção",
    description: "Nossos compromissos rigorosos no cumprimento da LGPD e segurança cibernética dos seus dados.",
    content: `
### Sua Privacidade Blindada
Na Pedro Oliver Dev, privacidade não é um bônus: é a nossa fundação constitucional. Levamos a regulamentação **LGPD (Lei Geral de Proteção de Dados)** às últimas consequências:

- **Não vendemos** ou transacionamos seus dados com corretores ou bancos terceiros.
- **Total Transparência**: Você pode requisitar a exclusão definitiva dos seus dados de atendimento e registros com 1 clique.
- **Segurança de Servidor**: Toda comunicação com nossas APIs transita via protocolo criptografado TLS 1.3 de ponta a ponta.
    `
  },
  "politica-cookies": {
    id: "politica-cookies",
    title: "Política de Cookies e Navegabilidade",
    description: "Informações sobre como pequenas preferências salvas em cookies simplificam seu uso diário.",
    content: `
### Cookies Necessários de Preferência
Utilizamos cookies estritamente dedicados de forma transparente para:

1. **Persistência de Idioma e Tema**: Manter a escolha de tema escuro ou claro salva no seu computador.
2. **Identificação de Token de Sessão**: Garantir segurança enquanto você navega pelas áreas protegidas por senha da nossa API ou painel.
3. **Métricas de Performance**: Logs anônimos de velocidade para diagnosticarmos trechos lentos da plataforma de forma cega.
    `
  },
  recursos: {
    id: "recursos",
    title: "Centro de Recursos Técnicos",
    description: "Documentos, e-books, kits de design e ferramentas adicionais fornecidas por Pedro Oliver Dev.",
    content: `
### Recursos Operacionais para Crescimento
Facilitamos o cotidiano dos nossos parceiros empresariais oferecendo um centro integrado de recursos:

- **Modelo de Briefing para Desenvolvimento**: Estruture os pré-requisitos lógicos do seu sistema para orçamentos perfeitos.
- **Kit de Boas Práticas de UI/UX**: Um guia rápido com referências sobre contrastes de tipografias e espaçamentos simétricos.
- **Coleção de Exemplos em Node**: Scripts simples para acoplar no backend de faturamento.
    `
  },
  seguranca: {
    id: "seguranca",
    title: "Segurança de Nível Corporativo (Security)",
    description: "Criptografamos, auditamos e enclausuramos nossos serviços para resistir a invasões cibernéticas com folga.",
    content: `
### Sistemas Invasíveis Não São Sistemas
Um design deslumbrante não evita prejuízos de segurança. Com Pedro Oliver Dev não tratamos segurança como perfumaria secundária:

- **Isolamento de Contêineres**: Cada aplicação orquestrada em nosso ecossistema opera em *Sandboxing* estrito, evitando que falhas de vizinhos interceptem seu banco de dados.
- **Validação Anti-Injeção**: Filtros de sanitização de inputs em todas as rotas de API contra ataques SQL injection e vírus cross-site (XSS).
- **Criptografia Simétrica**: Dados estratégicos e senhas são encriptados usando funções hash rigorosas como \`bcrypt\` de alto custo de computação.
    `
  },
  performance: {
    id: "performance",
    title: "Performance Extrema: Menos de 100ms",
    description: "A obsessão por rapidez que converte visitantes passivos em compradores em milissegundos.",
    content: `
### Velocidade que Gera Lucro
Um site lento que demora mais de 3 segundos para carregar perde até **40% de conversão imediata**. 

Nossas técnicas de melhorias incluem:
- **Redução de Ativos (Minification)**: Compactamos todo JavaScript e CSS em pacotes minúsculos que carregam velozmente na rede móvel mais fraca.
- **Lazy Loading Progressivo**: Imagens e códigos secundários só são interpretados quando entram no campo de visão do olho humano.
- **Edge Deployment**: O projeto é servido instantaneamente de dezenas de datacenters distribuídos proximamente da localidade do seu cliente.
    `
  },
  tecnologias: {
    id: "tecnologias",
    title: "Tecnologias de Elite no Ecossistema",
    description: "Uma imersão nas escolhas de linguagens, frameworks e bancos de dados que guiam nosso laboratório de software.",
    content: `
### Escolhas Inteligentes de Engenhos
Na Pedro Oliver Dev recusamos dependências obsoletas. Adotamos os motores mais respeitados da engenharia atual para as soluções:

- **JavaScript / TypeScript (Front-end imersivo)**: Para interfaces que não recarregam com React.
- **Python (Processamento pesado)**: Automação cirúrgica de dados e engenharia com Inteligência Artificial.
- **NodeJS / Express (Back-end ágil)**: APIs de alta vazão preparadas para responder volumes absurdos de buscas em paralelo.
- **PostgreSQL / Redis (Bancos resilientes)**: O cofre ideal com persistência correta e cache instantâneo de faturamento.
    `
  },
  status: {
    id: "status",
    title: "Status dos Sistemas de Pedro Oliver Dev",
    description: "Nossos painéis públicos de monitoramento das APIs, bots e integridade dos servidores na nuvem.",
    content: `
### Transparência na Operação (Uptime: 99.98%)
Acompanhe em tempo real a saúde do nosso ecossistema:

* **API Geral (REST / GraphQL)**:   \`● OPERANDO NORMALMENTE\` (Uptime 99.99%)
* **Ambiente Hospedagem Run**:    \`● OPERANDO NORMALMENTE\` (Uptime 99.97%)
* **Bancos de Dados Próprios**:   \`● OPERANDO NORMALMENTE\` (Uptime 100%)
* **Bots de Suporte Integrados**: \`● OPERANDO NORMALMENTE\` (Uptime 99.95%)

Caso ocorra um pico de quedas, nossos engenheiros são notificados por SMS e Discord redundantes em até 45 segundos para correções proativas.
    `
  },
  parcerias: {
    id: "parcerias",
    title: "Programa de Parcerias Corporativas",
    description: "Estúdios de design, consultorias de TI e agências de marketing crescendo juntos com Pedro Oliver Dev.",
    content: `
### Cresça Com o Apoio de Pedro Oliver Dev
Desenvolvemos parcerias de alta sinergia onde nosso laboratório de software de altíssimo nível atua como a espinha dorsal de engenharia para agências e consultores que preferem focar no atendimento e estratégias institucionais:

- **White-Label Premium**: Construímos o código, entregamos de forma limpa, e você revende sob a embalagem da sua agência com total amparo mercadológico.
- **Comissionamento Justo**: Indique clientes complexos necessitando de bots, dashboards e APIs sob medida e colha dividendos expressivos.
- **Amparo Técnico Dedicado**: Um canal direto de dúvidas no Discord para seu designer alinhar contrastes e comportamentos técnicos complexos.
    `
  },
  "discord-bots": {
    id: "discord-bots",
    title: "Desenvolvimento de Bots para Discord",
    description: "Bots customizados, eficientes e integrados para automação de canais e suporte no Discord.",
    content: `
### O Discord Como Central de Comando
Muitas empresas utilizam o Discord para centralizar suporte, notificações e controle operacional de equipes. Com Pedro Oliver Dev, construímos bots que interagem nativamente com APIs internas, automatizam triagens, processam compras em canais privados e sincronizam dados.
    `
  },
  "square-cloud": {
    id: "square-cloud",
    title: "Square Cloud: Hospedagem Simples e Estável",
    description: "Hospede seus microsserviços, APIs e bots na melhor e mais elogiada nuvem de deploy rápido do país.",
    content: `
### Agilidade Operacional Extrema
A Square Cloud destaca-se pela ausência de barreiras na infraestrutura. Com uma CLI potente e logs fluidos em tempo de execução, fornece o abrigo perfeito para bots JavaScript/Python, automações pontuais e protótipos avançados.
    `
  },
  hospedagem: {
    id: "hospedagem",
    title: "Servidores & Hospedagem na Nuvem",
    description: "Onde o seu site mora. Escolhas excelentes de servidores com redundância global para seu negócio.",
    content: `
### Confiabilidade Total de Redes
Hospedar software corporativo requer segurança, baixo ping e proteção severa contra ataques cibernéticos em massa (DDoS). Escolhemos integradores e data centers de ponta com edge delivery para manter sua estrutura ágil, fria e barata ao final do mês.
    `
  },
  "desenvolvimento-web": {
    id: "desenvolvimento-web",
    title: "Desenvolvimento Web Profissional",
    description: "Erguemos plataformas de alta escalabilidade com foco em usabilidade exemplar e conversão corporativa.",
    content: `
### A Web Sem Barreiras
Construímos portais e sistemas unindo estética espetacular e código otimizado. Suas páginas carregam com velocidade, os links operam fluídos e o usuário navega sem poluição ou atritos desnecessários no funil de vendas.
    `
  },
  "front-end": {
    id: "front-end",
    title: "Engenharia de Front-end",
    description: "Transformando design estático em código estonteante, fluído e com layouts responsivos.",
    content: `
### A Máscara Interativa da Tecnologia
Nosso front-end modular com TypeScript e React.js dá dinâmica aos componentes. Cada clique de botão reage na mesma hora, animações guiam o foco mecânico do olho e os pacotes são otimizados ao limite para economizar rede móvel do usuário final.
    `
  },
  "back-end": {
    id: "back-end",
    title: "Engenharia de Back-end & APIs",
    description: "A força bruta oculta que rege as regras do seu negócio e armazena informações críticas.",
    content: `
### Processamentos Invisíveis e Seguros
Tratam-se das engrenagens invisíveis: servidores que se auto-escalam, tratamento matemático exato de relatórios fiscais, validação profunda de credenciais de login e distribuição veloz de dados com banco PostgreSQL altamente performático.
    `
  },
  "ui-ux": {
    id: "ui-ux",
    title: "Design de Interfaces (UI/UX)",
    description: "A ciência do comportamento humano alinhada com layout minimalista para encantar clientes.",
    content: `
### Menos é Absurdamente Mais
Estética sem utilidade é desperdício. Desenhamos diagramas visuais focados na facilidade de uso diário. Botões com boa área de toque (zona de conforto no polegar), contrastes perfeitos de tipografia e transições de páginas sem cortes bruscos.
    `
  },
  seo: {
    id: "seo",
    title: "SEO (Search Engine Optimization)",
    description: "Apareça nas primeiras páginas do Google sem gastar fortunas de dinheiro público ou privado em Ads.",
    content: `
### O robô do Google Adora Pedro Oliver
Nós praticamos SEO semântico na raiz do HTML. Nossos códigos usam as tags estruturais corretas, metadados bem dispostos e alto índice de aprovação nas ferramentas de audições como Google Lighthouse de velocidade de renderização primária.
    `
  },
  "seguranca-digital": {
    id: "seguranca-digital",
    title: "Segurança Digital & Criptografia",
    description: "Blindando APIs corporativas, bancos de dados confidenciais e conexões remotas de faturamento.",
    content: `
### Prevenir Para Nunca Lamentar
Configuramos firewalls restritivos contra spammers de requisições, chaves criptografas SSL/TLS e códigos com validação restrita de tokens (JWT), assegurando que o caixa financeiro e bancos do usuário fiquem protegidos o tempo inteiro.
    `
  },
  otimizacao: {
    id: "otimizacao",
    title: "Otimização de Sites & Carregamentos",
    description: "Redução drástica de scripts para websites carregarem em menos de um sopro de segundo.",
    content: `
### Acelerando Suas Páginas ao Extremo
Análise de bundles, substituição de SVGs pesados por vetores otimizados, e compressão WebP de imagens em cache de nuvem. Seus aplicativos e painéis operam velozes em celulares modestos ou conexões lentas de trânsito de forma estável.
    `
  }
};
