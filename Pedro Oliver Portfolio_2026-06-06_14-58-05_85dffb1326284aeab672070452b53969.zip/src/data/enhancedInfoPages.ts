import { InfoPageType } from '../types';
import { infoPages as originalPages } from './infoPages';
import { newPages } from './newContent';

const enhancedJavascript = `
### O que é o JavaScript?
O **JavaScript (JS)** é a linguagem universal da internet. Lançado como um simples script, hoje impulsiona sistemas complexos no frontend e backend.

### Para que serve?
Ele serve para criar interatividade, gerenciar dados, animar páginas e estruturar backends robustos usando Node.js.

### Onde é usada?
* Aplicações Web (SPAs como Netflix e Spotify).
* Aplicativos Mobile (React Native).
* Servidores (Node.js, Deno).
* Machine Learning no navegador (TensorFlow.js).

### Principais Vantagens
* **Assincronismo Não Bloqueante**: Graças ao Event Loop.
* **Ecossistema Gigante**: NPM é o maior repositório de pacotes do mundo.
* **Onipresente**: Roda em qualquer dispositivo com um navegador.

### Exemplos de Uso e Aplicações Reais
* Um painel B2B financeiro atualizando cotações em tempo real.
* Uma PWA (Progressive Web App) que funciona offline na área rural.

### Nível de Dificuldade
**Intermediário a Avançado** - É fácil iniciar, mas sua natureza assíncrona, prototipagem e tipagem dinâmica exigem disciplina para o domínio real (geralmente alcançada via TypeScript).

### Boas Práticas
* Sempre use TypeScript para grandes projetos.
* Evite poluir o contexto global.
* Extraia lógicas de domínio para fora dos componentes de renderização.

### Curiosidades
Foi criado em apenas 10 dias por Brendan Eich em 1995.

### Ferramentas Recomendadas
* **VS Code** (Editor oficial da web moderna).
* **Vite** (Build tool ultra rápido).
* **Biome/ESLint** (Linters e formatadores).

### Documentação e Tutoriais Relacionados
* [MDN Web Docs (Oficial)](https://developer.mozilla.org/pt-BR/docs/Web/JavaScript)
* [Tutorial: React Hooks no Pedro Oliver Dev](/articles/tutorial-react-hooks)
`;

const enhancedHtml = `
### O que é a tecnologia?
HTML (HyperText Markup Language) é a espinha dorsal de toda a web. Não é uma linguagem de programação, mas de marcação, projetada para fornecer estrutura e significado semântico ao conteúdo na internet.

### Para que serve?
Ele define cabeçalhos, parágrafos, botões, formulários e divisões. O HTML traduz dados brutos em uma interface documentada interpretável pelo navegador.

### Onde é usada?
Literalmente 100% dos sites, web apps e plataformas hospedadas na internet pública usam HTML por baixo dos panos.

### Principais Vantagens
* **Fundação Perfeita**: Sem um bom HTML, nenhum JavaScript resolve problemas de estrutura.
* **SEO Aprimorado**: O Google lê suas tags H1, H2 e Main para indexar.
* **Acessibilidade**: Leitores de tela para deficientes visuais dependem de tags corretas.

### Aplicações Reais e Nível de Dificuldade
**Nível: Iniciante.** 
Aplica-se a tudo, de um simples blog estático às páginas do Instagram.

### Boas Práticas e Curiosidades
* Use \`<button>\` para ações e \`<a>\` para navegação. Nunca misture os dois conceitualmente!
* HTML5 não requer mais o uso exclusivo da tag div, prefira semântica.
* Sir Tim Berners-Lee o inventou em 1991 no CERN.

### Ferramentas
* **axe DevTools** (para testes de acessibilidade).
* **W3C Validator**.
`;

const enhancedPython = `
### O que é Python?
Python é uma linguagem multiparadigma, de alto nível e amplamente adorada por sua sintaxe extremamente limpa e legível, semelhante ao inglês estruturado.

### Para que serve e Onde é Usada?
Serve primariamente para: Inteligência Artificial (Machine Learning e Deep Learning), automações, web scraping, Data Science e backends de alta complexidade. Usada no Instagram, Netflix, NASA e instituições financeiras.

### Principais Vantagens
* Leitura impecável que reduz custos de manutenção.
* Maior ecossistema global para IA e Dados (Pandas, Numpy, PyTorch, TensorFlow).
* Integração rápida (FastAPI, Django).

### Exemplos e Dificuldade
**Nível: Iniciante/Intermediário**. 
É fantástica para aprender a programar, mas leva anos para dominar a performance de concorrência algorítmica.

### Dicas e Curiosidades
* O nome não tem nada a ver com a cobra, mas com a trupe de comédia "Monty Python".
* Prefira usar ambientes isolados (VENVs) em todo projeto.

### Ferramentas e Docs
* PyCharm e Jupyter Notebooks.
* Documentação Oficial: docs.python.org.
`;

const enhancedRun = `
### O que é Ronu/RunOS?
O Google Cloud Run (ou plataformas containerizadas serverless) é uma máquina de guerra moderna para deploy de código que compila e ignora os limites das VMs tradicionais.

### Para que serve?
Serve para rodar qualquer contêiner web stateless (sem estado interno permanente) com faturamento por milissegundo e auto escalabilidade que vai de zero a dezenas de milhares de acessos em 1 segundo.

### Principais Vantagens
* Concorrência: Uma instância aguenta 100 a 1000 requisições simultâneas.
* Escalonamento para Zero: Não paga nada de madrugada se ninguém entrar.
* Injeção de variáveis segura.

### Nível de Dificuldade
**Intermediário.** Exige entender minimamente de Docker e redes HTTP.
`;

export const enhancedDescriptions: Record<string, string> = {
  javascript: enhancedJavascript,
  html: enhancedHtml,
  python: enhancedPython,
  run: enhancedRun,
};

// Add enhanced items over original infoPages
export const mergedInfoPages = { ...originalPages };

Object.keys(enhancedDescriptions).forEach(key => {
  if (mergedInfoPages[key]) {
    mergedInfoPages[key].content = enhancedDescriptions[key];
  }
});

// Add new modular pages from newContent.ts
newPages.forEach(page => {
  mergedInfoPages[page.id] = page;
});
