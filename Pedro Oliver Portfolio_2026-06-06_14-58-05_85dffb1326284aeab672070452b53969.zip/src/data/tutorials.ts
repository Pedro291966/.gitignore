import { Article } from './articles';

export const tutorialsData: Article[] = [
  {
    id: 'tutorial-html-semantic',
    date: '20 Mai 2024',
    category: 'HTML',
    title: 'Dominando o HTML5 Semântico em 2024',
    excerpt: 'Um tutorial completo passo a passo sobre como estruturar páginas web utilizando as melhores tags do HTML5 moderno.',
    image: 'https://images.unsplash.com/photo-1618477388954-7852f32655ec?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `# Introdução ao HTML Semântico
    
Escrever HTML corretamente é mais do que fazer a página "aparecer". É enviar os sinais corretos para leitores de tela e robôs de busca.

## Estrutura Básica

Utilize \`<main>\`, \`<header>\`, \`<footer>\` e \`<article>\` em vez de divs genéricas.

## Por que isso importa?
- **Acessibilidade**: Leitores de tela conseguem pular para navegar facilmente pelas seções.
- **SEO**: O Google consegue identificar a área mais importante do site.

## Erros Comuns
Muita gente usa \`<div>\` para tudo. Esse é o erro conhecido como "div soup" ou sopa de divs. Utilize as tags corretas sempre que possível!

## Conclusão
Seja semântico em seus códigos HTML para melhor indexação e acessibilidade.`,
    tags: ['HTML', 'SEO', 'Acessibilidade'],
    readTime: '8 min de leitura'
  },
  {
    id: 'tutorial-python-api',
    date: '21 Mai 2024',
    category: 'Python',
    title: 'Criando sua primeira API em Python com FastAPI',
    excerpt: 'Aprenda a construir uma API de alta performance em menos de 5 minutos.',
    image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bfce8?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `# Por que FastAPI?

FastAPI se tornou a escolha número #1 de desenvolvedores Python por sua velocidade absurda (comparável com Go e Node.js) e sua integração nativa com Pydantic para validação de tipos.

## Instalação
Basta usar \`pip install fastapi uvicorn\`

## Criando a Rota

Com apenas 5 linhas você tem sua API no ar pronta para receber tráfego pesado.

## Conclusão
O ecossistema Python nunca esteve tão bem provido de ferramentas de backend. FastAPI é o futuro!`,
    tags: ['Python', 'FastAPI', 'Backend'],
    readTime: '5 min de leitura'
  }
];
