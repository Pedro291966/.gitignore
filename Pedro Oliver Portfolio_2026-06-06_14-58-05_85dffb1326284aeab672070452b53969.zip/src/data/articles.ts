export interface Article {
  id: string;
  date: string;
  category: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  tags?: string[];
  readTime?: string;
  author?: string;
}

import { tutorialsData } from "./tutorials";
import { expandedArticles } from "./newArticles";

export const articlesData: Article[] = [
  ...expandedArticles,
  ...tutorialsData,

  {
    id: 'spa-vs-ssr',
    date: '20 Mai 2024',
    category: 'Arquitetura',
    title: 'Por que abandonamos SPAs tradicionais para e-commerce',
    excerpt: 'Como a migração para Server Components e Next.js reduziu nosso TTI em 40% e resolveu problemas crônicos de SEO que mantinham nossos devs acordados à noite.',
    image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `Existem cenários em que Single Page Applications (SPAs) brilham: dashboards interativos, ferramentas de software (SaaS) e painéis administrativos que exigem estado contínuo na interface.\n\nNo entanto, ao projetar e-commerces e plataformas voltadas para conversão pública agressiva, a arquitetura SPA começa a apresentar seus pontos fracos críticos, principalmente em duas frentes: **Performance Inicial** e **SEO Indexável**.\n\n### O Custo do JavaScript Inicial\nUma SPA envia um enorme pacote de JavaScript vazio antes que a página possa ser processada. O cliente é forçado a fazer o download completo, parse, execução e só então iniciar as buscas na API. Nós observamos nosso Time To Interactive (TTI) inflar para impressionantes 4.2 segundos em redes móveis 3G medianas.\n\n### A Solução: Next.js & Server Components\nAo adotarmos a nova geração do React Server Components (RSC) com Next.js, nós transformamos nosso empacotamento. Renderizamos todo modelo crítico no lado do servidor e enviamos apenas HTML pré-processado para o celular do usuário.\n\n- **TTI reduzido em 40%**: Caímos de 4.2s para 1.7s.\n- **SEO Otimizado**: Os indexadores recebem um HTML semântico recheado de meta-tags.\n- **Páginas dinâmicas cacheadas na Edge**: Resposta global em milissegundos.\n\nA transição não foi isenta de dores, as fronteiras entre \`"use client"\` e \`"use server"\` obrigaram nossos times a revisarem conceitos antigos, mas os resultados financeiros justificaram a decisão.`,
    tags: ['React', 'Next.js', 'SEO', 'Performance'],
    readTime: '6 min de leitura'
  },
  {
    id: 'minimalismo-funcional',
    date: '15 Mai 2024',
    category: 'Design Engineering',
    title: 'A Importância do Minimalismo Funcional em Interfaces SaaS',
    excerpt: 'Por que reduzir elementos visuais não significa reduzir funcionalidades, mas sim destacar o que realmente importa para a conversão de usuários avançados.',
    image: 'https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `O minimalismo na web está frequentemente associado à beleza puramente estética, mas o verdadeiro **minimalismo funcional** é uma técnica de engenharia psicológica. Seu objetivo: limpar o caminho cognitivo do sistema até o objetivo do usuário.\n\n### Form follows Function\nNós desenvolvemos painéis que lidam com milhares de linhas de dados em tempo real. O primeiro instinto de um time júnior é "adicionar cores" para separar. O nosso foi remover toda a cor que não emitisse um sinal de alerta.\n\n- **Preto, Branco e Cinza**: Ao usarmos uma paleta monocromática, garantimos que um botão colorido se torne o centro das atenções instantaneamente.\n- **Gestalt Aplicado**: Usamos espaço em branco como isolamento acústico entre elementos da UI.\n\nReduzimos nossos componentes de interface a menos de 45 primários no Design System corporativo. O tempo de engenharia para aplicar novos layouts caiu absurdamente e os clientes relataram maior foco e agilidade ao usar o software.\n\nO minimalismo funcional não é sobre retirar ferramentas. É sobre dar a elas o espaço necessário para respirarem.`,
    tags: ['UI/UX', 'Design System', 'Acessibilidade'],
    readTime: '4 min de leitura'
  },
  {
    id: 'transicoes-suaves',
    date: '02 Abr 2024',
    category: 'Engenharia',
    title: 'Transições Suaves: Engenharia Por Trás de Animações Fluídas',
    excerpt: 'Explorando os bastidores técnicos e desafios no uso de requestAnimationFrame, Framer Motion e GSAP para entregar performance em plataformas web de alto tráfego a 60fps.',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `Animações costumavam ser a ruína da performance web. Entregar 60 quadros por segundo (fps) requer processamento sob os 16.6ms na Main Thread - onde estilos, pintura e interatividade disputam prioridade.\n\n### O Fim do SetTimeout\nHistoricamente lidávamos com animações através de timers. Hoje utilizamos a API de \`requestAnimationFrame\`. Mais do que isso, nossa equipe padronizou a criação iterativa com as ferramentas **Framer Motion** nas plataformas React e **GSAP** para instâncias WebGL.\n\n### Como garantir estabilidade?\nO segredo está no que você anima:\n1. Anime unicamente propriedades de composição.\n2. **Transform** (translate, scale, rotate) ao invés de top/left/width/height.\n3. **Opacity** ao invés de backgrounds transparentes gerados em runtime.\n\nPromover esses elementos a camadas independentes de GPU com a técnica \`will-change\` foi uma vitória, mas é uma faca de dois gumes; promover itens demais esgota a VRAM do dispositivo do usuário e causa picos de lag repentinos.\n\nNós tratamos a animação não apenas como um toque final, mas como linguagem, guiando a fluência da vista pela interface e confirmando o contato do usuário sem gargalos.`,
    tags: ['Animações', 'Framer Motion', 'Performance'],
    readTime: '5 min de leitura'
  },
  {
    id: 'sindrome-impostor',
    date: '28 Mar 2024',
    category: 'Carreira & Dicas',
    title: 'Síndrome do Impostor: Lidando com a pressão de ser Fullstack',
    excerpt: 'Dúvidas que todo dev tem, mas poucos falam: como equilibrar o aprendizado constante sem se sentir sobrecarregado pelas novas tecnologias e frameworks semanais.',
    image: 'https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `Na busca pelo cargo Fullstack perfeito, criamos uma cultura de ansiedade. Se hoje não dominarmos React, Next, Nest, Postgres, Redis, AWS, Docker e GenAI, sentiremos que ficamos para trás.\n\n### A Verdade do Mercado\nGrandes lideranças de engenharia nas maiores Big Techs do planeta sabem perfeitamente que não há seres humanos que detêm 100% do radar tecnológico.\n\n- **Foco nos Fundamentos**: Um engenheiro que entende os protocolos HTTP, a gestão relacional de estado, algoritmos puros de pesquisa e princípios de SOLID nunca perderá seu valor. Ferramentas como Vite, TurboPack e Deno são ramificações dessas bases universais.\n\n### Práticas Recomendadas\n1. Escolha uma linguagem server (Node/Go/Python) e domine sua camada a fundo antes de pular para outra.\n2. Aprenda por demanda. Você não precisa estudar Kubernetes se não estiver enviando algo escalável e distribuído em produção esta semana.\n\nEsqueça os feeds do X/Twitter tech diários focados no "Amanhã" das bibliotecas recém-lançadas. Foque nos fundamentos do "Ontem" - que regem os sistemas que faturam bilhões "Hoje".`,
    tags: ['Carreira', 'Saúde Mental', 'Estudos'],
    readTime: '4 min de leitura'
  },
  {
    id: 'hooks-assassinos',
    date: '10 Mar 2024',
    category: 'Clean Code',
    title: 'Hooks Assassinos: Como não destruir a performance do React',
    excerpt: 'Padrões comuns que degradam a performance do seu app. Um guia prático sobre dependências do useEffect, re-renders desnecessários e estabilidade de referência.',
    image: 'https://images.unsplash.com/photo-1510915228340-29c85a43dcfe?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `A introdução dos Hooks pelo React alterou fundamentalmente o mindset da construção de componentes para a composição funcional. No entanto, o \`useEffect\` é hoje uma das maiores armadilhas de performance (e bugs de retenção de memória) do front-end.\n\n### O Efeito Cascata (Re-Renders Infinitos)\nUma dependência esquecida, ou um array e objeto recalculados a cada render caindo em um useEffect formam o ciclo mortal que despenca as métricas interativas no Lighthouse:\n\n\`\`\`jsx\n// Um anti-pattern incrivelmente comum\nconst dataOptions = { filter: 'active' }; // Objeto recreado!\n\nuseEffect(() => {\n  loadData(dataOptions);\n}, [dataOptions]);\n\`\`\`\n\nA solução aqui nunca foi varrer o problema para baixo do tapete desativando a regra do ESLint \`exhaustive-deps\`, mas estabilizar a referência através de \`useMemo\` ou elevação estática para fora do escopo funcional.\n\n### Simplificando o Estado\nNossa revisão em auditorias de terceiros revela que 30% a 40% das ocorrências de efeitos em tela são desnecessárias. Frequentemente o estado pode ser simplesmente inferido, ou o "efeito colateral" de envio pode ser ativado diretamente no handler do clique – de onde ele nunca deveria ter saído.\n\nA responsabilidade profissional e a compreensão exata do Ciclo de Vida são suas melhores amarras de segurança.`,
    tags: ['React', 'Hooks', 'Clean Code'],
    readTime: '6 min de leitura'
  },
  {
    id: 'arquitetura-escalavel-aws',
    date: '28 Fev 2024',
    category: 'Engenharia',
    title: 'Arquitetura Serverless em Alta Escala na AWS',
    excerpt: 'Como desenhamos arquiteturas baseadas em eventos utilizando AWS Lambda, SQS e DynamoDB para suportar milhões de requisições com custos controlados.',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `A transição de monólitos implantados em instâncias EC2 para um paradigma totalmente Serverless representa uma das mudanças arquiteturais mais promissoras (e desafiadoras) da engenharia moderna.\n\n### Desacoplando o Core com Event-Driven Architecture\nAo invés de dependências diretas de API via HTTP (onde uma falha paralisa toda a cadeia), introduzimos resiliência através de filas SQS e tópicos SNS. Se o serviço de faturamento cair, a jornada principal de compra continua; o faturamento apenas processará os eventos em atraso quando retornar.\n\n- **Micro-Faturamento**: Cobramos literalmente por milissegundo de execução no AWS Lambda, e somente em caso de uso.\n- **Escalabilidade Transparente**: Um pico de 10 para 100.000 requests quase não necessita intervenção humana, graças a partições bem desenhadas no DynamoDB.\n\n### O Preço Oculto (Cold Starts)\nHá compensações claras. Os temidos *Cold Starts* podem adicionar latência inaceitável a chamadas críticas em tempo real. Soluções como **Provisioned Concurrency** aliviam este sintoma, mas exigem um gerenciamento contínuo para não comprometer a grande vantagem econômica de recursos ociosos zerados.`,
    tags: ['AWS', 'Serverless', 'Arquitetura', 'Backend'],
    readTime: '7 min de leitura'
  },
  {
    id: 'acessibilidade-web-2024',
    date: '12 Fev 2024',
    category: 'Design Engineering',
    title: 'Acessibilidade Não É Opcional: Construindo UIs Inclusivas',
    excerpt: 'Ir além do contraste de cores. Como utilizar atributos ARIA e marcação semântica para criar experiências incrivelmente sólidas e universais.',
    image: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `Ao longo de décadas, métricas de performance focaram na máquina. Hoje, o sucesso da web inclusiva está intimamente ligado na performance entregue para todos os seres humanos, sem exceções.\n\n### A Semântica Salva Vidas\nFalsos botões (fazendo de uma \`div\` um acionador via JavaScript \`onClick\`) destrói a árvore de acessibilidade reportada pelo navegador.\n\n\`\`\`html\n<!-- O Padrão Oculto do Problema -->\n<div class="btn" onClick="submit()">Enviar Formulário</div>\n\n<!-- A Solução Universal -->\n<button type="submit" aria-label="Enviar requerimento de orçamento">Enviar Formulário</button>\n\`\`\`\n\nA ausência total de **Foco de Teclado Consistente** impede a navegação para usuários de mobilidade reduzida.\n\n### Ferramentações Automáticas\nPoucas coisas trazem tanto impacto com tão poucos ajustes do que auditar em ferramentas de lint e Lighthouse desde a fase embrionária do design em Figma até no Pipeline CI/CD com integrações como \`axe-core\`.`,
    tags: ['Acessibilidade', 'HTML Semântico', 'UI'],
    readTime: '5 min de leitura'
  },
  {
    id: 'design-system-tokens',
    date: '05 Jan 2024',
    category: 'Design Engineering',
    title: 'Design Tokens: A ponte entre Figma e Código',
    excerpt: 'Como sincronizar as decisões de design da sua equipe diretamente com o repositório de front-end através da tokenização da sua interface.',
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `Um Design System só é verdeiro se as ferramentas do designer refletem diretamente o que está em produção. Mas como manter dezenas de arquivos CSS atualizados sem intervenção manual toda vez que a cor da marca mudar?\n\n### O conceito de Design Tokens\nDesign Tokens são os "átomos" do seu Design System — pares de chave e valor armazenados agnosticamentes, como em JSON, que representam decisões visuais.\n\nExemplo:\n\`\`\`json\n{\n  "color": {\n    "brand": {\n      "primary": { "value": "#6366f1" }\n    }\n  }\n}\n\`\`\`\n\n### Automação com Style Dictionary\nUsando bibliotecas como Style Dictionary da Amazon, este JSON bruto se transforma automaticamente em variáveis CSS, código Swift para iOS e recursos XML para Android no momento do *build* da sua aplicação.\n\nA verdadeira mágica ocorre ao integrar plugins do Figma que enviam pull requests automáticos no GitHub toda vez que a liderança de design edita a fundação visual do projeto.`,
    tags: ['Design System', 'Figma', 'CSS', 'Automação'],
    readTime: '8 min de leitura'
  },
  {
    id: 'testes-e2e-cypress-playwright',
    date: '10 Dez 2023',
    category: 'Engenharia',
    title: 'Playwright vs Cypress: Uma Batalha pela Confiabilidade',
    excerpt: 'A evolução das ferramentas de testes end-to-end e o motivo de muitas equipes estarem realizando uma migração dolorosa (mas produtiva) para o Playwright.',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80&grayscale=true',
    content: `Escrever testes end-to-end (E2E) sempre foi considerado a parte mais laboriosa do pipeline de qualidade de software, associada principalmente a falsos negativos (flaky tests) e servidores pesados.\n\n### O Legado do Cypress\nO Cypress salvou a web em uma época obscura dominada pelos horrores obscuros de configuração e drivers quebrados do Selenium. Ele trouxe uma interface amigável e uma API síncrona poderosa (embora internamente assíncrona) baseada em uma arquitetura única no próprio navegador.\n\n### A Ascensão do Playwright\nCriada pela Microsoft, o Playwright apareceu prometendo solucionar pontos de dor crônicos deixados pelo sucessor, como a limitação crônica do Cypress para suportar nativamente e simultaneamente navegadores rodando no mesmo teste, iFrames aninhados cruzados com *cross-origins* e execuções realmente paralelas out-of-the-box.\n\nE com uma vantagem matadora: uma ferramenta maravilhosa de \`codegen\` que gera automaticamente os testes baseados simplesmente em nós gravarmos o comportamento humano na tela.\n\nA estabilidade superior ao interceptar a camada de requisições tornou muitos projetos reféns orgulhosos dessa mudança.`,
    tags: ['Testes', 'QA', 'Playwright', 'Cypress'],
    readTime: '7 min de leitura'
  },
  {
    id: 'bots-discord-telegram',
    date: '20 Mai 2026',
    category: 'Sistemas e Automações',
    title: 'Bots Inteligentes: Automatizando Operações e Elevando o Engajamento',
    excerpt: 'Descubra como os agentes e bots integrados a plataformas de comunicação podem se transformar nos melhores assistentes virtuais da sua equipe.',
    image: 'https://images.unsplash.com/photo-1593642532744-d377ab507dc8?auto=format&fit=crop&w=1200&q=80',
    content: `Os bots em comunidades ou operações internas deixaram de ser meros brinquedos de entretenimento para se tornarem peças fundamentais da engenharia de processos. Em serviços como Discord, Telegram, Slack e plataformas proprietárias, os agentes conversacionais resolvem gargalos crônicos.\n\n### O Renascimento das Automações\nComo Pedro Oliver Dev, especializamo-nos em construir muito mais do que simples "chatbots". Projetamos sistemas capazes de interpretar dados estruturados, gerir rotinas de pagamento automatizado, integrar-se com CLMs (Customer Lifecycle Management) e distribuir chamados para a equipe certa.\n\n- **Micro-interações Valiosas**: Resoluções de tickets em tempo real, evitando trocas intermináveis de e-mails.\n- **Disponibilidade 24/7**: Um sistema backend robusto que nunca falha e nunca precisa de férias.\n- **Plenamente Escalável**: Usando ecossistemas serverless, um bot feito para 10 usuários atende pacificamente a 100.000 sem a necessidade de reescrever o motor.\n\nImplementar um Bot nativamente ancorado numa API de back-end com Node.js e orquestração sólida não é luxo, é a definição moderna de eficiência empresarial.`,
    tags: ['Bots', 'Automação', 'Node.js', 'Eficiência'],
    readTime: '4 min de leitura'
  },
  {
    id: 'o-poder-dos-dashboards',
    date: '10 Mai 2026',
    category: 'Tecnologia Aplicada',
    title: 'O Poder dos Dashboards: Transformando Dados Complexos em Decisões Claras',
    excerpt: 'Um olhar técnico sobre a construção de painéis de administração reativos que não apenas exibem métricas, mas contam a história real da sua operação.',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    content: `Visualizar dados de forma limpa e inteligente é a ponte entre armazenar milhões de informações em um banco relacional e efetivamente usar isso a favor do seu empreendimento.\n\n### A Engenharia do Fluxo de Informação\nCom Pedro Oliver Dev, construímos interfaces que priorizam a legibilidade de dados. Quando trabalhamos com React e soluções como Recharts ou D3, nós separamos agressivamente o gerenciamento de estado global das requisições assíncronas do backend, usando Cache e Data Fetching otimizado.\n\n- **Carregamento Instantâneo**: Adotando arquiteturas como SWR ou React Query evitamos falsos recarregamentos da interface.\n- **UI Não Oclusiva**: Um design premium evita espalhafatos. Concentramo-nos na clareza. Menos molduras e mais foco na tabela, no gráfico e nos indicadores principais.\n- **Tipagem Segura**: Com a integração via TypeScript, garantimos que um gráfico nunca vai silenciar um erro fatal devido a dados não padronizados. \n\nDashboards robustos economizam horas semanais de análise, revelando insights operacionais de extrema importância em segundos.`,
    tags: ['Dashboards', 'Aplicações Web', 'React', 'Gestão'],
    readTime: '6 min de leitura'
  },
  {
    id: 'automacao-whatsapp-ia',
    date: '10 Jan 2026',
    category: 'Inteligência Artificial',
    title: 'Automatização de Suporte via WhatsApp com IA',
    excerpt: 'Como reduzimos o tempo de resposta do SAC para 5 segundos integrando os modelos de IA da geração Gemini e fluxos avançados na API do WhatsApp Business.',
    image: 'https://images.unsplash.com/photo-1596526131083-e8c633c948d2?q=80&w=2574&auto=format&fit=crop',
    content: `A automatização de atendimento nunca foi apenas um problema de "colocar um robô". O grande abismo do mercado sempre foi "colocar um robô que não afaste os clientes por parecer engessado".\n\nNeste case desenvolvido por Pedro Oliver Dev, detalhamos como superamos os limites tradicionais dos chatbots de botões adotando inteligência artificial autogerativa.\n\n### O Fim da Árvore de Decisão Rígida\nAo invés de programarmos nós fixos (Ex: 'Digite 1 para RH, 2 para Vendas'), treinamos agentes autônomos contextuais usando prompts gigantes que englobavam todas as regras de negócio de nossos clientes parceiros. \n\nO modelo é capaz de entender a semântica da dúvida e responder perfeitamente. O mais impressionante foi sua capacidade de:\n- **Manter histórico de conversa**: sem quebrar a continuidade lógica do diálogo.\n- **Consultar banco de dados externos**: buscando ordens de serviço ativas antes de responder status de entrega.\n- **Humanizar interações**: sabendo adequar a linguagem dependendo da irritação do cliente (Sentiment Analysis).\n\n### Ferramental Tecnológico\nA orquestração foi desenhada utilizando Node.js, Webhooks do Whatsapp Business API (Meta), um layer de memória vetorizada utilizando Pinecone, e o poder do raciocínio multimodal do Gemini 3.1 Pro via vertex AI.`,
    tags: ['AI', 'WhatsApp', 'Automação', 'Bots'],
    readTime: '7 min de leitura'
  },
  {
    id: 'design-system-pedro-oliver',
    date: '02 Dez 2025',
    category: 'Design System',
    title: 'Criando um Design System Escalonável: O Método Pedro Oliver',
    excerpt: 'Desconstruindo a essência da criação de tokens visuais que escalam desde interfaces desktop até painéis embarcados sem perder a coerência visual.',
    image: 'https://images.unsplash.com/photo-1507238692062-5a0445d41fac?q=80&w=2670&auto=format&fit=crop',
    content: `Sistemas de design não são apenas repositórios de botões no Figma. Um Design System real, que poupe tempo de engenharia, precisa respirar junto com o código.\n\nCom Pedro Oliver Dev, usamos a filosofia de Tokens Essenciais. Focamos muito menos em variação infinita de paletas e mais em harmonização arquitetural primária.\n\n### Tokens como Verdade Absoluta\nAo integrar o Tailwind CSS com variáveis nativas no \`:root\`, definimos regras matemáticas rígidas de escala de tipografia e espaçamento que não podem ser violadas. Assim, um engenheiro front-end nunca escreve margins aleatórios (como \`mt-[11px]\`), mas sim unidades semânticas (\`mt-3\`).\n\nO Design System de Pedro Oliver Dev é construído em cima de contraste acentuado: o "preto não tão preto" (\`zinc-950\`) mesclado com branco absoluto na tipografia Display cria a assinatura moderna, crua e premium que permeia as marcas que impulsionamos.`,
    tags: ['Design System', 'UI/UX', 'Tailwind', 'CSS'],
    readTime: '4 min de leitura'
  }
];
