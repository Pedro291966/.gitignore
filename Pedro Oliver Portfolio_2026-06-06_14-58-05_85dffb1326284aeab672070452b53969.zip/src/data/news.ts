export const newsData: Record<string, any> = {
  "ci-cd-2026": {
    id: "ci-cd-2026",
    title: "Lançamento da nova versão do sistema interno de CI/CD",
    description: "Para garantir ainda mais agilidade nas entregas de software, reformulamos nosso pipeline adotando estratégias mais robustas de integração contínua.",
    date: "14 Mai 2026",
    category: "Engenharia",
    author: "Pedro Oliver Engineering",
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2670&auto=format&fit=crop",
    content: `
      <h2>Uma nova era na entrega de software</h2>
      <p>Nos últimos 6 meses, a equipe de engenharia de Pedro Oliver Dev trabalhou incansavelmente para reescrever do zero nossos pipelines de Integração e Entrega Contínuas (CI/CD). O objetivo sempre foi um só: <strong>como entregar valor aos clientes na metade do tempo sem sacrificar 1% da qualidade?</strong></p>
      
      <p>Com as novas atualizações via Edge Containers e validações rígidas de TDD (Test Driven Development) no próprio pipeline, todas as PRs (Pull Requests) agora contam com ambientes de preview efêmeros gerados em menos de 2 minutos.</p>
      
      <h3>O que isso significa para os clientes?</h3>
      <ul>
        <li>Testes de homologação instantâneos e isolados, sem o risco de sujar o ambiente de staging.</li>
        <li>Bugs mitigados no early stage, evitando que cheguem a branch principal.</li>
        <li>Mudanças e hotfixes indo para produção com a segurança de um clique.</li>
      </ul>
      <p>Continuamos investindo pesadamente em R&D para sermos a agência de engenharia mais rápida e confiável do mercado.</p>
    `
  },
  "ui-ux-award": {
    id: "ui-ux-award",
    title: "Nova premiação global de UI/UX em nossa prateleira",
    description: "Fomos contemplados com uma medalha no Annual Design Awards pelo case desenvolvido em parceria com nosso cliente de Nova Iorque no último trimestre.",
    date: "03 Abr 2026",
    category: "Reconhecimento",
    author: "Diretoria de Arte",
    image: "https://images.unsplash.com/photo-1600132806370-bf17e65e942f?q=80&w=2794&auto=format&fit=crop",
    content: `
      <h2>Design que funciona no mundo real</h2>
      <p>É com muito orgulho que comunicamos nossa vitória no Annual Interface & Experience Awards 2026.</p>
      <p>Mas, diferente do que o mercado convencional acredita, esse prêmio não foi ganho apenas desenhando interfaces bonitas, mas sim interfaces <strong>funcionais</strong>.</p>
      
      <h3>A Matemática do Acesso</h3>
      <p>No projeto B2B validado para nosso cliente americano do ramo financeiro, as exigências de acessibilidade eram gigantescas. Precisávamos de aprovação WCAG AAA, com auto-contraste nativo nas telas e redução de atrito cognitivo em tabelas de milhares de dados.</p>
      <p>Este reconhecimento mundial ratifica nosso foco da engenharia aliada com arte e psicologia do usuário. Obrigado a toda equipe de Design e Front-End.</p>
    `
  },
  "design-sprint": {
    id: "design-sprint",
    title: "Processo de Design Sprint 2.0",
    description: "Anunciamos a atualização do nosso core de discovery, permitindo agora validar hipóteses de negócios em apenas 3 dias com prototipagem avançada de alta fidelidade.",
    date: "22 Fev 2026",
    category: "Metodologia",
    author: "Product Team",
    image: "https://images.unsplash.com/photo-1542626991-cbc4e32524cc?q=80&w=2669&auto=format&fit=crop",
    content: `
      <h2>Acelerando a inovação</h2>
      <p>Anunciamos a implementação oficial do <strong>Design Sprint 2.0</strong> em todas as contas Enterprise assumidas por Pedro Oliver Dev este ano.</p>
      <p>Através das melhorias de processo integrando automação de AI para resumos de briefings e pesquisa paralela automatizada, reduzimos o ciclo original de 5 dias desenvolvido pela Google Ventures para uns incríveis <strong>3 dias laborais</strong>, culminando em um protótipo fidedigno, clicável e pronto para teste de usuários finais.</p>
    `
  },
  "migracao-infraestrutura": {
    id: "migracao-infraestrutura",
    title: "Finalizamos a migração global da nossa arquitetura",
    description: "Todos os nossos serviços críticos agora rodam nativamente na borda, entregando conteúdos em milissegundos independente do continente.",
    date: "10 Jan 2026",
    category: "Infraestrutura",
    author: "Equipe de DevOps",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=2000&auto=format&fit=crop",
    content: `
      <h2>Velocidade e Resiliência sem paralelos</h2>
      <p>Nossa visão sempre foi de construir sistemas inquebráveis. Hoje, nos orgulhamos de anunciar que concluímos um plano colossal de migração: 100% dos nossos nós de aplicação web agora operam *Serverless* e em *Edge computing* globais.</p>
      <p>Resultados alcançados:</p>
      <ul>
        <li>Queda de 82% no tempo de resposta inicial (TTFB).</li>
        <li>Eliminação das temíveis *cold-starts* em nós cruciais via *V8 Isolates*.</li>
        <li>Replicação bancária ativa em 12 regiões diferentes (multi-cloud failover).</li>
      </ul>
    `
  },
  "pedro-oliver-open-source": {
    id: "pedro-oliver-open-source",
    title: "Compromisso Pedro Oliver Dev com o Open Source",
    description: "Lançaremos em breve cinco bibliotecas mantidas internamente pela empresa, focadas em componentes React fluidos e processamento seguro no lado do servidor.",
    date: "05 Nov 2025",
    category: "Comunidade",
    author: "Pedro Oliver, CEO",
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2000&auto=format&fit=crop",
    content: `
      <h2>Devolvendo à Comunidade</h2>
      <p>O desenvolvimento moderno seria impensável sem o ecossistema Open Source (OSS). Quase todas as infraestruturas modernas se apoiam em projetos mantidos pela comunidade livre.</p>
      <p>Como forma de devolver essa dádiva imensa, nós da Pedro Oliver Dev estamos limpando o código dos nossos componentes mais robustos e independentes para disponibilizá-los sob a licença do MIT no Github ainda este ano.</p>
      <p>Fique atento às nossas redes para a estreia dos mantenedores core.</p>
    `
  }
};
