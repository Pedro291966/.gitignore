export const categories = [
  { id: 'HTML', name: 'HTML' },
  { id: 'CSS', name: 'CSS' },
  { id: 'JavaScript', name: 'JavaScript' },
  { id: 'TypeScript', name: 'TypeScript' },
  { id: 'React', name: 'React' },
  { id: 'Node.js', name: 'Node.js' },
  { id: 'Python', name: 'Python' },
  { id: 'APIs', name: 'APIs' },
  { id: 'Deploy', name: 'Deploy' },
  { id: 'Boas Práticas', name: 'Boas Práticas' },
  { id: 'Arquitetura', name: 'Arquitetura' },
  { id: 'Carreira', name: 'Carreira' }
];
