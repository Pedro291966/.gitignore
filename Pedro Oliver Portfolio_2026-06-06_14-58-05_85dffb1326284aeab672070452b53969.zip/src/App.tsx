import { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import { motion } from 'motion/react';

// Lazy loading pages for better performance and elegant loading states
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Projects = lazy(() => import('./pages/Projects'));
const Articles = lazy(() => import('./pages/Articles'));
const ArticleDetail = lazy(() => import('./pages/ArticleDetail'));
const Documentation = lazy(() => import('./pages/Documentation'));
const Policies = lazy(() => import('./pages/Policies'));
const Contact = lazy(() => import('./pages/Contact'));
const FAQ = lazy(() => import('./pages/FAQ'));
const News = lazy(() => import('./pages/News'));
const NewsDetail = lazy(() => import('./pages/NewsDetail'));
const Bots = lazy(() => import('./pages/Bots'));
const Sites = lazy(() => import('./pages/Sites'));
const Sistemas = lazy(() => import('./pages/Sistemas'));
const InfoPage = lazy(() => import('./pages/InfoPage'));

// Sophisticated Loading Component
function PageLoader() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="min-h-[75vh] w-full pt-16 max-w-7xl mx-auto px-6 lg:px-8" 
      role="status" 
      aria-label="Carregando Portifólio de Pedro Oliver"
    >
      <div className="mb-10 flex items-center gap-4">
        <div className="relative w-14 h-14 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-center overflow-hidden shadow-[0_0_35px_rgba(255,255,255,0.18)]">
          <img src="/logo.png" alt="Logo Pedro Oliver" className="w-12 h-12 object-contain animate-pulse" />
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-zinc-500 font-bold">Carregando</p>
          <p className="text-white font-display text-xl tracking-tight">Portifólio | Pedro Oliver</p>
        </div>
      </div>

      {/* Header Skeleton */}
      <div className="flex flex-col gap-6 mb-16 max-w-3xl">
        {/* Eyebrow / Label */}
        <div className="h-4 w-24 bg-zinc-800/50 rounded-full animate-pulse" />
        {/* Title */}
        <div className="h-12 sm:h-16 w-3/4 sm:w-2/3 bg-zinc-800/60 rounded-2xl animate-pulse" />
        {/* Subtitle lines */}
        <div className="flex flex-col gap-3 mt-2">
          <div className="h-5 w-full bg-zinc-800/40 rounded-lg animate-pulse" />
          <div className="h-5 w-5/6 bg-zinc-800/40 rounded-lg animate-pulse" />
        </div>
      </div>

      {/* Content Skeleton - Grid of features/cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="flex flex-col gap-5 bg-zinc-900/30 border border-zinc-800/40 p-6 sm:p-8 rounded-[2rem] animate-pulse">
            {/* Image / Icon box */}
            <div className="h-40 sm:h-48 w-full bg-zinc-800/50 rounded-2xl" />
            
            {/* Tags row */}
            <div className="flex gap-3 mt-2">
              <div className="h-5 w-20 bg-zinc-800/60 rounded-full" />
              <div className="h-5 w-24 bg-zinc-800/40 rounded-full" />
            </div>
            
            {/* Card Title */}
            <div className="h-7 w-4/5 bg-zinc-800/60 rounded-xl" />
            
            {/* Card Excerpt */}
            <div className="flex flex-col gap-2">
              <div className="h-4 w-full bg-zinc-800/40 rounded-md" />
              <div className="h-4 w-full bg-zinc-800/40 rounded-md" />
              <div className="h-4 w-2/3 bg-zinc-800/40 rounded-md" />
            </div>
            
            {/* Footer / Button area */}
            <div className="h-10 w-36 bg-zinc-800/50 rounded-xl mt-auto pt-4" />
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export default function App() {
  return (
    <Router>
      <Layout>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/articles" element={<Articles />} />
            <Route path="/articles/:id" element={<ArticleDetail />} />
            <Route path="/docs" element={<Documentation />} />
            <Route path="/policies" element={<Policies />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/news" element={<News />} />
            <Route path="/news/:id" element={<NewsDetail />} />
            <Route path="/bots" element={<Bots />} />
            <Route path="/sites" element={<Sites />} />
            <Route path="/sistemas" element={<Sistemas />} />
            <Route path="/info/:id" element={<InfoPage />} />
          </Routes>
        </Suspense>
      </Layout>
    </Router>
  );
}
