import { useParams, Navigate, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ArrowLeft, BookOpen, Layers, Terminal, Sparkles, AlertCircle, 
  HelpCircle, ExternalLink, Zap, CheckCircle, Database, ShieldAlert, Cpu, Activity, Shield, BarChart, Server, Globe
} from 'lucide-react';
import { mergedInfoPages as infoPages } from "../data/enhancedInfoPages";
import Markdown from 'react-markdown';

const getAdvantageIcon = (text: string) => { const t = text.toLowerCase(); if (t.includes('veloz') || t.includes('rápido') || t.includes('performance')) return <Zap size={18} />; if (t.includes('segur')) return <Shield size={18} />; if (t.includes('dados') || t.includes('analí')) return <BarChart size={18} />; if (t.includes('servidor') || t.includes('backend')) return <Server size={18} />; if (t.includes('compatib') || t.includes('navegador')) return <Globe size={18} />; return <Activity size={18} />; }; const renderWithAnimation = (Tag: any) => ({ node, children, ...props }: any) => ( <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-20px" }} transition={{ duration: 0.6, ease: "easeOut" }} > <Tag {...props}>{children}</Tag> </motion.div> );
import Comments from '../components/Comments';

// Highly rich metadata dictionary mapping for each key technology to add gorgeous SVGs, official logos, 
// dynamic glow backdrops, floating cycles and full-blown professional sections.
interface TechDetail {
  logo: React.ReactNode;
  glowColor: string;
  accentText: string;
  difficulty: "Iniciante" | "Intermediário" | "Avançado" | "Especialista";
  difficultyColor: string;
  primaryPurpose: string;
  advantages: string[];
  codeSnippet: string;
  codeLanguage: string;
  realWorldProjects: string;
  bestPractices: string[];
  curiosity: string;
  documentationUrl: string;
}

const TECH_METADATA: Record<string, TechDetail> = {
  javascript: {
    glowColor: "from-yellow-500/20 to-amber-500/5",
    accentText: "text-yellow-400",
    difficulty: "Intermediário",
    difficultyColor: "bg-amber-400/10 text-amber-500 border-amber-400/20",
    primaryPurpose: "Universalizar interatividades estroboscópicas no lado do cliente e alimentar microsserviços ultrarrápidos em Node.js no servidor.",
    advantages: [
      "Processamento assíncrono não-bloqueante (Event Loop de alta performance)",
      "Rodado de forma nativa por literalmente todos os navegadores na Terra",
      "Ecossistema de pacotes gigantesco (NPM) com milhões de bibliotecas prontas",
      "Compartilhamento trivial de tipos e modelos de dados entre Front-end e Back-end"
    ],
    codeSnippet: `// Exemplo clássico de assincronismo moderno com Promises e Async/Await
async function buscarDadosOperacionais(url) {
  try {
    const resposta = await fetch(url);
    if (!resposta.ok) throw new Error('Falha na requisição');
    const logs = await resposta.json();
    return logs.filter(log => log.status === 'ACTIVE');
  } catch(error) {
    console.error('Falha de requisição de rede:', error);
  }
}`,
    codeLanguage: "javascript",
    realWorldProjects: "BFFs de alta escala, painéis interativos de relatórios de vendas, SPA sincronizadas no Spotify/Netflix.",
    bestPractices: [
      "Evite mutabilidade de dados direta; prefira sempre métodos funcionais (.map, .filter, .reduce)",
      "Sempre capture rejeições de Promises em blocos try/catch rigorosos",
      "Não declare variáveis globais poluindo a escopo principal do navegador"
    ],
    curiosity: "O JavaScript foi escrito inicialmente na Netscape em apenas 10 dias em maio de 1995 por Brendan Eich, sob o nome de 'Mocha'.",
    documentationUrl: "https://developer.mozilla.org/pt-BR/docs/Web/JavaScript",
    logo: (
      <motion.div 
        animate={{ y: [0, -10, 0] }} 
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
        className="w-32 h-32 flex items-center justify-center rounded-2xl bg-emerald-500/10 border border-emerald-500/30 relative shadow-[0_0_40px_rgba(16,185,129,0.2)]"
      >
        <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-2xl animate-pulse" />
        <Server size={52} className="text-emerald-400 z-10 filter drop-shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
      </motion.div>
    )
  }
};

export default function InfoPage() {
  const { id } = useParams<{ id: string }>();
  
  if (!id || !infoPages[id]) {
    return <Navigate to="/" replace />;
  }

  const page = infoPages[id];
  const techMeta = TECH_METADATA[id] || null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen font-sans text-zinc-300"
    >
      {/* Absolute center background glow mapping */}
      <div className={`absolute top-0 right-0 w-1/2 aspect-square bg-gradient-to-b ${techMeta ? techMeta.glowColor : 'from-zinc-800/10 to-transparent'} rounded-full blur-[140px] pointer-events-none -z-10`} />
      
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-12"
        >
          <Link to="/" className="inline-flex items-center gap-2 text-zinc-500 hover:text-white transition-colors text-sm font-semibold uppercase tracking-widest group">
            <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform text-emerald-400" /> Voltar ao início
          </Link>
        </motion.div>

        {/* Dynamic technology hero section with floating glow logo */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-10 mb-16 pb-12 border-b border-zinc-900">
          <motion.div 
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="flex-grow max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-900/50 text-xs font-semibold uppercase tracking-widest text-zinc-300 mb-6 backdrop-blur-sm">
              <BookOpen size={14} className="text-emerald-400" />
              <span>Central de Conhecimento</span>
              {techMeta && (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-800" />
                  <span className={`px-2 py-0.5 rounded-md border ${techMeta.difficultyColor} text-[10px]`}>
                    {techMeta.difficulty}
                  </span>
                </>
              )}
            </div>
            
            <h1 className="text-4xl md:text-5xl font-display font-medium tracking-tight mb-5 leading-[1.1] text-white">
              {techMeta ? (
                <>
                  Documentação: <span className={techMeta.accentText}>{page.title.replace("Documentação: ", "").replace("Semântica Oculta: ", "")}</span>
                </>
              ) : (
                page.title
              )}
            </h1>
            
            <p className="text-lg text-zinc-400 font-light leading-relaxed">
              {page.description}
            </p>
          </motion.div>

          {/* Glowing Animated Float Badge Container */}
          {techMeta && (
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ 
                scale: 1, 
                opacity: 1,
                y: [0, -12, 0]
              }}
              transition={{
                scale: { duration: 0.5 },
                opacity: { duration: 0.5 },
                y: { duration: 5, repeat: Infinity, ease: "easeInOut" }
              }}
              className="relative w-36 h-36 flex items-center justify-center bg-zinc-950 rounded-3xl border border-zinc-900/60 shadow-[0_15px_30px_rgba(0,0,0,0.4)] md:self-center self-start"
            >
              {/* Pulsing light behind logo */}
              <span className={`absolute -inset-2 rounded-3xl opacity-25 bg-gradient-to-tr ${techMeta.glowColor} blur-xl animate-pulse`} />
              <div className="relative z-10 p-4">
                {techMeta.logo}
              </div>
            </motion.div>
          )}
        </div>

        {/* Comprehensive descriptive technology tabs if metadata is matched */}
        {techMeta && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid gap-12 mb-16"
          >
            {/* O que é / Para que serve panel */}
            <div className="p-8 rounded-3xl border border-zinc-900/50 bg-zinc-950/20 backdrop-blur-sm">
              <h3 className="text-lg font-display font-medium text-white mb-3 flex items-center gap-2">
                <Sparkles size={16} className="text-emerald-400" /> O que é & Para que serve?
              </h3>
              <p className="text-zinc-400 font-light leading-relaxed">
                {techMeta.primaryPurpose}
              </p>
            </div>

            {/* Advantages grid */}
            <div>
              <h3 className="text-lg font-display font-medium text-white mb-6 flex items-center gap-2 select-none">
                <CheckCircle size={16} className="text-emerald-400" /> Principais Vantagens de Implementação
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {techMeta.advantages.map((adv, i) => (
                  <div key={i} className="group flex flex-col p-6 rounded-3xl border border-zinc-900/60 bg-zinc-950/40 font-light hover:bg-zinc-900/60 hover:border-zinc-700/60 hover:shadow-[0_10px_30px_rgba(0,0,0,0.4)] hover:-translate-y-1 transition-all duration-300">
                    <div className="w-10 h-10 mb-4 rounded-xl border border-zinc-800 bg-zinc-900 flex items-center justify-center text-zinc-400 group-hover:text-emerald-400 group-hover:border-emerald-500/30 group-hover:bg-emerald-500/10 transition-colors">
                      {getAdvantageIcon(adv)}
                    </div>
                    <strong className="text-white block mb-2 font-medium text-base">Impacto #{i+1}</strong>
                    <p className="text-zinc-400 text-sm leading-relaxed flex-grow">{adv}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Code sandbox block */}
            <div>
              <h3 className="text-lg font-display font-medium text-white mb-4 flex items-center gap-2">
                <Terminal size={17} className="text-emerald-400" /> Caso de Uso Comprovado (Código)
              </h3>
              <div className="rounded-2xl border border-zinc-900 bg-zinc-950 overflow-hidden shadow-2xl">
                <div className="px-4 py-2.5 bg-zinc-900 border-b border-zinc-900 flex items-center justify-between text-xs text-zinc-500 font-mono uppercase tracking-widest">
                  <span>EXEMPLO DE CÓDIGO</span>
                  <span className="text-emerald-400">{techMeta.codeLanguage}</span>
                </div>
                <pre className="p-6 text-zinc-300 font-mono text-xs overflow-x-auto leading-6 max-h-[350px]">
                  <code>{techMeta.codeSnippet}</code>
                </pre>
              </div>
            </div>

            {/* Quality assurance / Difficulty rating */}
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="p-6 rounded-3xl border border-zinc-900/60 bg-zinc-950/20">
                <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-500 mb-3 flex items-center gap-1.5">
                  <ShieldAlert size={14} className="text-emerald-400" /> Nível de Dificuldade
                </h4>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xl font-medium text-white">{techMeta.difficulty}</span>
                  <span className="text-xs text-zinc-500 font-light">de aprendizado</span>
                </div>
                <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-500 rounded-full" 
                    style={{ 
                      width: techMeta.difficulty === "Iniciante" ? "30%" : techMeta.difficulty === "Intermediário" ? "55%" : "85%" 
                    }} 
                  />
                </div>
              </div>

              <div className="p-6 rounded-3xl border border-zinc-900/60 bg-zinc-950/20">
                <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-500 mb-3 flex items-center gap-1.5">
                  <ExternalLink size={14} className="text-emerald-400" /> Documentação Oficial
                </h4>
                <p className="text-xs text-zinc-500 font-light mb-4">Consulte as referências nativas recomendadas pelos engenheiros:</p>
                <a 
                  href={techMeta.documentationUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-xs font-semibold text-white hover:text-emerald-300 bg-zinc-900/80 px-4 py-2 rounded-full border border-zinc-800 hover:border-zinc-700 transition-colors"
                >
                  Documentação Oficial <ExternalLink size={12} />
                </a>
              </div>
            </div>

            {/* Best practices list */}
            <div>
              <h3 className="text-lg font-display font-medium text-white mb-4 flex items-center gap-2">
                <AlertCircle size={16} className="text-emerald-400" /> Boas Práticas do Padrão Ouro
              </h3>
              <ul className="space-y-3.5">
                {techMeta.bestPractices.map((practice, i) => (
                  <li key={i} className="flex gap-3 text-sm text-zinc-400 font-light leading-relaxed">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono text-[10px] flex-shrink-0 mt-0.5">✔</span>
                    <span>{practice}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* curiosity highlight card */}
            <div className="p-6 sm:p-8 rounded-3xl border border-dashed border-zinc-800 bg-zinc-900/10 relative overflow-hidden">
              <span className="absolute -top-10 -right-10 w-24 h-24 bg-emerald-500/5 blur-3xl rounded-full" />
              <h4 className="text-white font-medium text-sm uppercase tracking-widest mb-3 flex items-center gap-2 select-none">
                <HelpCircle size={14} className="text-emerald-400" /> Curiosidade Histórica
              </h4>
              <p className="text-xs leading-relaxed text-zinc-500 italic pr-6 font-light">
                "{techMeta.curiosity}"
              </p>
            </div>
          </motion.div>
        )}

        {/* Classic markdown-rendered core content */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="prose prose-invert prose-zinc max-w-none text-zinc-400 
            prose-headings:font-display prose-headings:font-medium prose-headings:tracking-tight prose-headings:text-white
            prose-a:text-white prose-a:decoration-zinc-700 hover:prose-a:decoration-white prose-a:underline-offset-4 
            prose-code:bg-zinc-800/80 prose-code:text-zinc-200 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:before:content-none prose-code:after:content-none 
            prose-pre:bg-zinc-950/60 prose-pre:border prose-pre:border-zinc-900 prose-pre:backdrop-blur-sm
            prose-strong:text-zinc-200 prose-ul:list-disc prose-li:marker:text-zinc-700 mb-20"
        >
          <div className="markdown-body border-t border-zinc-900/50 pt-16">
            <Markdown components={{ h1: renderWithAnimation('h1'), h2: renderWithAnimation('h2'), h3: renderWithAnimation('h3'), h4: renderWithAnimation('h4'), p: renderWithAnimation('p'), ul: renderWithAnimation('ul'), ol: renderWithAnimation('ol'), blockquote: renderWithAnimation('blockquote') }}>{page.content}</Markdown>
          </div>
        </motion.div>

        {/* Reactive Comments Integration */}
        <Comments articleTitle={`Documentação: ${page.title}`} />

        {/* Navigation grids */}
        <div className="grid md:grid-cols-2 gap-6 mt-20 pt-16 border-t border-zinc-900">
          <Link to="/contact" className="p-8 rounded-3xl border border-zinc-900 bg-gradient-to-br from-zinc-950/40 to-black hover:border-zinc-800 transition-all group shadow-lg">
             <Terminal size={24} className="text-zinc-500 group-hover:text-emerald-400 transition-colors mb-4" />
             <h3 className="text-xl font-display font-medium text-white mb-2">Engenharia Sob Medida</h3>
             <p className="text-zinc-500 font-light text-sm">Pronto para conversar sobre o uso prático destas tecnologias no seu negócio?</p>
          </Link>
          <Link to="/docs" className="p-8 rounded-3xl border border-zinc-900 bg-gradient-to-br from-zinc-950/40 to-black hover:border-zinc-800 transition-all group shadow-lg">
             <Layers size={24} className="text-zinc-500 group-hover:text-emerald-400 transition-colors mb-4" />
             <h3 className="text-xl font-display font-medium text-white mb-2">Documentação Completa</h3>
             <p className="text-zinc-500 font-light text-sm">Explore as referências de APIs, webhooks e integrações para os nossos serviços e sistemas web.</p>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
