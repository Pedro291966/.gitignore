import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Terminal, Share2, Twitter, Linkedin, Copy, Check, ChevronRight, ArrowRight, X } from 'lucide-react';
import { articlesData } from '../data/articles';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { useState, useEffect } from 'react';
import { OptimizedImage } from '../components/OptimizedImage';
import { TypingAnimation } from '../components/TypingAnimation';
import Comments from '../components/Comments';
import SectionHeader from '../components/SectionHeader';

export default function ArticleDetail() {
  const { id } = useParams();
  const article = articlesData.find(a => a.id === id);
  const [copied, setCopied] = useState(false);
  const [toc, setToc] = useState<{ id: string, text: string, level: number }[]>([]);
  const [activeSection, setActiveSection] = useState<string>('');
  const [fabOpen, setFabOpen] = useState(false);

  useEffect(() => {
    if (!article) return;
    
    // Extract Headings for TOC
    const headings = Array.from(article.content.matchAll(/^(#{2,3})\s+(.*)$/gm)).map(match => ({
      level: match[1].length,
      text: match[2],
      id: match[2].toLowerCase().replace(/[^\w-]+/g, '-')
    }));
    setToc(headings);

    // Track as read
    try {
      const stored = JSON.parse(localStorage.getItem('readArticles') || '[]');
      if (!stored.includes(article.id)) {
        stored.push(article.id);
        localStorage.setItem('readArticles', JSON.stringify(stored));
      }
    } catch(e) {}
  }, [article]);

  useEffect(() => {
    if (toc.length === 0) return;
    
    // Setup IntersectionObserver for Scrollspy
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: '-20% 0px -80% 0px' }
    );

    toc.forEach(item => {
      const el = document.getElementById(item.id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [toc]);

  if (!article) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center">
        <h1 className="text-4xl font-display font-medium mb-4">Artigo não encontrado</h1>
        <Link to="/articles" className="inline-flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
           <ArrowLeft size={16} /> Voltar aos artigos
        </Link>
      </div>
    );
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href,
      }).catch(console.error);
    } else {
      copyLink();
    }
  };

  const copyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        })
        .catch(err => console.error('Failed to copy', err));
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = window.location.href;
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        console.error('Fallback: Oops, unable to copy', err);
      }
      document.body.removeChild(textArea);
    }
  };

  const relatedArticles = article 
    ? articlesData.filter(a => a.id !== article.id && a.category === article.category).slice(0, 2)
    : [];

  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-8 pt-12 pb-32 grid lg:grid-cols-[1fr_280px] xl:grid-cols-[1fr_320px] gap-16 lg:gap-24 items-start">
    <motion.article 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4, }}
      className="max-w-3xl w-full"
    >
      <Link to="/articles" className="inline-flex items-center gap-2 text-sm font-semibold tracking-widest uppercase text-zinc-500 hover:text-white transition-colors mb-16">
        <ArrowLeft size={16} /> Artigos
      </Link>
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4 text-xs font-semibold tracking-widest uppercase text-zinc-500">
          <span>{article.date}</span>
          <span className="w-1 h-1 rounded-full bg-zinc-700" />
          <span className="text-white flex items-center gap-1.5 px-2 py-1 bg-zinc-900 rounded-md">
            {article.category === 'Engenharia' || article.category === 'Arquitetura' || article.category === 'Clean Code' ? <Terminal size={12} /> : null}
            {article.category}
          </span>
        </div>
                <div className="flex items-center gap-3">
           <button onClick={handleShare} className="relative w-11 h-11 rounded-full border border-zinc-800 bg-zinc-900/80 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-700 hover:bg-zinc-800 transition-all hover:scale-110 active:scale-95 group shadow-lg" aria-label="Compartilhar Artigo">
             <Share2 size={18} className="group-hover:animate-pulse" />
             <span className="absolute inset-0 rounded-full hover:shadow-[0_0_20px_rgba(255,255,255,0.15)] opacity-0 group-hover:opacity-100 transition-opacity"></span>
             
             {/* Rich Tooltip */}
             <div className="absolute -top-14 left-1/2 -translate-x-1/2 px-3 py-2 bg-white text-black text-xs font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_10px_30px_rgba(255,255,255,0.15)] transform translate-y-2 group-hover:-translate-y-1 z-50 flex items-center gap-1.5">
               <Share2 size={12} className="opacity-80" />
               Compartilhar matriz
               <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 border-[5px] border-transparent border-t-white" />
             </div>
           </button>
           
           <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(window.location.href)}`} target="_blank" rel="noopener noreferrer" className="relative w-11 h-11 rounded-full border border-zinc-800 bg-zinc-900/80 hidden sm:flex items-center justify-center text-zinc-400 hover:text-[#1DA1F2] hover:border-[#1DA1F2]/50 hover:bg-[#1DA1F2]/10 transition-all hover:scale-110 active:scale-95 group shadow-lg" aria-label="Compartilhar no Twitter">
             <Twitter size={18} className="group-hover:animate-pulse" />
             <span className="absolute inset-0 rounded-full hover:shadow-[0_0_20px_rgba(29,161,242,0.25)] opacity-0 group-hover:opacity-100 transition-opacity"></span>
             
             {/* Rich Tooltip */}
             <div className="absolute -top-14 left-1/2 -translate-x-1/2 px-3 py-2 bg-white text-black text-xs font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_10px_30px_rgba(255,255,255,0.15)] transform translate-y-2 group-hover:-translate-y-1 z-50 flex items-center gap-1.5 border border-zinc-200">
               <Twitter size={12} className="text-[#1DA1F2]" />
               Tweetar
               <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 border-[5px] border-transparent border-t-white" />
             </div>
           </a>
           
           <a href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(window.location.href)}&title=${encodeURIComponent(article.title)}`} target="_blank" rel="noopener noreferrer" className="relative w-11 h-11 rounded-full border border-zinc-800 bg-zinc-900/80 hidden sm:flex items-center justify-center text-zinc-400 hover:text-[#0A66C2] hover:border-[#0A66C2]/50 hover:bg-[#0A66C2]/10 transition-all hover:scale-110 active:scale-95 group shadow-lg" aria-label="Compartilhar no LinkedIn">
             <Linkedin size={18} className="group-hover:animate-pulse" />
             <span className="absolute inset-0 rounded-full hover:shadow-[0_0_20px_rgba(10,102,194,0.25)] opacity-0 group-hover:opacity-100 transition-opacity"></span>
             
             {/* Rich Tooltip */}
             <div className="absolute -top-14 left-1/2 -translate-x-1/2 px-3 py-2 bg-white text-black text-xs font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_10px_30px_rgba(255,255,255,0.15)] transform translate-y-2 group-hover:-translate-y-1 z-50 flex items-center gap-1.5 border border-zinc-200">
               <Linkedin size={12} className="text-[#0A66C2]" />
               Publicar post
               <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 border-[5px] border-transparent border-t-white" />
             </div>
           </a>
           
           <button onClick={copyLink} className="relative w-11 h-11 rounded-full border border-zinc-800 bg-zinc-900/80 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-700 hover:bg-zinc-800 transition-all hover:scale-110 active:scale-95 group shadow-lg" aria-label="Copiar link do artigo">
             {copied ? <Check size={18} className="text-emerald-500 scale-110 transition-transform" /> : <Copy size={18} className="group-hover:animate-pulse" />}
             <span className={`absolute inset-0 rounded-full transition-opacity opacity-0 group-hover:opacity-100 ${copied ? 'shadow-[0_0_20px_rgba(16,185,129,0.3)]' : 'shadow-[0_0_20px_rgba(255,255,255,0.15)]'}`}></span>
             
             {/* Rich Tooltip */}
             <div className={`absolute -top-14 left-1/2 -translate-x-1/2 px-3 py-2 text-black text-xs font-semibold rounded-lg opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap shadow-[0_10px_30px_rgba(255,255,255,0.15)] transform translate-y-2 group-hover:-translate-y-1 z-50 flex items-center gap-1.5 border border-zinc-200 ${copied ? 'bg-emerald-400' : 'bg-white'}`}>
               {copied ? <Check size={12} className="text-black" /> : <Copy size={12} className="opacity-80" />}
               {copied ? 'Link Copiado!' : 'Copiar URL'}
               <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 border-[5px] border-transparent ${copied ? 'border-t-emerald-400' : 'border-t-white'}`} />
             </div>
           </button>
        </div>
      </div>
      
      <h1 className="text-4xl md:text-5xl font-display font-medium tracking-tight mb-8 leading-[1.1] text-white">
        <TypingAnimation text={article.title} />
      </h1>
      
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6, ease: "easeOut" }}
      >
        {toc.length > 0 && (
          <details className="lg:hidden mb-8 group border border-zinc-800 rounded-2xl bg-zinc-900/30 overflow-hidden">
            <summary className="px-6 py-4 cursor-pointer font-medium text-sm tracking-widest text-zinc-400 uppercase flex items-center justify-between hover:text-white transition-colors">
              Sumário do Artigo
              <ChevronRight size={16} className="transform transition-transform group-open:rotate-90" />
            </summary>
            <nav className="flex flex-col gap-3 px-6 pb-6 pt-2 border-t border-zinc-800/50">
              {toc.map(item => (
                <a 
                  key={item.id} 
                  href={`#${item.id}`}
                  className={`text-sm transition-colors ${item.level === 3 ? 'pl-4 text-zinc-500 hover:text-white' : 'text-zinc-400 hover:text-white font-medium'}`}
                >
                  {item.text}
                </a>
              ))}
            </nav>
          </details>
        )}

        <p className="text-xl text-zinc-400 font-light leading-relaxed mb-12 border-l-2 border-zinc-800 pl-6">
          {article.excerpt}
        </p>

        {article.image && (
          <div className="w-full aspect-[2/1] mb-16 rounded-3xl overflow-hidden relative border border-zinc-800 shadow-lg">
            <OptimizedImage 
              src={article.image} 
              alt={article.title}
            />
          </div>
        )}

        <div className="prose prose-invert prose-zinc max-w-none text-zinc-400 prose-headings:font-display prose-headings:font-medium prose-headings:tracking-tight prose-a:text-white prose-a:decoration-zinc-700 hover:prose-a:decoration-white prose-a:underline-offset-4 prose-code:bg-zinc-800 prose-code:text-zinc-200 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:before:content-none prose-code:after:content-none prose-pre:bg-transparent prose-pre:p-0 prose-pre:m-0 mb-16">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h2({ children }) {
                const text = String(children);
                const id = text.toLowerCase().replace(/[^\w-]+/g, '-');
                return <h2 id={id} className="scroll-mt-32 border-b border-zinc-800 pb-4">{children}</h2>;
              },
              h3({ children }) {
                const text = String(children);
                const id = text.toLowerCase().replace(/[^\w-]+/g, '-');
                return <h3 id={id} className="scroll-mt-32">{children}</h3>;
              },
              img: ({ src, alt, ...props }) => (
                <OptimizedImage
                  src={String(src)}
                  alt={String(alt)}
                  className="w-full rounded-2xl border border-zinc-800 shadow-lg my-12"
                />
              ),
              code({ node, inline, className, children, ...props }: any) {
                const match = /language-(\w+)/.exec(className || '');
                return !inline && match ? (
                  <div className="my-8 rounded-xl overflow-hidden border border-zinc-800 bg-[#1E1E1E]">
                    <div className="px-4 py-2 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-500 font-mono uppercase tracking-widest">
                      <span>{match[1]}</span>
                    </div>
                    <SyntaxHighlighter
                      {...props}
                      style={vscDarkPlus as any}
                      language={match[1]}
                      PreTag="div"
                      showLineNumbers={true}
                      customStyle={{ margin: 0, padding: '1.5rem', background: 'transparent' }}
                      lineNumberStyle={{ minWidth: '2em', paddingRight: '1em', color: '#6B7280', textAlign: 'right' }}
                    >
                      {String(children).replace(/\n$/, '')}
                    </SyntaxHighlighter>
                  </div>
                ) : (
                  <code {...props} className={className}>
                    {children}
                  </code>
                );
              }
            }}
          >
            {article.content}
          </ReactMarkdown>
        </div>
      </motion.div>
      
      <Comments articleTitle={article.title} />
      
      {relatedArticles.length > 0 && (
        <div className="border-t border-zinc-900 mt-24 pt-16">
          <SectionHeader 
            title="Artigos Relacionados" 
            subtitle="Explore mais conteúdos neste mesmo universo de conhecimento." 
          />
          <div className="flex flex-col md:grid md:grid-cols-3 gap-8 mt-12">
            {relatedArticles.map((rel, index) => {
              const isFirst = index === 0;
              return (
                <motion.div
                  key={rel.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.15 }}
                  className={`block ${isFirst ? 'md:col-span-2' : 'md:col-span-1'}`}
                >
                  <Link 
                    to={`/articles/${rel.id}`} 
                    className="group block h-full"
                    aria-label={`Ler artigo: ${rel.title}`}
                  >
                    <div className="flex flex-col h-full bg-zinc-950/40 border border-zinc-900/60 hover:border-zinc-800 rounded-3xl overflow-hidden shadow-2xl hover:shadow-[0_20px_50px_rgba(0,0,0,0.5)] transition-all duration-300">
                      {/* Image container */}
                      <div className={`overflow-hidden relative ${isFirst ? 'aspect-[16/9] lg:aspect-[2/1]' : 'aspect-[16/9]'}`}>
                        <OptimizedImage 
                          src={rel.image} 
                          alt={rel.title} 
                          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
                        />
                        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent pointer-events-none opacity-80" />
                        <span className="absolute top-4 left-4 px-3 py-1 bg-black/65 backdrop-blur-md border border-zinc-800 text-emerald-400 text-[10px] font-bold uppercase tracking-widest rounded-full">
                          {rel.category}
                        </span>
                      </div>

                      {/* Content panel */}
                      <div className="p-6 sm:p-8 flex-grow flex flex-col justify-between">
                        <div>
                          <div className="flex items-center gap-3 text-xs text-zinc-500 mb-3 font-mono">
                            <span>{rel.date}</span>
                            <span className="w-1 h-1 rounded-full bg-zinc-800" />
                            <span>{rel.readTime || '5 min de leitura'}</span>
                          </div>
                          
                          <h4 className={`font-display font-medium text-white group-hover:text-emerald-400 transition-colors ${isFirst ? 'text-2xl sm:text-3xl' : 'text-xl'} mb-3 leading-tight`}>
                            {rel.title}
                          </h4>
                          
                          <p className="text-zinc-400 font-light text-sm leading-relaxed mb-6 line-clamp-3">
                            {rel.excerpt}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-zinc-400 group-hover:text-emerald-300 transition-colors">
                          <span>Ler o artigo completo</span>
                          <ArrowRight size={14} className="transform group-hover:translate-x-1.5 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      <div className="border-t border-zinc-900 mt-24 pt-12 flex flex-col items-center">
         <p className="text-zinc-500 font-medium mb-6 uppercase tracking-widest text-xs">Gostou da leitura?</p>
         <Link to="/articles" className="group bg-gradient-to-r from-emerald-500 to-teal-400 text-black px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:scale-[1.03] active:scale-95 shadow-[0_0_20px_rgba(16,185,129,0.25)] hover:shadow-[0_0_30px_rgba(16,185,129,0.4)]">
            Explorar outros artigos
         </Link>
      </div>

      {/* Premium Floating Share Action (FAB) Menu */}
      <div className="fixed bottom-24 right-6 md:right-8 z-50 flex flex-col items-end gap-3 font-sans">
        <AnimatePresence>
          {fabOpen && (
            <motion.div 
              initial={{ opacity: 0, y: 15, scale: 0.85 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 15, scale: 0.85 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="flex flex-col gap-3 mb-2 items-end"
            >
              {/* Twitter Button */}
              <a 
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(window.location.href)}`} 
                target="_blank" 
                rel="noopener noreferrer"
                onClick={() => setFabOpen(false)}
                title="Compartilhar no Twitter/X" className="flex items-center gap-3 px-4 py-2.5 rounded-full border border-zinc-800 bg-zinc-950/90 text-zinc-400 hover:text-[#1DA1F2] hover:border-[#1DA1F2]/50 hover:shadow-[0_0_15px_rgba(29,161,242,0.2)] transition-all text-xs font-semibold uppercase tracking-wider backdrop-blur-md group"
              >
                <span>Twitter / X</span>
                <Twitter size={15} className="group-hover:scale-110 transition-transform" />
              </a>

              {/* LinkedIn Button */}
              <a 
                href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(window.location.href)}&title=${encodeURIComponent(article.title)}`} 
                target="_blank" 
                rel="noopener noreferrer"
                onClick={() => setFabOpen(false)}
                title="Compartilhar no LinkedIn" className="flex items-center gap-3 px-4 py-2.5 rounded-full border border-zinc-800 bg-zinc-950/90 text-zinc-400 hover:text-[#0A66C2] hover:border-[#0A66C2]/50 hover:shadow-[0_0_15px_rgba(10,102,194,0.2)] transition-all text-xs font-semibold uppercase tracking-wider backdrop-blur-md group"
              >
                <span>LinkedIn</span>
                <Linkedin size={15} className="group-hover:scale-110 transition-transform" />
              </a>

              {/* Copy URL Button */}
              <button 
                onClick={() => { copyLink(); }} title="Copiar link"
                className={`flex items-center gap-3 px-4 py-2.5 rounded-full border transition-all text-xs font-semibold uppercase tracking-wider backdrop-blur-md group ${copied ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.2)]' : 'border-zinc-800 bg-zinc-950/90 text-zinc-400 hover:text-emerald-400 hover:border-emerald-500/50 hover:shadow-[0_0_15px_rgba(16,185,129,0.2)]'}`}
              >
                <span>{copied ? 'Link copiado!' : 'Copiar link'}</span>
                {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} className="group-hover:scale-110 transition-transform" />}
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Core FAB Toggle Button */}
        <button 
          onClick={() => setFabOpen(!fabOpen)} 
          className={`relative w-14 h-14 rounded-full flex items-center justify-center text-white shadow-xl transition-all duration-300 select-none outline-none group active:scale-95
            ${fabOpen 
              ? 'bg-zinc-900 border border-zinc-800 hover:bg-zinc-800' 
              : 'bg-emerald-500 hover:bg-emerald-400 hover:shadow-[0_0_25px_rgba(16,185,129,0.55)]'
            }`}
          aria-label="Opções de compartilhamento fixas"
        >
          {fabOpen ? (
            <X size={20} className="transform rotate-0 transition-transform duration-300" />
          ) : (
            <Share2 size={20} className="transform rotate-0 group-hover:scale-110 transition-transform duration-300" />
          )}

          {/* Glowing pulse indicator when closed */}
          {!fabOpen && (
            <span className="absolute -inset-1 rounded-full animate-ping bg-emerald-500/10 pointer-events-none -z-10" />
          )}
        </button>
      </div>
    </motion.article>

    {/* Table of Contents Sidebar */}
    <aside className="hidden lg:block sticky top-32 overflow-hidden px-6 py-8 rounded-3xl bg-zinc-950/50 border border-zinc-900/50 shadow-xl backdrop-blur-md w-full">
      {/* Subtle Hero Pattern for the aside */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none z-0" 
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }}
      />
      
      <div className="relative z-10 w-full font-sans">
        <h4 className="text-[10px] font-bold uppercase tracking-[0.22em] text-zinc-500 mb-6 flex items-center gap-2 select-none">
          <ChevronRight size={14} className="text-emerald-400" /> Índice do Conteúdo
        </h4>
        
        <motion.nav 
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.08 }
            }
          }}
          className="flex flex-col gap-1 border-l border-zinc-900/80 relative" 
          aria-label="Navegação secundária"
        >
          {toc.map((item, index) => {
            const isActive = activeSection === item.id;
            return (
              <motion.a 
                key={item.id} 
                href={`#${item.id}`}
                aria-current={isActive ? "location" : undefined}
                variants={{
                  hidden: { opacity: 0, y: 10 },
                  visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100 } }
                }}
                whileHover={{ x: 3 }}
                className={
                  `text-xs py-2 transition-all duration-300 relative leading-snug flex items-center gap-3
                  ${item.level === 3 ? 'pl-6 text-[11px]' : 'pl-4'}
                  ${isActive 
                    ? 'text-emerald-400 font-semibold before:absolute before:left-[-1px] before:top-0 before:bottom-0 before:w-[2px] before:bg-emerald-400 before:shadow-[0_0_10px_#10b981] before:rounded-r-full' 
                    : 'text-zinc-500 hover:text-zinc-200'}`
                }
              >
                {isActive && (
                  <motion.span 
                    layoutId="activeIndicatorDot"
                    className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#10b981]"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <span className="truncate">{item.text}</span>
              </motion.a>
            );
          })}
        </motion.nav>
      </div>
    </aside>
    </div>
  );
}
