import { motion } from 'motion/react';
import SectionHeader from '../components/SectionHeader';
import { Target, Lightbulb, Code2, Layers, Briefcase, Zap } from 'lucide-react';

export default function About() {
  const values = [
    { title: 'Minimalismo Funcional', desc: 'Acreditamos que menos é mais, desde que a função não seja comprometida. A função sempre guia a forma.', icon: <Lightbulb size={24} /> },
    { title: 'Código Limpo', desc: 'Prezamos por arquiteturas modernas (Clean Architecture) e escaláveis, garantindo estabilidade e alta performance.', icon: <Code2 size={24} /> },
    { title: 'Atenção aos Detalhes', desc: 'Compreendemos que o refinamento final, de micro-interações a acessibilidade, faz a diferença na experiência.', icon: <Target size={24} /> },
  ];

  const services = [
    { title: 'Consultoria Estratégica & Arquitetura', desc: 'Planejamento de alto nível focado no alinhamento de objetivos de negócio com viabilidade técnica. Desenho de arquitetura de software (Microservices, Serverless) priorizando escalabilidade e segurança na nuvem.', icon: <Lightbulb size={24} /> },
    { title: 'Desenvolvimento Web Fullstack', desc: 'Construção de aplicações robustas de ponta a ponta utilizando o ecossistema React, Next.js, Node.js e bancos de dados SQL/NoSQL, focando em performance, SEO estrutural e alto desempenho.', icon: <Code2 size={24} /> },
    { title: 'Melhoria Contínua & Performance', desc: 'Auditorias implacáveis focaadas em otimização de velocidade de carregamento (Core Web Vitals), remoção de gargalos, acessibilidade (WCAG) e implementações contínuas por meio de metodologias ágeis (Scrum/Kanban).', icon: <Zap size={24} /> },
    { title: 'Design System & UI/UX Design', desc: 'Elaboração de interfaces elegantes, responsivas e sistemas de componentes consistentes (Figma para React) visando aumentar o engajamento e a taxa de retenção dos usuários.', icon: <Layers size={24} /> },
    { title: 'Integração de APIs de Terceiros', desc: 'Conexões complexas e seguras entre sistemas legados e plataformas modernas de pagamento, ERPs, CRMs e APIs de inteligência artificial ou machine learning.', icon: <Target size={24} /> },
    { title: 'Suporte Técnico Especializado', desc: 'Garantia de operação por meio de contratos de SLA, manutenção de infraestrutura em nuvem, gestão de logs, monitoramento 24/7 e refatoração preventiva.', icon: <Briefcase size={24} /> },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemAnim = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, } }
  };

  return (
    <motion.div initial="hidden" animate="show" exit="hidden" variants={container}>
      <SectionHeader 
        title={<>Sobre o <span className="font-serif italic text-zinc-500">Studio.</span></>} 
        subtitle="Mais do que apenas código. Construímos engenharia focada no sucesso e na viabilidade técnica ao longo prazo." 
      />
      
      <motion.section variants={container} className="max-w-7xl mx-auto px-6 lg:px-8 mb-32 grid lg:grid-cols-2 gap-16 items-center">
        <motion.div 
          variants={itemAnim}
          className="aspect-[4/5] w-full max-w-[520px] mx-auto bg-zinc-900 rounded-3xl overflow-hidden relative group"
        >
          <img 
            src="https://i.pinimg.com/1200x/cb/cc/cb/cbcccb3fbdfbadd926ebd801054c7fb3.jpg" 
            alt="Foto de Pedro Oliver" 
            className="w-full h-full object-cover object-center opacity-80 group-hover:scale-105 transition-transform duration-1000"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />
          <div className="absolute bottom-8 left-8 right-8 pointer-events-none">
            <h3 className="text-2xl font-display font-medium text-white mb-2">Pedro Oliver</h3>
            <p className="text-zinc-300 font-light">Engenheiro de Software & Lead Designer</p>
          </div>
          <div className="absolute inset-0 border border-white/10 rounded-3xl pointer-events-none" />
        </motion.div>
        
        <div className="flex flex-col justify-center">
          <motion.h2 variants={itemAnim} className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-8">Quem sou & <br/>Nossa Trajetória</motion.h2>
          <div className="space-y-8">
            <motion.div variants={itemAnim}>
              <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-2 flex items-center gap-2"><Briefcase size={16}/> Trajetória & Experiência</h3>
              <p className="text-zinc-300 leading-relaxed font-light text-lg mb-4">
                Com mais de uma década de experiência transformando problemas complexos de negócios em interfaces digitais intuitivas, minha trajetória iniciou no coração da engenharia front-end e expandiu-se pela arquitetura de sistemas distribuídos e liderança técnica em equipes multidisciplinares e de alta performance.
              </p>
              <p className="text-zinc-300 leading-relaxed font-light text-lg">
                Gerencie ativamente o desenvolvimento ágil utilizando as metodologias <strong>Scrum e Kanban</strong>, certificando que a esteira de entregas atenda com exatidão a visão do produto. Possuo certificações em arquitetura AWS e profundo domínio em ecossistema JavaScript (React, Next.js, TypeScript e Node.js).
              </p>
            </motion.div>
            <motion.div variants={itemAnim}>
              <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-2 flex items-center gap-2"><Target size={16}/> O Objetivo</h3>
              <p className="text-zinc-300 leading-relaxed font-light text-lg">
                Nosso principal objetivo é construir e escalar produtos de alto impacto. Projetos que não apenas possuam a beleza estética e acessibilidade, mas que de fato convertam e resolvam problemas de escalabilidade real, superando expectativas nos mais cruciais indicadores da engenharia: <em>disponibilidade, usabilidade e confiabilidade</em>.
              </p>
            </motion.div>
            <motion.div variants={itemAnim}>
              <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-2 flex items-center gap-2"><Zap size={16}/> Áreas de Atuação & Diferenciais</h3>
              <p className="text-zinc-300 leading-relaxed font-light text-lg">
                Em oposição às tradicionais agências de volume de software, eu aplico uma consultoria hiper focada em qualidade e entrega técnica refinada. Atuamos como verdadeiros parceiros e braços tecnológicos — do refinamento de interface com usuários (UX/UI), segurança arquitetural e design system até a garantia da resiliência contínua dos deploys na infraestrutura.
              </p>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Serviços */}
      <section className="bg-gradient-to-b from-black via-zinc-950 to-black border-y border-zinc-900 py-32 mb-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div variants={container} initial="hidden" whileInView="show" viewport={{ once: true, margin: '-50px' }} className="text-center mb-16">
            <h2 className="text-4xl font-display font-medium tracking-tight mb-6">Serviços Especializados</h2>
            <p className="text-zinc-400 max-w-2xl mx-auto text-lg font-light leading-relaxed">
              Focamos em áreas de profundo domínio técnico. Entregamos desde a identidade do sistema até a implementação do backend que sustenta o ecossistema.
            </p>
          </motion.div>

          <motion.div variants={container} initial="hidden" whileInView="show" viewport={{ once: true, margin: '-50px' }} className="grid md:grid-cols-3 gap-8">
            {services.map((s, i) => (
              <motion.div key={i} variants={itemAnim} className="p-8 border border-zinc-800 bg-gradient-to-br from-zinc-900/50 to-black rounded-3xl hover:border-zinc-700 hover:bg-zinc-900/90 transition-all duration-300 hover:-translate-y-2 group shadow-lg">
                <div className="w-14 h-14 bg-zinc-800 text-white rounded-2xl flex items-center justify-center mb-6 border border-zinc-700 shadow-inner group-hover:bg-white group-hover:text-black transition-colors duration-500">
                  {s.icon}
                </div>
                <h3 className="text-2xl font-display font-medium mb-4">{s.title}</h3>
                <p className="text-zinc-400 font-light leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 lg:px-8 mb-32">
        <h2 className="text-4xl font-display font-medium tracking-tight mb-16 text-center">Pilares Fundamentais</h2>
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-50px' }}
          className="grid md:grid-cols-3 gap-8 mb-32"
        >
          {values.map((v, i) => (
            <motion.div 
              key={i}
              variants={itemAnim}
              className="p-10 border border-zinc-900 bg-gradient-to-b from-zinc-950/40 to-black backdrop-blur-sm rounded-3xl hover:border-zinc-700 hover:bg-zinc-900 transition-all duration-300 shadow-xl"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-black font-display font-bold text-xl shadow-[0_0_20px_rgba(255,255,255,0.1)]">
                  0{i + 1}
                </div>
                <div className="text-zinc-500">{v.icon}</div>
              </div>
              <h3 className="text-2xl font-display font-medium mb-4 tracking-tight">{v.title}</h3>
              <p className="text-zinc-400 font-light leading-relaxed">{v.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Call to action section */}
        <motion.div 
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           viewport={{ once: true }}
           transition={{ duration: 0.5 }}
           className="relative rounded-3xl overflow-hidden bg-zinc-900 border border-zinc-800 p-12 lg:p-20 text-center"
         >
           <div className="absolute inset-0 bg-gradient-to-br from-zinc-800/20 via-zinc-900 to-black pointer-events-none" />
           
           <div className="relative z-10 max-w-3xl mx-auto flex flex-col items-center">
             <div className="w-16 h-16 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(255,255,255,0.1)]">
               <Zap size={28} className="text-white" />
             </div>
             
             <h3 className="text-3xl md:text-5xl font-display font-medium text-white mb-6 tracking-tight leading-tight">
               Pronto para transformar sua visão em realidade tecnológica?
             </h3>
             
             <p className="text-zinc-400 text-lg font-light mb-10 max-w-2xl leading-relaxed">
               Nossa equipe está pronta para avaliar o escopo, entender as necessidades exclusivas do seu modelo de negócio e propor a rota técnica ideal para escalar a operação com maestria.
             </p>
             
             <a href="/contact" className="inline-flex items-center justify-center gap-3 bg-white text-black px-10 py-5 rounded-full font-semibold tracking-wide transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_40px_rgba(255,255,255,0.3)]">
               Iniciar uma conversa hoje mesmo
             </a>
           </div>
         </motion.div>
      </section>
    </motion.div>
  );
}
