import { motion } from 'motion/react';
import { ArrowRight, Calendar, Sparkles, Rocket, Cpu } from 'lucide-react';
import { Link } from 'react-router-dom';
import { newsData } from '../data/news';

export default function News() {
  const updates = Object.values(newsData).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen"
    >
      <div className="max-w-5xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16 border-b border-zinc-900 pb-12"
        >
          <h1 className="text-4xl md:text-6xl font-display font-medium tracking-tight mb-6 leading-[1.1] text-white">
            Novidades
          </h1>
          <p className="text-lg text-zinc-400 font-light max-w-2xl leading-relaxed">
            Anúncios, melhorias de plataforma, lançamentos de features e os últimos comunicados de Pedro Oliver Dev.
          </p>
        </motion.div>

        <div className="flex flex-col gap-12">
          {updates.map((item, i) => (
            <motion.article 
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group flex flex-col md:flex-row gap-8 items-start rounded-3xl p-6 lg:p-8 border border-zinc-900 bg-zinc-950/40 hover:bg-zinc-900/40 hover:border-zinc-800 transition-all duration-300 shadow-xl"
            >
              {item.image ? (
                <div className="w-full md:w-64 aspect-[4/3] rounded-2xl overflow-hidden shrink-0 border border-zinc-800 relative bg-zinc-900">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700" loading="lazy" />
                  <div className="absolute inset-0 bg-black/40 pointer-events-none group-hover:bg-black/20 transition-colors" />
                </div>
              ) : (
                <div className="w-full md:w-64 aspect-[4/3] rounded-2xl shrink-0 border border-zinc-800 bg-zinc-900 flex items-center justify-center relative overflow-hidden group-hover:border-zinc-700 transition-colors">
                  <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center text-zinc-500 group-hover:text-white group-hover:bg-zinc-700 transition-colors duration-500 shadow-inner">
                    <Rocket size={24} />
                  </div>
                </div>
              )}
              
              <div className="flex-1 flex flex-col pt-2 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded-full">{item.category}</span>
                  <div className="flex items-center gap-1.5 text-zinc-500 text-xs font-semibold uppercase tracking-widest">
                    <Calendar size={14} />
                    {item.date}
                  </div>
                </div>
                
                <h2 className="text-2xl lg:text-3xl font-display font-medium text-white mb-4 leading-tight group-hover:text-zinc-200 transition-colors">
                  {item.title}
                </h2>
                <p className="text-zinc-400 font-light leading-relaxed mb-6">
                  {item.description}
                </p>
                
                <Link to={`/news/${item.id}`} className="mt-auto flex items-center gap-2 text-sm font-semibold tracking-widest uppercase text-white hover:text-zinc-300 transition-colors w-fit pt-4">
                  <span>Ler Mais</span>
                  <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
