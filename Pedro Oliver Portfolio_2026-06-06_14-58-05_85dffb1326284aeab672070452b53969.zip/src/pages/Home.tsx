import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, ArrowUpRight, MessageSquare, Star, LifeBuoy, ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { articlesData } from '../data/articles';

export default function Home() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [isHoveringTestimonial, setIsHoveringTestimonial] = useState(false);

  useEffect(() => {
    if (isHoveringTestimonial) return;
    
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isHoveringTestimonial]);
  const stagger = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, } }
  };

  const faqs = [
    { q: "Qual o prazo médio de entrega?", a: "Depende da complexidade, mas um design premium e desenvolvimento inicial de uma MVP varia entre 4 a 8 semanas." },
    { q: "Vocês fazem manutenção de código legado?", a: "Atuamos em reescrita e refatoração para arquiteturas limpas (Clean Arch), mas preferimos re-plataformar a manter tecnologias obsoletas." },
    { q: "Quais tecnologias vocês usam?", a: "React, Next.js, Node.js, TypeScript e integrações robustas para a nuvem." },
  ];

  const testimonials = [
    { 
      text: "O nível de atenção aos detalhes e maestria na execução técnica nos impressionou muito. O resultado final excedeu todas as expectativas. Recomendo para qualquer projeto tecnológico de alto calibre.", 
      name: "João Pedro Maciel", 
      role: "CEO & Fundador", 
      company: "TechCorp Global", 
      avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=150&q=80",
      stars: 5 
    },
    { 
      text: "Código absurdamente limpo, o que permitiu nossa equipe interna manter as automações de forma trivial. O suporte técnico de SLA entregue por Pedro Oliver é impecável.", 
      name: "Mariana Silva de Souza", 
      role: "CTO & Sócia", 
      company: "Fintech Venture", 
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
      stars: 5 
    },
    { 
      text: "Estética visual apurada combinada com performance insana de carregamento. O aumento na nossa taxa de conversão orgânica de Leads saltou 42% no primeiro bimestre pós-lançamento.", 
      name: "Lucas Ferreira", 
      role: "Head de Inovação Digital", 
      company: "AeroSpace Media", 
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
      stars: 5 
    },
  ];

  const trends = [
    { title: "Arquiteturas Headless", desc: "Desacoplamos completamente a interface (Front-end) do banco de dados (Back-end) para garantir performance inigualável em múltiplas plataformas simultâneas." },
    { title: "Interfaces Orientadas a IA", desc: "Criação de ecossistemas preditivos que se adaptam as intenções e fluxos de trabalho únicos dos usuários finais, escalando conversão e conforto." },
    { title: "Infraestrutura Serverless", desc: "Processamentos ativados só sob demanda. Custo proporcional escalável, sem necessidade de provisão ou manutenção extrema de servidores bare-metal." }
  ];

  const stats = [
    { value: "40+", label: "Projetos Lançados", desc: "Entre MVPs, sistemas completos e APIs" },
    { value: "99.9%", label: "Uptime Garantido", desc: "Nas infraestruturas que gerenciamos" },
    { value: "12", label: "Prêmios de Design", desc: "Reconhecimento em usabilidade e UX" },
    { value: "24/7", label: "Suporte Dedicado", desc: "Para contratos de SLA enterprise" }
  ];

  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="w-full max-w-7xl mx-auto px-6 lg:px-8 min-h-[90vh] flex flex-col justify-center relative pt-20">
        <div className="particles-bg">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="particle"></div>
          ))}
        </div>
        <div className="absolute top-1/2 right-0 -translate-y-1/2 w-2/3 aspect-square bg-zinc-900/30 rounded-full blur-[140px] -z-10 pointer-events-none" />
        
        <motion.div 
          variants={stagger}
          initial="hidden"
          animate="show"
          className="max-w-5xl"
        >
          <motion.div variants={item} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-zinc-800 bg-zinc-900/50 text-xs font-semibold uppercase tracking-widest text-zinc-300 mb-8 backdrop-blur-sm shadow-[0_0_15px_rgba(255,255,255,0.05)]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_10px_rgba(52,211,153,0.5)]" />
            Vagas abertas para desenvolvimento em Q3 2024
          </motion.div>
          
          <motion.h1 variants={item} className="text-5xl md:text-7xl lg:text-[5.5rem] font-display font-medium tracking-tight leading-[1] mb-8 text-white">
            Transformamos a sua visão em <span className="text-transparent bg-clip-text bg-gradient-to-r from-zinc-300 to-zinc-600">código.</span><br />
            Sem atalhos. Sem concessões.
          </motion.h1>
          
          <motion.p variants={item} className="text-lg md:text-xl text-zinc-400 font-light max-w-2xl mb-12 leading-relaxed">
            Somos um estúdio de engenharia e design focado na criação de plataformas de alto impacto. Nós não apenas construímos softwares, nós elaboramos experiências excepcionais para usuários e bases sólidas para o seu negócio blindado para o futuro.
          </motion.p>
          
          <motion.div variants={item} className="flex flex-col sm:flex-row gap-5">
            <Link 
              to="/projects" 
              aria-label="Ver todos os projetos"
              className="group relative inline-flex items-center justify-center gap-3 bg-white text-black px-8 py-4 rounded-full font-semibold tracking-wide transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.15)] hover:shadow-[0_0_40px_rgba(255,255,255,0.3)]"
            >
              Explorar nossos cases
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              <span className="absolute -top-12 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-zinc-900 text-white text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-700">
                Veja o que já construímos
              </span>
            </Link>
            <Link 
              to="/contact" 
              aria-label="Falar com nossa equipe"
              className="group relative inline-flex items-center justify-center gap-3 border border-zinc-700 bg-zinc-900/50 backdrop-blur text-white px-8 py-4 rounded-full font-medium tracking-wide transition-all hover:border-zinc-500 hover:bg-zinc-800 active:scale-95"
            >
              Iniciar uma conversa
              <span className="absolute -top-12 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-zinc-900 text-white text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-700">
                Orçamentos em 24h
              </span>
            </Link>
          </motion.div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="w-full bg-zinc-950/50 border-y border-zinc-900/50 py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-zinc-900">
            {stats.map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`flex flex-col items-center text-center ${i === 0 ? '' : 'pl-8'}`}
              >
                <span className="text-4xl md:text-5xl font-display font-medium text-white mb-2">{stat.value}</span>
                <span className="text-zinc-300 font-semibold text-sm tracking-widest uppercase mb-1">{stat.label}</span>
                <span className="text-zinc-500 text-xs font-light max-w-[200px]">{stat.desc}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pedro Oliver Dev Intro */}
      <section className="w-full relative">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-32 mb-16 border-b border-zinc-900/50">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-50px' }} className="mb-16">
             <h2 className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-4 text-white">A arquitetura por trás da inovação.</h2>
             <p className="text-zinc-400 max-w-4xl font-light text-lg mb-6 leading-relaxed">
               A <strong>Pedro Oliver Dev</strong> é uma iniciativa de engenharia de software focada em resolver problemas de missão crítica. Nossa expertise abrange desde o <strong>desenvolvimento de infraestruturas resilientes e sistemas enterprise</strong> até a arquitetura de dados, automações orientadas por IA, integrações B2B escaláveis e consultoria contínua.
             </p>
             <p className="text-zinc-400 max-w-4xl font-light text-lg mb-6 leading-relaxed">
               Assumimos o desafio de engenharia integralmente: <strong>transformamos as complexidades operacionais dos nossos clientes em plataformas de altíssima performance, com segurança de nível institucional e design impecável.</strong>
             </p>
             <p className="text-zinc-400 max-w-4xl font-light text-lg leading-relaxed">
               Acreditamos que a abstração tecnológica deve empoderar decisões estratégicas. Por isso, valorizamos a qualidade matemática em cada linha de código, o desempenho latente sem comprometer a semântica visual, a segurança inabalável e a arquitetura *future-proof*.
             </p>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8">
             {trends.map((trend, i) => (
               <motion.div 
                 key={i}
                 initial={{ opacity: 0, y: 30 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true, margin: '-50px' }}
                 transition={{ duration: 0.4, delay: i * 0.1 }}
                 className="p-8 rounded-3xl bg-zinc-900/30 border border-zinc-800 hover:bg-zinc-900/80 hover:border-zinc-700 transition-all group shadow-lg"
               >
                 <h3 className="text-2xl font-display font-medium mb-4 text-white group-hover:text-zinc-200 transition-colors">{trend.title}</h3>
                 <p className="text-zinc-400 font-light leading-relaxed mb-6">{trend.desc}</p>
               </motion.div>
             ))}
          </div>
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="mt-12 flex justify-center">
              <Link to="/about" className="inline-flex items-center justify-center gap-3 bg-gradient-to-r from-zinc-800 to-zinc-900 border border-zinc-700 text-white px-8 py-4 rounded-full font-medium tracking-wide transition-all hover:bg-zinc-800 hover:border-zinc-600 hover:shadow-[0_0_20px_rgba(255,255,255,0.1)] active:scale-95">
                Conheça nossos serviços <ArrowRight size={18} />
              </Link>
          </motion.div>
        </div>
      </section>

      {/* Hosting Recommendations Banner -> Replaced with Full Section later, so keep this tight or let's remove the simple logos and expand it below */}
      <section className="w-full bg-zinc-950 py-32 border-b border-zinc-900/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-2/3 aspect-square bg-zinc-800/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-50px' }} className="mb-16 max-w-2xl">
             <h2 className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-4">Onde hospedar suas ideias?</h2>
             <p className="text-zinc-400 font-light text-lg">
               Independente do seu projeto — sejam bots, dashboards, sites institucionais, APIs robustas, sistemas web complexos, landing pages ou aplicações completas em produção — escolher uma boa casa para o seu código é fundamental. Conheça nossas plataformas favoritas, que reúnem simplicidade, poder e segurança.
             </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              { 
                name: 'Square Cloud', 
                url: 'https://squarecloud.app/pt-br/home', 
                desc: 'A plataforma ideal para dar vida rápida às suas ideias. Descomplicada e adorada pelos desenvolvedores.',
                benefits: 'Deploy fácil, CLI potente e excelente custo-benefício.',
                projects: 'Bots para Discord, APIs em Node/Python, pequenos sites e provas de conceito.'
              },
              { 
                name: 'Hostinger', 
                url: 'https://www.hostinger.com/br', 
                desc: 'Gigante global conhecida por conciliar estabilidade fantástica e acessibilidade em um único lugar.',
                benefits: 'Painel hPanel ultra intuitivo, domínio grátis e suporte 24/7 humanizado.',
                projects: 'Sites WordPress, portfólios, lojas virtuais, sistemas PHP e landing pages de conversão.'
              },
              { 
                name: 'Discloud', 
                url: 'https://discloud.com/', 
                desc: 'Uma escolha brilhante da comunidade para hospedar bots e pequenos projetos web com rapidez inacreditável.',
                benefits: 'Foco total no desenvolvedor, interface amigável e logs em tempo real.',
                projects: 'Bots criativos, painéis de controle compactos, scripts agendados e projetos multi-linguagem.'
              },
              { 
                name: 'ShardCloud', 
                url: 'https://shardcloud.app/en', 
                desc: 'A solução emergente voltada para aplicações fluidas que exigem mais proximidade com a infraestrutura e recursos maleáveis.',
                benefits: 'Alta flexibilidade, estabilidade confiável e precificação justa baseada no tamanho da sua operação.',
                projects: 'Aplicações full-stack sob medida, sistemas web mais elaborados e contêineres Docker.'
              }
            ].map((hosting, idx) => (
              <motion.div 
                key={hosting.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="group p-8 rounded-3xl bg-black border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900/50 transition-all duration-300 flex flex-col justify-between shadow-lg"
              >
                <div>
                  <h3 className="text-2xl font-display font-medium text-white mb-3">{hosting.name}</h3>
                  <p className="text-zinc-400 font-light mb-6 leading-relaxed">{hosting.desc}</p>
                  
                  <div className="space-y-4 mb-8">
                    <div>
                      <h4 className="text-xs uppercase tracking-widest text-zinc-500 font-semibold mb-1">Principais Benefícios:</h4>
                      <p className="text-sm text-zinc-300 font-light">{hosting.benefits}</p>
                    </div>
                    <div>
                      <h4 className="text-xs uppercase tracking-widest text-zinc-500 font-semibold mb-1">Ideal Para:</h4>
                      <p className="text-sm text-zinc-300 font-light">{hosting.projects}</p>
                    </div>
                  </div>
                </div>
                <a 
                  href={hosting.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="relative inline-flex items-center gap-2 group-hover:gap-3 text-sm font-semibold tracking-wide border-b border-transparent group-hover:border-zinc-500 pb-1 text-zinc-400 group-hover:text-white transition-all w-fit group/btn"
                  aria-label={`Acessar site da ${hosting.name}`}
                >
                  Conhecer {hosting.name} <ArrowUpRight size={16} className="text-zinc-600 group-hover:text-zinc-400" />
                  <span className="absolute -top-10 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover/btn:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800">
                    Acessar {hosting.name}
                  </span>
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects Teaser */}
      <section className="w-full max-w-7xl mx-auto px-6 lg:px-8 py-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6"
        >
          <div>
            <h2 className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-4">Trabalhos Selecionados</h2>
            <p className="text-zinc-400 max-w-md font-light text-lg">Uma pequena amostra do nosso compromisso com estética e arquitetura escalável.</p>
          </div>
          <Link to="/projects" className="group flex items-center gap-2 text-sm uppercase tracking-widest font-semibold text-white hover:text-zinc-300 transition-colors pb-2">
            Ver todos completos <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            { title: 'Plataforma Fintech', type: 'Web Application © 2024', img: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80&grayscale=true' },
            { title: 'Sistema de Design', type: 'Component Library © 2024', img: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80&grayscale=true' }
          ].map((project, i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0, y: 30 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true, margin: '-50px' }}
               transition={{ duration: 0.8, delay: i * 0.15, }}
               className="group cursor-pointer relative block"
             >
               <div className="w-full aspect-[4/3] bg-zinc-900 rounded-3xl overflow-hidden mb-6 relative">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity z-10 duration-500" />
                  <img src={project.img} alt={project.title} className="w-full h-full object-cover grayscale transition-all duration-1000 group-hover:scale-110 group-hover:grayscale-0 opacity-80 group-hover:opacity-100" />
               </div>
               <div className="flex justify-between items-start">
                 <div>
                   <h3 className="text-2xl font-display font-medium mb-2 group-hover:text-zinc-300 transition-colors">{project.title}</h3>
                   <p className="text-zinc-400 text-sm font-mono">{project.type}</p>
                 </div>
                 <div className="w-12 h-12 rounded-full border border-zinc-800 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300 group-hover:scale-110">
                   <ArrowUpRight size={20} />
                 </div>
               </div>
             </motion.div>
          ))}
        </div>
      </section>

      {/* Testimonials Carousel */}
      <section className="w-full bg-gradient-to-b from-zinc-950 to-black border-y border-zinc-900 py-32 overflow-hidden relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 aspect-[2/1] bg-zinc-900/20 rounded-[100%] blur-[120px] -z-10 pointer-events-none opacity-50" />
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-center mb-16">
             <h2 className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-4 text-white">Opiniões que inspiram</h2>
             <p className="text-zinc-400 max-w-lg mx-auto">Experiências reais de clientes e parceiros que confiaram em nossa engenharia para escalar seus negócios.</p>
          </motion.div>
          
          <div 
            className="relative max-w-4xl mx-auto"
            onMouseEnter={() => setIsHoveringTestimonial(true)}
            onMouseLeave={() => setIsHoveringTestimonial(false)}
          >
             <AnimatePresence mode="wait">
                 <motion.div 
                   key={activeTestimonial}
                   initial={{ opacity: 0, x: 20 }} 
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -20 }}
                   transition={{ duration: 0.5, ease: "easeOut" }}
                   className="p-8 md:p-12 rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-900/60 to-black/80 backdrop-blur-md shadow-2xl relative"
                 >
                   {/* Background Quote Icon */}
                   <div className="absolute top-6 left-6 text-zinc-800/50 font-display text-8xl leading-none select-none pointer-events-none">"</div>
                   
                   <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center md:items-start text-center md:text-left">
                     <div className="shrink-0 relative">
                       <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-br from-zinc-600 to-zinc-900">
                         <img src={testimonials[activeTestimonial].avatar} alt={testimonials[activeTestimonial].name} className="w-full h-full rounded-full object-cover border-2 border-zinc-950" />
                       </div>
                       <div className="absolute -bottom-2 -right-2 bg-zinc-800 p-1.5 rounded-full border border-zinc-700 shadow-xl">
                          <Star size={12} className="text-zinc-300" fill="currentColor" />
                       </div>
                     </div>
                     <div className="flex-1">
                       <div className="flex gap-1 justify-center md:justify-start mb-6 text-zinc-400">
                          {[...Array(5)].map((_, j) => (
                             <Star 
                               key={j} 
                               size={14} 
                               fill={j < testimonials[activeTestimonial].stars ? "currentColor" : "none"} 
                               className={j < testimonials[activeTestimonial].stars ? "text-emerald-400" : "text-zinc-700"} 
                             />
                           ))}
                       </div>
                       <p className="text-white text-xl md:text-2xl font-light leading-relaxed mb-8 font-display tracking-tight">"{testimonials[activeTestimonial].text}"</p>
                       <div>
                         <p className="text-white font-medium tracking-wide text-sm md:text-base">{testimonials[activeTestimonial].name}</p>
                         <p className="text-zinc-500 text-xs md:text-sm mt-0.5 font-light">{testimonials[activeTestimonial].role} <span className="text-zinc-400 font-medium">@ {testimonials[activeTestimonial].company}</span></p>
                       </div>
                     </div>
                   </div>
                 </motion.div>
             </AnimatePresence>

             {/* Carousel Controls */}
             <div className="flex items-center justify-between mt-8 relative z-20">
               <div className="flex gap-3">
                 <button 
                    onClick={() => setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
                    aria-label="Depoimento Anterior"
                    className="w-10 h-10 rounded-full border border-zinc-800 bg-zinc-900/50 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-700 transition-colors"
                 >
                   <ChevronLeft size={18} />
                 </button>
                 <button 
                    onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
                    aria-label="Próximo Depoimento"
                    className="w-10 h-10 rounded-full border border-zinc-800 bg-zinc-900/50 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-700 transition-colors"
                 >
                   <ChevronRight size={18} />
                 </button>
               </div>
               
               <div className="flex gap-2">
                 {testimonials.map((_, i) => (
                   <button 
                     key={i} 
                     onClick={() => setActiveTestimonial(i)}
                     aria-label={`Ir para depoimento ${i + 1}`}
                     className={`h-1.5 rounded-full transition-all duration-300 ${i === activeTestimonial ? 'w-8 bg-zinc-400' : 'w-2 bg-zinc-800 hover:bg-zinc-700'}`}
                   />
                 ))}
               </div>
             </div>
          </div>
        </div>
      </section>

      {/* Articles Preview */}
      <section className="w-full bg-black py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6 border-b border-zinc-900 pb-8"
          >
            <div>
              <h2 className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-4">Insights & Artigos</h2>
              <p className="text-zinc-400 max-w-md font-light text-lg">Exploramos tecnologia, design e engenharia com profundidade.</p>
            </div>
            <Link to="/articles" className="group flex items-center gap-2 text-sm uppercase tracking-widest font-semibold text-white hover:text-zinc-300 transition-colors">
              Ler todas as publicações <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {articlesData.slice(0, 3).map((article, i) => (
              <motion.div 
                key={article.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group flex flex-col"
              >
                <Link to={`/articles/${article.id}`} className="block overflow-hidden rounded-2xl mb-6 aspect-video relative border border-zinc-900">
                  {article.image ? (
                    <img src={article.image} alt={article.title} className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-105" />
                  ) : (
                    <div className="w-full h-full bg-zinc-900 flex items-center justify-center transform transition-transform duration-700 group-hover:scale-105">
                      <span className="text-zinc-700 font-display">Sem imagem</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent pointer-events-none opacity-50 group-hover:opacity-30 transition-opacity" />
                  <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md border border-white/10 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest text-white">
                    {article.category}
                  </div>
                </Link>
                <div className="flex flex-col flex-1">
                  <div className="flex items-center gap-3 text-xs font-semibold tracking-widest text-zinc-500 uppercase mb-3">
                    <span>{article.date}</span>
                    {article.readTime && (
                      <>
                        <span className="w-1 h-1 rounded-full bg-zinc-700" />
                        <span>{article.readTime}</span>
                      </>
                    )}
                  </div>
                  <Link to={`/articles/${article.id}`}>
                    <h3 className="text-xl font-display font-medium text-white mb-3 group-hover:text-zinc-300 transition-colors line-clamp-2 leading-snug">
                      {article.title}
                    </h3>
                  </Link>
                  <p className="text-zinc-400 font-light text-sm line-clamp-2 mb-6">
                    {article.excerpt}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ & Support Preview */}
      <section className="w-full bg-gradient-to-b from-black to-zinc-950/30">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-32 grid md:grid-cols-2 gap-16 lg:gap-24">
            <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="flex flex-col justify-center">
               <h2 className="text-3xl md:text-4xl font-display font-medium tracking-tight mb-6">Perguntas Frequentes</h2>
               <div className="space-y-6">
                 {faqs.map((faq, i) => (
                    <div key={i} className="pb-6 border-b border-zinc-900 last:border-0 last:pb-0">
                       <h3 className="text-lg font-medium text-white mb-2">{faq.q}</h3>
                       <p className="text-zinc-400 font-light leading-relaxed">{faq.a}</p>
                    </div>
                 ))}
               </div>
               <Link to="/docs" className="mt-8 flex items-center gap-2 text-zinc-400 hover:text-white transition-colors w-fit text-sm font-medium tracking-widest uppercase">
                 Ver documentação <ArrowRight size={16} />
               </Link>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="p-10 rounded-3xl border border-zinc-800 bg-gradient-to-b from-zinc-900/50 to-zinc-950/80 flex flex-col justify-center items-start shadow-xl">
               <div className="w-14 h-14 bg-zinc-800 text-white rounded-full flex items-center justify-center mb-6 shadow-inner">
                 <LifeBuoy size={24} />
               </div>
               <h3 className="text-2xl font-display font-medium text-white mb-4">Precisa de Suporte?</h3>
               <p className="text-zinc-400 font-light leading-relaxed mb-8">
                 Nossa equipe está disponível para ajudar com projetos existentes, contratos ativos de SLA, ou apenas para tirar uma dúvida sobre nossa metodologia.
               </p>
               <Link to="/contact" className="group flex items-center justify-center gap-3 bg-gradient-to-r from-zinc-200 to-white text-black px-8 py-4 rounded-full font-semibold tracking-wide transition-all hover:scale-[1.03] active:scale-[0.98] w-full text-center shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]">
                 <MessageSquare size={18} /> Entrar em contato
               </Link>
            </motion.div>
        </div>
      </section>
    </div>
  );
}
