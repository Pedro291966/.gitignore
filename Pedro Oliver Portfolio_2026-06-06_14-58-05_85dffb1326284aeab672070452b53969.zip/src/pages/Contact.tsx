import { motion } from 'motion/react';
import { ArrowRight, Mail, MapPin, Clock, CheckCircle2 } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import React, { useState } from 'react';

export default function Contact() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => {
      setStatus('success');
      setTimeout(() => setStatus('idle'), 4000);
    }, 1500);
  }

  return (
    <div>
      <SectionHeader 
        title="Inicie uma conversa" 
        subtitle="Tem um projeto em mente? Preencha o formulário e nossa equipe de design strategy entrará em contato em 24h." 
      />
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 mb-32 grid md:grid-cols-2 gap-20">
        <motion.div
           initial={{ opacity: 0, x: -20 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.4 }}
        >
          <form className="flex flex-col gap-8" onSubmit={handleSubmit}>
            <div className="grid grid-cols-2 gap-8">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold tracking-widest uppercase text-zinc-500">Nome Completo</label>
                <input 
                  type="text" 
                  placeholder="Pedro Oliver" 
                  className="bg-transparent border-b border-zinc-800 py-3 text-white placeholder-zinc-700 outline-none focus:border-white transition-colors rounded-none"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold tracking-widest uppercase text-zinc-500">Email Corporativo</label>
                <input 
                   type="email" 
                   placeholder="seu@email.com" 
                   className="bg-transparent border-b border-zinc-800 py-3 text-white placeholder-zinc-700 outline-none focus:border-white transition-colors rounded-none"
                />
              </div>
            </div>
            
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold tracking-widest uppercase text-zinc-500">Tipo de Projeto</label>
              <select className="bg-transparent border-b border-zinc-800 py-3 text-zinc-300 outline-none focus:border-white transition-colors appearance-none rounded-none cursor-pointer">
                <option value="web" className="bg-zinc-900 text-white">Design & Desenvolvimento Web</option>
                <option value="app" className="bg-zinc-900 text-white">Aplicativo Mobile</option>
                <option value="brand" className="bg-zinc-900 text-white">Identidade Visual (Branding)</option>
                <option value="consulting" className="bg-zinc-900 text-white">Consultoria UI/UX</option>
              </select>
            </div>
            
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold tracking-widest uppercase text-zinc-500">Mensagem</label>
              <textarea 
                rows={5}
                placeholder="Conte-nos um pouco sobre a sua visão..."
                className="bg-transparent border-b border-zinc-800 py-3 text-white placeholder-zinc-700 outline-none focus:border-white transition-colors resize-none rounded-none"
              ></textarea>
            </div>
            
            <button 
              type="submit" 
              disabled={status !== 'idle'}
              className="group inline-flex items-center justify-between bg-gradient-to-r from-zinc-200 to-white text-black px-8 py-5 rounded-full font-semibold tracking-wide transition-all hover:scale-[1.02] active:scale-[0.98] mt-4 shadow-[0_0_20px_rgba(255,255,255,0.15)] hover:shadow-[0_0_35px_rgba(255,255,255,0.25)] disabled:pointer-events-none disabled:opacity-80 disabled:scale-100"
            >
              {status === 'idle' && <><span>Enviar Inquérito</span><ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" /></>}
              {status === 'submitting' && <span className="animate-pulse w-full text-center">Enviando...</span>}
              {status === 'success' && <div className="flex w-full justify-center items-center gap-2"><CheckCircle2 size={18} /> Recebido com sucesso!</div>}
            </button>
          </form>
        </motion.div>
        
        <motion.div
           initial={{ opacity: 0, x: 20 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.6, delay: 0.2 }}
           className="flex flex-col gap-12"
        >
           <div>
             <h3 className="text-2xl font-display font-medium tracking-tight mb-8">Informações Físicas</h3>
             <div className="flex flex-col gap-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 border border-zinc-900 bg-zinc-950 rounded-full"><MapPin size={24} className="text-zinc-400" /></div>
                  <div>
                    <h4 className="font-medium text-white mb-1">São Paulo, BR</h4>
                    <p className="text-zinc-500 text-sm leading-relaxed">Av. Brigadeiro Faria Lima, 3064<br/>Itaim Bibi - SP, 01451-000</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-3 border border-zinc-900 bg-zinc-950 rounded-full"><Mail size={24} className="text-zinc-400" /></div>
                  <div>
                    <h4 className="font-medium text-white mb-1">Novo Negócio</h4>
                    <p className="text-zinc-500 text-sm leading-relaxed">pedro@studio.com<br/>+55 11 93714 3103</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-3 border border-zinc-900 bg-zinc-950 rounded-full"><Clock size={24} className="text-zinc-400" /></div>
                  <div>
                    <h4 className="font-medium text-white mb-1">Horário de Operação</h4>
                    <p className="text-zinc-500 text-sm leading-relaxed">Segunda – Sexta<br/>09:00 – 18:00 (GMT-3)</p>
                  </div>
                </div>
             </div>
           </div>
           
           <div className="pt-12 border-t border-zinc-900">
             <h3 className="text-xs font-semibold tracking-widest uppercase text-zinc-500 mb-6">Redes Sociais</h3>
             <div className="flex gap-6">
               <a href="#" className="text-white hover:text-zinc-400 font-medium transition-colors">LinkedIn</a>
               <a href="#" className="text-white hover:text-zinc-400 font-medium transition-colors">Instagram</a>
               <a href="#" className="text-white hover:text-zinc-400 font-medium transition-colors">Behance</a>
               <a href="#" className="text-white hover:text-zinc-400 font-medium transition-colors">Twitter</a>
             </div>
           </div>
        </motion.div>
      </div>
    </div>
  );
}
