import { motion } from 'motion/react';
import SectionHeader from '../components/SectionHeader';
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export default function Policies() {
  const { hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const id = hash.replace('#', '');
      const element = document.getElementById(id);
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
      }
    }
  }, [hash]);

  const sections = [
    {
      id: 'termos-de-uso',
      title: 'Termos de Uso',
      content: 'Ao acessar e utilizar os serviços de Pedro Oliver Dev, você concorda em cumprir e se vincular a estes Termos de Serviço. Solicitamos a leitura cuidadosa das condições estabelecidas para o uso de nossas plataformas, códigos e artefatos de design. Violações destes termos podem resultar em encerramento da prestação de serviços.'
    },
    {
      id: 'privacidade',
      title: 'Política de Privacidade',
      content: 'A sua privacidade é levada extremamente a sério. Não vendemos, alugamos ou compartilhamos dados dos clientes com terceiros em hipótese alguma. As informações coletadas visam unicamente a melhoria contínua da prestação do serviço e faturamento legal. Todos os dados são armazenados em infraestruturas seguras e codificadas (criptografia in-transit e at-rest), seguindo as rigorosas premissas da LGPD (Brasil) e GDPR (Europa).'
    },
    {
      id: 'seguranca',
      title: 'Segurança & Proteção de Dados',
      content: 'Nossa infraestrutura emprega as mais eficientes diretrizes de segurança de software do mercado. Contamos com prevenção ativa contra ataques comuns (framework OWASP Top 10), firewalls de aplicação, rate-limiting e backups automatizados geo-redundantes distribuídos. Mantemos a confiança dos nossos visitantes operando um ambiente de Zero-Trust internamente.'
    },
    {
      id: 'reembolso',
      title: 'Política de Reembolso',
      content: 'Garantimos uma política de reembolso clara e honesta. Reembolsos integrais são processados incondicionalmente em até 7 dias após o pagamento inicial (durante a Discovery Phase), sem a necessidade de justificativas — sendo subtraídas apenas as taxas de processamento da via de pagamento escolhida (ex: tarifa do cartão). Após a aprovação do modelo final (Design) e o efetivo início da fase de Desenvolvimento, os valores retidos tornam-se não-reembolsáveis, devido à alocação dedicada de horas exclusivas do nosso time técnico ao seu projeto.'
    }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemAnim = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, } }
  };

  return (
    <motion.div initial="hidden" animate="show" exit="hidden" variants={container}>
      <SectionHeader 
        title="Políticas da Empresa" 
        subtitle="Nosso compromisso com a transparência, segurança das informações e respeito mútuo em todos os acordos comerciais." 
      />
      
      <div className="max-w-4xl mx-auto px-6 lg:px-8 mb-32">
        <motion.div variants={container} className="prose prose-invert prose-zinc max-w-none">
          <motion.p variants={itemAnim} className="text-zinc-400 font-light leading-relaxed mb-12 bg-zinc-900/50 p-6 rounded-2xl border border-zinc-800">
            Última atualização: 18 de Maio de 2024. <br />
            Se você tiver dúvidas técnicas ou jurídicas referentes ao tratamento das informações em seus projetos ou à nossa metodologia, envie um e-mail para <a href="mailto:contato@pedrooliver.dev" className="text-white hover:text-zinc-300 underline underline-offset-4 transition-colors">contato@pedrooliver.dev</a>.
          </motion.p>
          
          <div className="flex flex-col gap-16">
            {sections.map((sec, i) => (
              <motion.div variants={itemAnim} id={sec.id} key={i} className="border-t border-zinc-900 pt-12 mt-12 first:border-0 first:pt-0 first:mt-0 scroll-mt-32">
                <h2 className="text-3xl font-display font-medium text-white mb-6 tracking-tight">
                  <span className="text-zinc-600 mr-3">0{i + 1}.</span> {sec.title}
                </h2>
                <div className="text-zinc-400 font-light leading-relaxed text-lg">
                  {sec.content}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
