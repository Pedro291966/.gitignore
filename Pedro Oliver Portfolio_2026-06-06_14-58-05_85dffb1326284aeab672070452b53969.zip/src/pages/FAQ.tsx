import { motion } from 'motion/react';
import { Plus, Minus, Search, MessageCircleQuestion, Settings, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

const categories = [
  { id: 'projects', name: 'Projetos', icon: <Settings size={18} /> },
  { id: 'technical', name: 'Suporte Técnico', icon: <Search size={18} /> },
  { id: 'general', name: 'Dúvidas Gerais', icon: <MessageCircleQuestion size={18} /> }
];

const faqs = [
  {
    id: 1,
    categoryId: 'projects',
    question: "Como funciona o processo de desenvolvimento de um projeto?",
    answer: "Trabalhamos com uma abordagem ágil e iterativa. Iniciamos com uma imersão no seu modelo de negócio, seguida pelo design detalhado (UI/UX) das interfaces. Após aprovação, a engenharia entra em cena construindo APIs, banco de dados e front-end."
  },
  {
    id: 2,
    categoryId: 'projects',
    question: "Vocês trabalham com escopo fechado ou ágil?",
    answer: "Priorizamos entregas ágeis (Sprints). Cada ciclo gera uma entrega utilizável, permitindo feedbacks rápidos e ajustes de percurso. Contratos de escopo fechado são possíveis para projetos menores."
  },
  {
    id: 3,
    categoryId: 'technical',
    question: "O código gerado é propriedade da minha empresa?",
    answer: "Sim. Nenhuma trava ou vendor-lockin é imposta. Entregamos todo o repositório, documentação da arquitetura e manuais operacionais ao fim do projeto, para que seu próprio time possa evoluí-lo a qualquer momento."
  },
  {
    id: 4,
    categoryId: 'general',
    question: "Vocês atendem clientes globalmente?",
    answer: "Sim, atuamos com clientes em diversos fusos horários. Nossos processos assíncronos e documentação impecável garantem clareza no projeto, independentemente de onde você esteja."
  },
  {
    id: 5,
    categoryId: 'technical',
    question: "Quais tecnologias a Studio utiliza primariamente?",
    answer: "Nossa stack principal reflete a preferência da indústria de alto nível: React, TypeScript, Node.js (ou Go para microsserviços muito específicos), Tailwind CSS e provedores Cloud robustos."
  }
];

export default function FAQ() {
  const [activeCategory, setActiveCategory] = useState('projects');
  const [openIds, setOpenIds] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleQuestion = (id: number) => {
    setOpenIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const filteredFaqs = faqs.filter(faq => {
    const matchesCategory = faq.categoryId === activeCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch = query === '' || faq.question.toLowerCase().includes(query) || faq.answer.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen"
    >
      <div className="absolute top-0 right-0 w-1/2 aspect-square bg-zinc-800/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16 text-center"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-900/50 text-xs font-semibold uppercase tracking-widest text-zinc-300 mb-8 backdrop-blur-sm mx-auto">
            Central de Ajuda
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-medium tracking-tight mb-6 leading-[1.1] text-white">
            Perguntas Frequentes
          </h1>
          <p className="text-lg text-zinc-400 font-light max-w-2xl mx-auto leading-relaxed">
            Respostas diretas e precisas para as principais dúvidas sobre nossos processos, tecnologias e modelos de atuação técnica.
          </p>
        </motion.div>

        {/* Categories */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold tracking-wide transition-all shadow-md ${
                activeCategory === category.id 
                  ? 'bg-white text-black scale-105 shadow-[0_0_20px_rgba(255,255,255,0.15)]' 
                  : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-white hover:border-zinc-700'
              }`}
            >
              {category.icon}
              {category.name}
            </button>
          ))}
        </div>

        {/* FAQ Accordion */}
        <div className="flex flex-col gap-4">
          {filteredFaqs.map((faq, i) => {
            const isOpen = openIds.includes(faq.id);
            return (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                key={faq.id}
                className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/50 backdrop-blur transition-colors hover:border-zinc-700"
              >
                <button
                  onClick={() => toggleQuestion(faq.id)}
                  className="w-full px-6 py-6 flex items-start justify-between text-left gap-4"
                  aria-expanded={isOpen}
                >
                  <span className="font-display text-lg font-medium text-white group-hover:text-zinc-300 transition-colors">
                    {faq.question}
                  </span>
                  <div className={`mt-1 flex-shrink-0 text-zinc-500 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>
                    {isOpen ? <Minus size={20} /> : <Plus size={20} />}
                  </div>
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: isOpen ? 'auto' : 0, opacity: isOpen ? 1 : 0 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6 text-zinc-400 font-light leading-relaxed border-t border-zinc-800/50 pt-4 mt-2">
                    {faq.answer}
                  </div>
                </motion.div>
              </motion.div>
            );
          })}
        </div>

        {/* Support CTA */}
        <div className="mt-20 p-10 rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-900 to-black text-center shadow-xl">
          <h3 className="text-2xl font-display font-medium text-white mb-4">Ainda tem dúvidas?</h3>
          <p className="text-zinc-400 text-sm font-light mb-8 max-w-md mx-auto">
            Se a sua pergunta não foi respondida acima, nossa equipe está sempre disponível para entender o seu cenário com profundidade.
          </p>
          <Link to="/contact" className="inline-flex items-center justify-center gap-3 bg-white text-black px-8 py-3.5 rounded-full font-semibold tracking-wide transition-all hover:scale-105 active:scale-95 shadow-[0_0_15px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.3)]">
            Fale Conosco
            <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
