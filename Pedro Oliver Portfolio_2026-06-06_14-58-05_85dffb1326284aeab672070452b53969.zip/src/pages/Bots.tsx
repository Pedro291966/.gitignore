import { motion } from 'motion/react';
import { Bot, Zap, Shield, MessageSquare, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Bots() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen"
    >
      <div className="absolute top-0 right-0 w-1/2 aspect-square bg-zinc-800/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16 border-b border-zinc-900 pb-12 text-center md:text-left"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-900/50 text-xs font-semibold uppercase tracking-widest text-zinc-300 mb-8 backdrop-blur-sm">
            <Bot size={16} /> Soluções Automatizadas
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-medium tracking-tight mb-6 leading-[1.1] text-white">
            Bots & Automação Inteligente
          </h1>
          <p className="text-lg text-zinc-400 font-light max-w-2xl leading-relaxed mx-auto md:mx-0">
            Aumente o engajamento, reduza o tempo de resposta e automatize tarefas repetitivas com assistentes virtuais de alta performance e algoritmos reativos construídos por Pedro Oliver Dev.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {[
            {
              icon: <MessageSquare size={24} />,
              title: "Atendimento 24/7",
              desc: "Seus clientes nunca mais ficarão sem suporte. Agentes capazes de resolver problemas básicos imediatamente e passar tickets complexos para humanos."
            },
            {
              icon: <Zap size={24} />,
              title: "Onboarding Dinâmico",
              desc: "Recepção e triagem de novos usuários em comunidades Discord, Slack ou Telegram baseada em respostas de fluxo estruturado."
            },
            {
              icon: <Shield size={24} />,
              title: "Moderação & Segurança",
              desc: "Antispam ativo, bloqueio de exploits e gerenciamento de perfis maliciosos de forma automatizada e invisível."
            }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 border border-zinc-900 bg-zinc-950/40 hover:bg-zinc-900/50 hover:border-zinc-800 transition-all rounded-3xl group shadow-lg"
            >
               <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:text-white group-hover:bg-zinc-800 transition-colors mb-6 shadow-inner">
                 {feature.icon}
               </div>
               <h3 className="text-xl font-display font-medium text-white mb-3">{feature.title}</h3>
               <p className="text-zinc-400 leading-relaxed font-light">{feature.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="p-10 md:p-16 rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-900/80 to-black relative overflow-hidden group shadow-2xl"
        >
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1620825937374-87fc1d6aaf2c?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center opacity-10 group-hover:opacity-20 transition-opacity duration-700" />
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="max-w-xl text-center md:text-left">
               <h3 className="text-3xl md:text-4xl font-display font-medium text-white mb-4">Pronto para escalar sua operação?</h3>
               <p className="text-zinc-400 font-light">Solicite um orçamento sob medida ou entenda qual é o escopo ideal para a necessidade imediata da sua comunidade.</p>
            </div>
            <Link to="/contact" className="shrink-0 inline-flex items-center justify-center gap-3 bg-white text-black px-8 py-4 rounded-full font-semibold tracking-wide transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.3)] border border-transparent">
              Falar com Engenheiro <ArrowRight size={18} />
            </Link>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
