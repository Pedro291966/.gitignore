import { motion } from 'motion/react';
import { Database, Server, ServerCog, Activity, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Sistemas() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen"
    >
      <div className="absolute top-0 right-0 w-1/2 aspect-square bg-zinc-800/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16 border-b border-zinc-900 pb-12 text-center md:text-left"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-900/50 text-xs font-semibold uppercase tracking-widest text-zinc-300 mb-8 backdrop-blur-sm">
            <ServerCog size={16} /> Alta Complexidade
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-medium tracking-tight mb-6 leading-[1.1] text-white">
            Sistemas & APIs Backend
          </h1>
          <p className="text-lg text-zinc-400 font-light max-w-2xl leading-relaxed mx-auto md:mx-0">
            A espinha dorsal das operações da sua empresa. Painéis administrativos sob medida, integrações de bancos de dados legados, micro-serviços e processamento pesado isolado na nuvem.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {[
            {
              icon: <Database size={24} />,
              title: "Modelagem de Dados",
              desc: "Projetamos esquemas SQL e NoSQL escaláveis. Seja Postgres, MongoDB ou Redis, a arquitetura nascerá preparada para milhares de reads/writes assíncronos."
            },
            {
              icon: <Server size={24} />,
              title: "Construção de APIs",
              desc: "Interfaces RESTful ou viadutos GraphQL rigorosamente documentados, versionados e com payloads compactos."
            },
            {
              icon: <Activity size={24} />,
              title: "Observabilidade Global",
              desc: "Logs reais e métricas granulares sobre CPU/Memória integradas no seu sistema, garantindo antecipação contra incidentes estruturais."
            }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 border border-zinc-900 bg-zinc-950/40 hover:bg-zinc-900/50 hover:border-zinc-800 transition-all rounded-3xl group shadow-lg flex flex-col items-center md:items-start text-center md:text-left"
            >
               <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-zinc-400 group-hover:text-white group-hover:bg-zinc-800 transition-colors mb-6 shadow-inner">
                 {feature.icon}
               </div>
               <h3 className="text-xl font-display font-medium text-white mb-3">{feature.title}</h3>
               <p className="text-zinc-400 leading-relaxed font-light">{feature.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Link to="/contact" className="inline-flex items-center justify-center gap-3 bg-zinc-900 text-white border border-zinc-700 px-8 py-4 rounded-full font-semibold tracking-wide transition-all hover:bg-zinc-800 hover:border-zinc-500 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.05)]">
            Discutir Requisitos de Arquitetura <ArrowRight size={18} />
          </Link>
        </motion.div>
      </div>
    </motion.div>
  );
}
