import { useParams, Navigate, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, Calendar, User, Share2 } from 'lucide-react';
import { newsData } from '../data/news';

export default function NewsDetail() {
  const { id } = useParams<{ id: string }>();
  
  if (!id || !newsData[id]) {
    return <Navigate to="/news" replace />;
  }

  const article = newsData[id];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen"
    >
      <div className="absolute top-0 right-0 w-1/2 aspect-square bg-zinc-800/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-12"
        >
          <Link to="/news" className="inline-flex items-center gap-2 text-zinc-500 hover:text-white transition-colors text-sm font-semibold uppercase tracking-widest group">
            <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" /> Todas as Novidades
          </Link>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16 border-b border-zinc-900 pb-12"
        >
          <div className="flex items-center gap-3 mb-8">
            <span className="px-3 py-1 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded-full">{article.category}</span>
            <div className="flex items-center gap-1.5 text-zinc-500 text-xs font-semibold uppercase tracking-widest">
              <Calendar size={14} />
              {article.date}
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-display font-medium tracking-tight mb-6 leading-[1.1] text-white">
            {article.title}
          </h1>
          <p className="text-lg text-zinc-400 font-light max-w-2xl leading-relaxed">
            {article.description}
          </p>

          <div className="flex items-center justify-between mt-10">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full border border-zinc-800 overflow-hidden bg-zinc-900">
                <img src={article.authorAvatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80'} alt={article.author} className="w-full h-full object-cover" />
              </div>
              <div>
                <p className="text-white font-medium text-sm">{article.author}</p>
                <p className="text-zinc-500 text-xs">{article.authorRole || 'Equipe Pedro Oliver Dev'}</p>
              </div>
            </div>
            
            <button className="w-10 h-10 rounded-full border border-zinc-800 bg-zinc-900/50 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-700 transition-all active:scale-95 group relative">
               <Share2 size={16} />
               <span className="absolute -top-10 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl">
                 Compartilhar
               </span>
            </button>
          </div>
        </motion.div>

        {article.image && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="w-full aspect-[2/1] rounded-3xl overflow-hidden border border-zinc-800 bg-zinc-900 mb-16 relative"
          >
            <div className="absolute inset-0 bg-zinc-800 animate-pulse -z-10" />
            <img src={article.image} alt={article.title} className="w-full h-full object-cover" loading="lazy" />
          </motion.div>
        )}

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="prose prose-invert prose-zinc max-w-none text-zinc-400 
            prose-headings:font-display prose-headings:font-medium prose-headings:tracking-tight prose-headings:text-white
            prose-a:text-white prose-a:decoration-zinc-700 hover:prose-a:decoration-white prose-a:underline-offset-4 
            prose-strong:text-zinc-200 mb-20 leading-loose"
          dangerouslySetInnerHTML={{ __html: article.content }}
        />
      </div>
    </motion.div>
  );
}
