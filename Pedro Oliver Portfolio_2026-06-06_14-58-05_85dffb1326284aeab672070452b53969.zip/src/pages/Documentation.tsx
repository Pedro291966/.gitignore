import { motion } from 'motion/react';
import SectionHeader from '../components/SectionHeader';
import { ChevronDown, Code, Puzzle, Terminal, BookOpen, Layers, Zap, Cloud } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function Documentation() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [activeSection, setActiveSection] = useState('getting-started');

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if(entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, { rootMargin: '-20% 0px -70% 0px' });
    
    document.querySelectorAll('section[id]').forEach(sec => observer.observe(sec));
    return () => observer.disconnect();
  }, []);

  const faqs = [
    { question: 'Quais arquiteturas de Front-end vocês utilizam?', answer: 'Trabalhamos predominantemente com ecossistemas baseados em React (Vite e Next.js), aplicando diretrizes estritas do Clean Architecture, desacoplando regras de negócios das camadas de interface (UI) por implementações de inversão de controle (IoC).' },
    { question: 'Quais métodos de pagamento vocês aceitam?', answer: 'Aceitamos todas as principais bandeiras de cartões via Stripe, além de transferências bancárias internacionais e PIX para clientes do Brasil. Todos os fluxos de checkout aderem ao nível máximo de conformidade PCI-DSS (nível 1).' },
    { question: 'Como funciona a política de reembolsos e garantias?', answer: 'O reembolso garante proteção total na fase de Discovery do projeto (primeiros 7 dias). Após a alocação técnica focada e entrega do software, garantimos correções absolutas por 30 dias para qualquer quebra, ou divergência dos requisitos firmados.' },
    { question: 'Vocês realizam integrações com APIs legadas ou corporativas?', answer: 'Sim. Implementamos BFFs (Backend-For-Frontend) ou adaptadores no NodeJS (Express/Nest) especificamente concebidos para sanitizar e estruturar os retornos de APIs legadas (como SOAP, XML antigos, ou CRMs restritos).' },
    { question: 'Como protegem as aplicações de vulnerabilidades clássicas?', answer: 'Implementamos por padrão restrições rigorosas de Rate Limiting, sanitização massiva de inputs (blindagem contra XSS e SQL/NoSQL Injection) além de configurações herméticas de CORS e Helmet. Toda API deve operar em Zero-Trust.' },
    { question: 'O que devo fazer se encontrar um "Erro 500" no ambiente de teste?', answer: 'Caso cruze com erros de servidor (Internal Server Error) na branch de staging, reporte o ID do Log diretamente no canal dedicado do Slack/Discord do projeto. O tracking (geralmente gerido no Sentry) apontará o cluster falho em tempo real.' },
    { question: 'Oferecem manutenção contínua após o lançamento (Deploy)?', answer: 'Sim. A fase pós-go-live permite a transição para pacotes de SLO/SLA que definem tempo restrito de resposta. A monitoria contínua de Uptime e degradação de instâncias fica sob nossa vigília estrita 24 horas por dia.' },
  ];

  return (
    <div>
      <SectionHeader 
        title="Documentação" 
        subtitle="Guias de implementação, referências arquiteturais e materiais de uso para os times de desenvolvimento." 
      />
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 mb-32 grid lg:grid-cols-12 gap-16 relative">
        <div className="lg:col-span-3 hidden lg:block">
            <div className="sticky top-32 flex flex-col gap-3 border-l border-zinc-900 border-dashed">
            <div className="font-bold uppercase tracking-widest text-xs text-zinc-500 mb-4 pl-4">Sumário</div>
            <a href="#getting-started" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'getting-started' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Getting Started</a>
            <a href="#architecture" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'architecture' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Arquitetura Padrão</a>
            <a href="#guias-uso" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'guias-uso' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Guias de Uso</a>
            <a href="#frontend-best-practices" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'frontend-best-practices' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Best Practices: Frontend</a>
            <a href="#backend-best-practices" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'backend-best-practices' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Best Practices: Backend</a>
            <a href="#integracoes" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'integracoes' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Integrações Básicas</a>
            <a href="#deploy" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'deploy' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Deploy & CI/CD</a>
            <a href="#faq" className={`transition-all py-1 pl-4 text-sm border-l-2 ${activeSection === 'faq' ? 'border-white text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}>Perguntas Frequentes</a>
          </div>
        </div>

        <div className="lg:col-span-9 flex flex-col gap-32">
          
          <motion.section 
            id="getting-started"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><Terminal size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Getting Started</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-8 text-lg">
              Nosso boilerplate oficial utiliza as tecnologias mais eficientes do ecossistema React. Para iniciar o ambiente local do seu projeto, certifique-se de que o Node.JS e o NPM mais recentes estão instalados e utilize os comandos abaixo:
            </p>
            <div className="bg-zinc-950/80 backdrop-blur-sm border border-zinc-900 rounded-2xl p-8 font-mono text-sm text-zinc-300 overflow-x-auto shadow-2xl transition-all duration-300 hover:border-zinc-800">
              <span className="text-zinc-600 block mb-2"># Clone The Repository</span>
              <div className="text-white">git clone git@github.com:studio/project-name.git</div>
              <div className="mt-2 text-white">cd project-name</div>
              <span className="text-zinc-600 block mt-6 mb-2"># Install Core Dependencies using preferred package manager</span>
              <div className="text-white">npm install</div>
              <span className="text-zinc-600 block mt-6 mb-2"># Start Local Development Server on port 3000</span>
              <div className="text-white">npm run dev</div>
            </div>
          </motion.section>

          <motion.section 
            id="architecture"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><Puzzle size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Arquitetura Padrão</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-8 text-lg">
              As aplicações são estruturadas visando organização e separação de preocupações (Separation of Concerns). Seguindo os princípios de modularidade, a estrutura de pastas principal é dividida assim:
            </p>
            <div className="bg-zinc-950/80 backdrop-blur-sm border border-zinc-900 rounded-2xl p-8 font-mono text-sm text-zinc-400 leading-9 shadow-2xl transition-all duration-300 hover:border-zinc-800">
              <div className="flex items-center gap-3 mb-2"><Code size={18} className="text-white" /> <span className="text-white font-medium text-base">src/</span></div>
              <div className="pl-8 border-l border-zinc-900 ml-2 border-dashed flex flex-col gap-1">
                <div>├── components/ <span className="text-zinc-600 hidden sm:inline ml-2"># UI Components isolated from logic</span></div>
                <div>├── pages/ <span className="text-zinc-600 hidden sm:inline ml-11"># Routing entries & Layouts</span></div>
                <div>├── data/ <span className="text-zinc-600 hidden sm:inline ml-12"># Mock structures & static data</span></div>
                <div>├── styles/ <span className="text-zinc-600 hidden sm:inline ml-10"># Tailwind CSS configurations</span></div>
                <div>└── lib/ <span className="text-zinc-600 hidden sm:inline ml-14"># Utility functions & API refs</span></div>
              </div>
            </div>
          </motion.section>

          <motion.section 
            id="guias-uso"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><BookOpen size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Guias de Uso (Tutoriais)</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-6 text-lg">
              A compreensão dos nossos sistemas modulares passa por tutoriais de rápida assimilação. Caso precise alterar estados globais, adicionar páginas ou rotas:
            </p>
            <div className="space-y-4">
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">1. Adicionando novas Rotas e Páginas</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">Crie o componente da nova página na pasta <code>src/pages</code> e efetue o registro correto do roteamento utilizando o React Router v6 no entrypoint <code>App.tsx</code>.</p>
               </div>
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">2. Atualizando variáveis de CSS Global</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">A paleta de cores (Tailwind UI) reside no arquivo <code>index.css</code>. Modifique as vars <code>--color-background</code> e <code>--color-foreground</code> para alterar o root theme.</p>
               </div>
            </div>
          </motion.section>

          <motion.section 
            id="frontend-best-practices"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><Layers size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Best Practices: Front-end</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-6 text-lg">
              A arquitetura na camada cliente deve focar imperativamente na performance perceptível pelo usuário (TTFB, LCP), acessibilidade plena (WCAG) e modularidade do código sob os padrões do Clean Code.
            </p>
            <div className="space-y-4">
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">1. Organização de Código & Clean Architecture</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">Adote `Feature-Sliced Design` (FSD) ou domain-driven folder structures. Evite acoplar requisições diretamente na árvore de views React. Encapsule o Data Fetching em Custom Hooks e gerencie os estados globais via ferramentas atômicas (Zustand, Jotai) ou baseadas em Query caches (TanStack Query).</p>
               </div>
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">2. Performance Optmization</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">Empregue `Code Splitting` por rotas. Utilize SSG (Static Site Generation) para documentações e landing pages, ISG para comércio e SSR (Server Side Rendering) somente se necessário. Para assets, use formatadores automáticos de WebP/AVIF e adote Image lazy loading.</p>
               </div>
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">3. Responsividade & Acessibilidade</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">Codifique utilizando padrões Mobile-first. Adote TailwindCSS ou sistemas de design Tokens para breakpoints fluidos. Valide semanticidade de HTML (uso de tags <code>nav</code>, <code>article</code>, botões via <code>button</code>) e garanta suporte para navegação via teclado e Screen Readers (Aria labels estruturais).</p>
               </div>
            </div>
          </motion.section>

          <motion.section 
            id="backend-best-practices"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><Cloud size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Best Practices: Back-end</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-6 text-lg">
              Na engenharia de servidores e APIs, o foco reside majoritariamente na tolerância a falhas, escalabilidade horizontal rápida, transações seguras e tempos nulos de downtime sob imensas cargas.
            </p>
            <div className="space-y-4">
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">1. Escalabilidade & Manutenção</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">Adote microsserviços limitados ou micro-monolitos escaláveis em nuvem instanciada (Serverless Functions via AWS Lambda, ou Edge Computing). Mantenha as APIs em conformidade absoluta com os padrões RESTful ou GraphQL persistindo documentação (Swagger / OpenAPI) rigorosamente atualizada.</p>
               </div>
               <div className="p-6 border border-zinc-900 bg-zinc-950/40 rounded-2xl hover:border-zinc-700 transition-colors">
                  <h3 className="text-xl font-medium text-white mb-2">2. Segurança de Camada de Aplicação</h3>
                  <p className="text-zinc-400 font-light leading-relaxed mb-4">Autenticação sempre baseada em tokens assimétricos (JWT / JWE) combinada com Refresh Tokens HttpOnly seguros contra XSS. Implemente Helmet para encabeçamentos, Rate Limiting proativo, criptografia Hash complexa (Bcrypt, Argon2) e zero-trust no Input Parsing (utilize bibliotecas como <code>Zod</code> no Typescript).</p>
               </div>
            </div>
          </motion.section>

          <motion.section 
            id="integracoes"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><Zap size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Integrações Básicas</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-8 text-lg">
              Integração com APIs externas deve ser encapsulada em provedores ou serviços específicos isolados em <code>src/services/</code>.
            </p>
            <ul className="list-disc pl-6 text-zinc-400 space-y-3 font-light text-lg marker:text-zinc-600">
               <li><strong className="text-white font-medium">Stripe (Pagamentos):</strong> Utilize o pacote oficial e restrinja as chaves de API secretas ao Backend SDKs.</li>
               <li><strong className="text-white font-medium">Firebase / Supabase:</strong> Inicie no early entrypoint para gerenciar as rotas protegidas (Auth Guards).</li>
               <li><strong className="text-white font-medium">CMS (Sanity/Strapi):</strong> Fetches de SSR ou SSG são geridos no topo de página (Next.js) ou via hooks específicos de fetch.</li>
            </ul>
          </motion.section>

          <motion.section 
            id="deploy"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm rounded-xl"><Cloud size={24} className="text-white" /></div>
              <h2 className="text-4xl font-display font-medium tracking-tight">Deploy & CI/CD</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed font-light mb-6 text-lg">
              O deploy na edge infrastructure é fundamental para as nossas entregas de alto desempenho. Preferimos o uso orgânico da Vercel para frontends React/Next.
            </p>
            <div className="bg-zinc-950/80 border border-zinc-900 rounded-2xl p-6 font-mono text-sm text-zinc-300">
               Configuração sugerida para Build Settings: <br/><br/>
               <span className="text-zinc-500">Framework Preset:</span> Vite / Next <br/>
               <span className="text-zinc-500">Build Command:</span> <span className="text-white">npm run build</span> <br/>
               <span className="text-zinc-500">Output Directory:</span> <span className="text-white">dist</span>
            </div>
          </motion.section>

          <motion.section 
            id="faq"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="scroll-mt-32"
          >
            <h2 className="text-4xl font-display font-medium tracking-tight mb-12">Perguntas Frequentes</h2>
            <div className="flex flex-col gap-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-zinc-900 bg-zinc-950/50 rounded-3xl overflow-hidden transition-all duration-300 hover:border-zinc-700 hover:bg-zinc-900">
                  <button 
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full px-8 py-6 text-left flex justify-between items-center transition-colors outline-none focus:bg-white/5 active:bg-white/10"
                  >
                    <span className="font-medium text-white text-lg pr-4">{faq.question}</span>
                    <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all duration-300 ${openFaq === i ? 'border-white bg-white text-black' : 'border-zinc-800 text-zinc-400'}`}>
                      <ChevronDown size={18} className={`transition-transform duration-300 ${openFaq === i ? 'rotate-180' : ''}`} />
                    </div>
                  </button>
                  <div className={`grid transition-all duration-300 ease-in-out ${openFaq === i ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                    <div className="overflow-hidden">
                      <div className="px-8 pb-8 pt-2 text-zinc-400 font-light leading-relaxed text-lg border-t border-zinc-900/50 mx-8">
                        {faq.answer}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.section>
        </div>
      </div>
    </div>
  );
}
