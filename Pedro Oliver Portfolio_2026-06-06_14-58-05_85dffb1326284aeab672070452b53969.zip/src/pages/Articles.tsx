import { motion } from 'motion/react';
import { ArrowRight, Terminal, CheckCircle2, Clock, User, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import SectionHeader from '../components/SectionHeader';
import { articlesData } from '../data/articles';
import { OptimizedImage } from '../components/OptimizedImage';

export default function Articles() {
  const [readArticles, setReadArticles] = useState<string[]>([]);
  
  useEffect(() => {
    try {
      const stored = localStorage.getItem('readArticles');
      if (stored) setReadArticles(JSON.parse(stored));
    } catch(e) {}
  }, []);
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 30 },
    show: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, } 
    }
  };

  return (
    <motion.div initial="hidden" animate="show" exit="hidden" variants={container} className="min-h-screen">
      <SectionHeader 
        title="Artigos & Documentações" 
        subtitle="Explore nossos manuais completos, perspectivas técnicas, tutoriais de engenharia e insights corporativos." 
      />
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 mb-32">
        <motion.div variants={container} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-50px" }} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articlesData.map((article) => {
            const isRead = readArticles.includes(article.id);
            return (
              <motion.article 
                key={article.id}
                variants={item}
                className={`group relative flex flex-col bg-zinc-900/40 border border-zinc-800 rounded-3xl overflow-hidden hover:bg-zinc-900/80 hover:border-zinc-700 transition-all duration-500 shadow-lg ${isRead ? 'opacity-75' : ''}`}
              >
                <Link to={`/articles/${article.id}`} className="absolute inset-0 z-10" aria-label={article.title}></Link>
                
                <div className="w-full aspect-[16/10] overflow-hidden relative border-b border-zinc-800/50 bg-zinc-950">
                  <OptimizedImage 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-700"
                  />
                  <div className="absolute top-4 left-4 z-20 pointer-events-none flex gap-2">
                    <span className="text-white flex items-center gap-1.5 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-lg text-xs font-semibold uppercase tracking-widest border border-white/10">
                      {article.category === 'Engenharia' || article.category === 'Sistemas e Automações' ? <Terminal size={12} /> : null}
                      {article.category}
                    </span>
                  </div>
                  {isRead && (
                    <div className="absolute top-4 right-4 z-20 pointer-events-none">
                       <span className="flex items-center gap-1.5 px-2 py-1 bg-emerald-500/20 backdrop-blur-md text-emerald-300 text-xs font-bold rounded-md border border-emerald-500/30 shadow-sm" aria-label="Artigo já lido">
                         <CheckCircle2 size={14} /> LIDO
                       </span>
                    </div>
                  )}
                </div>

                <div className="flex flex-col flex-grow p-6 md:p-8">
                  <div className="flex items-center flex-wrap gap-x-4 gap-y-2 text-xs font-medium text-zinc-500 mb-4 pointer-events-none">
                    <span className="flex items-center gap-1.5"><Clock size={14} /> {article.readTime || '5 min de leitura'}</span>
                    <span className="w-1 h-1 rounded-full bg-zinc-700" />
                    <span>{article.date}</span>
                  </div>
                  
                  <h2 className={`text-xl md:text-2xl font-display font-semibold tracking-tight mb-3 transition-colors duration-300 line-clamp-2 ${isRead ? 'text-zinc-400 group-hover:text-zinc-200' : 'text-white group-hover:text-zinc-100'}`}>
                    {article.title}
                  </h2>
                  
                  <p className="text-zinc-400 font-light leading-relaxed mb-5 text-sm line-clamp-3">
                    {article.excerpt}
                  </p>

                  {article.tags && article.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-6 mt-auto">
                      {article.tags.slice(0, 3).map((tag, idx) => (
                        <span key={idx} className="flex items-center gap-1 text-[10px] font-medium tracking-wider uppercase bg-zinc-800/50 text-zinc-400 px-2.5 py-1 rounded-md border border-zinc-700/50 z-20 pointer-events-none">
                           <Tag size={10} /> {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="mt-auto pt-6 border-t border-zinc-800/60 flex items-center justify-between z-20 pointer-events-none">
                     <div className="flex items-center gap-2 text-xs font-medium text-zinc-500">
                        <User size={14} className="text-zinc-600" />
                        {article.author || 'Pedro Oliver Dev'}
                     </div>
                     <span className={`inline-flex items-center gap-1.5 text-sm font-semibold tracking-wide transition-all ${isRead ? 'text-zinc-500 group-hover:text-zinc-400' : 'text-white group-hover:text-zinc-300'}`}>
                       Ler post <ArrowRight size={16} className="group-hover:translate-x-1.5 transition-transform duration-300" />
                     </span>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </motion.div>
      </div>
    </motion.div>
  );
}
