import { motion } from 'motion/react';
import { ArrowUpRight, FileText } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import { Link } from 'react-router-dom';

export default function Projects() {
  const projects = [
    {
      id: 1,
      name: 'Omni Dashboard',
      description: 'Uma interface técnica para monitoramento de dados em tempo real, focada em performance e usabilidade para desenvolvedores.',
      tech: ['React', 'TypeScript', 'Tailwind CSS', 'Recharts'],
      img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800&grayscale=true',
    },
    {
      id: 2,
      name: 'Nexus Marketplace',
      description: 'Plataforma de e-commerce premium com foco em experiência de conversão de alto nível e estética limpa para marcas de luxo.',
      tech: ['Next.js', 'Stripe', 'Framer Motion'],
      img: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800&grayscale=true',
    },
    {
      id: 3,
      name: 'Vortex Protocol',
      description: 'Landing page imersiva para um projeto DeFi, utilizando animações suaves e tipografia ousada com WebGL.',
      tech: ['Vite', 'React', 'Three.js'],
      img: 'https://images.unsplash.com/photo-1639762681057-408e52192e55?auto=format&fit=crop&q=80&w=800&grayscale=true',
    }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemAnim = {
    hidden: { opacity: 0, y: 50 },
    show: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.5, }
    }
  };

  return (
    <motion.div initial="hidden" animate="show" exit="hidden" variants={container}>
      <SectionHeader 
        title="Trabalhos Recentes" 
        subtitle="Explore nossa coleção de projetos selecionados. Experiências digitais únicas criadas sob medida." 
      />
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 mb-32 flex flex-col gap-24">
        {projects.map((project, i) => (
          <motion.article 
            key={project.id}
            variants={itemAnim}
            viewport={{ once: true, margin: '-50px' }}
            whileInView="show"
            initial="hidden"
            className={`flex flex-col ${i % 2 !== 0 ? 'md:flex-row-reverse' : 'md:flex-row'} gap-12 items-center`}
          >
            <div className="w-full md:w-3/5 group cursor-pointer relative overflow-hidden rounded-3xl bg-zinc-900 aspect-[4/3]">
               <img 
                 src={project.img} 
                 alt={project.name} 
                 className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105 opacity-70 group-hover:opacity-100"
               />
               <div className="absolute inset-0 border border-white/10 rounded-3xl pointer-events-none" />
               <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
            
            <div className="w-full md:w-2/5 flex flex-col">
              <h2 className="text-3xl md:text-5xl font-display font-medium tracking-tight mb-4">{project.name}</h2>
              <p className="text-zinc-400 leading-relaxed font-light mb-8 text-lg">{project.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-10">
                {project.tech.map(t => (
                  <span key={t} className="px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-xs font-mono tracking-tight text-zinc-300">
                    {t}
                  </span>
                ))}
              </div>
              
              <div className="flex gap-4 relative z-20">
                <a 
                  href="https://github.com" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  aria-label={`Ver código fonte de ${project.name} no Github`}
                  className="group relative flex-1 inline-flex justify-center items-center gap-2 bg-gradient-to-r from-zinc-200 to-white text-black px-6 py-4 rounded-full font-semibold text-sm transition-all hover:scale-[1.03] active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.15)] hover:shadow-[0_0_30px_rgba(255,255,255,0.25)]"
                >
                  Github <ArrowUpRight size={16} />
                  <span className="absolute -top-12 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800">
                    Acessar Repositório
                  </span>
                </a>
                <Link 
                  to="/docs" 
                  aria-label={`Ler documentação de ${project.name}`}
                  className="group relative flex-1 inline-flex justify-center items-center gap-2 border border-zinc-700 bg-gradient-to-b from-zinc-800/50 to-zinc-950/50 backdrop-blur text-white px-6 py-4 rounded-full font-medium text-sm transition-all hover:bg-zinc-800 hover:border-zinc-500 active:scale-95"
                >
                  Documentação <FileText size={16} />
                  <span className="absolute -top-12 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-zinc-900 text-zinc-300 text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl border border-zinc-800">
                    Ver detalhes técnicos
                  </span>
                </Link>
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </motion.div>
  );
}
