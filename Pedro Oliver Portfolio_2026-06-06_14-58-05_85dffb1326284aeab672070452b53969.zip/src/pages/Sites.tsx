import { motion } from 'motion/react';
import { Globe, LayoutTemplate, Smartphone, Zap, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Sites() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full relative min-h-screen"
    >
      <div className="absolute top-0 right-0 w-1/2 aspect-square bg-zinc-800/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16 border-b border-zinc-900 pb-12 text-center md:text-left"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-900/50 text-xs font-semibold uppercase tracking-widest text-zinc-300 mb-8 backdrop-blur-sm">
            <Globe size={16} /> Presença Digital
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-medium tracking-tight mb-6 leading-[1.1] text-white">
            Sites Modernos & Landing Pages
          </h1>
          <p className="text-lg text-zinc-400 font-light max-w-2xl leading-relaxed mx-auto md:mx-0">
            A vitrine definitiva do seu negócio na internet. Combinamos design premiado com performance e acessibilidade para converter leads em clientes.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-20">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="p-10 border border-zinc-800 bg-gradient-to-br from-zinc-900/50 to-black rounded-3xl"
          >
             <LayoutTemplate size={32} className="text-white mb-6" />
             <h3 className="text-2xl font-display font-medium text-white mb-4">Arquitetura de Conversão</h3>
             <p className="text-zinc-400 leading-relaxed font-light mb-6">Nossas Landing Pages são desenhadas com psicologia de consumo em mente. Uso preciso de cores de alerta, contraste focado e tipografia legível para conduzir os olhos direto para o Call To Action principal.</p>
             <ul className="space-y-3">
               {['Wireframes fidedignos', 'Dark/Light mode nativo', 'Hero sections dinâmicas'].map((item, i) => (
                 <li key={i} className="flex flex-center gap-2 text-zinc-300 text-sm">
                   <div className="w-1.5 h-1.5 rounded-full bg-zinc-600 mt-1.5 shrink-0" />
                   {item}
                 </li>
               ))}
             </ul>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="p-10 border border-zinc-800 bg-gradient-to-bl from-zinc-900/50 to-black rounded-3xl"
          >
             <Zap size={32} className="text-white mb-6" />
             <h3 className="text-2xl font-display font-medium text-white mb-4">Vitesse Absoluta</h3>
             <p className="text-zinc-400 leading-relaxed font-light mb-6">Em pleno 2026, seu site institucional não pode demorar mais do que poucos milissegundos para carregar. Nós aplicamos otimizações radicais na borda da CDN e lazy-loading de assets para a pontuação de 100 no Lighthouse.</p>
             <ul className="space-y-3">
               {['Pontuação TTI invejável', 'Imagens WebP Otimizadas', 'Deploy distribuído via Edge'].map((item, i) => (
                 <li key={i} className="flex flex-center gap-2 text-zinc-300 text-sm">
                   <div className="w-1.5 h-1.5 rounded-full bg-zinc-600 mt-1.5 shrink-0" />
                   {item}
                 </li>
               ))}
             </ul>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <Link to="/projects" className="inline-flex items-center justify-center gap-3 bg-white text-black px-8 py-4 rounded-full font-semibold tracking-wide transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.3)] border border-transparent">
            Ver Portfólio de Sites <ArrowRight size={18} />
          </Link>
        </motion.div>
      </div>
    </motion.div>
  );
}
