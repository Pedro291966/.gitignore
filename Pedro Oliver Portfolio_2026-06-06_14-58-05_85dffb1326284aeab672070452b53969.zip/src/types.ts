export interface InfoPageType {
  id: string;
  title: string;
  description: string;
  content: string;
}
